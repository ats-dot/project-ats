package com.ats_tsalatsah.app

import android.graphics.Rect
import android.os.SystemClock

// Apa yang dicari di layar.
data class ScreenTarget(
    val name: String,
    val keys: List<String>,                          // kata kunci OCR (cocok salah satu)
    val area: Area = Area.FULL,                      // area yang dibaca
    val scale: Float = 0.6f,                         // perkecil gambar (min 0.5)
    val needPixels: List<PixelProbe> = emptyList(),  // harus cocok dulu, kalau tidak OCR dilewati
    val pixelOnly: Boolean = false,                  // cukup cek piksel, tanpa OCR
    val tapX: Float? = null,                         // titik ketuk (pecahan layar),
    val tapY: Float? = null,                         // null = tengah baris teks yang ketemu
    val popups: List<ScreenPopup> = emptyList()      // popup pengganggu: kalau terlihat, ketuk tutup dulu
)

// Popup yang harus ditutup dulu (ketuk silang) sebelum target dicari lagi.
data class ScreenPopup(
    val name: String,
    val keys: List<String>,   // teks khas popup (cocok salah satu)
    val tapX: Float,          // posisi tombol tutup (pecahan layar)
    val tapY: Float
)

object Popups {
    // "Got it": pengumuman yang kadang muncul sesudah game dimuat ulang (ganti server); diketuk begitu terbaca
    val GOT_IT = ScreenPopup(
        name = "Got it",
        keys = listOf("Got it"),
        tapX = 0.5f,
        tapY = 0.889f
    )

    // "Switch Account": muncul kadang setelah loading, menutupi halaman Create Character.
    // Teks "Switch Account" sendiri tidak dipakai karena tombolnya juga ada di halaman biasa.
    val SWITCH_ACCOUNT = ScreenPopup(
        name = "Switch Account",
        keys = listOf("MOONTON Account", "Facebook Account"),
        tapX = 0.7575f,
        tapY = 0.175f
    )
}

sealed class WatchResult {
    class Found(
        val key: String,
        val box: Rect?,
        val atMs: Long,
        val reads: Int,
        val screenW: Int,
        val screenH: Int
    ) : WatchResult()

    class NotFound(val reason: String, val reads: Int) : WatchResult()
}

// Daftar layar yang dikenali. Ubah area/skala di sini kalau perlu.
object Targets {
    // Popup "Info Sistem" di apk pertama putaran 1: ketuk tombol "Login kembali"
    fun loginPopup(keys: List<String>) = ScreenTarget(
        name = "Login kembali",
        keys = keys,
        area = Area.POPUP_CENTER,
        scale = 0.6f
    )

    fun createCharacter(keys: List<String>) = ScreenTarget(
        name = "Create Character",
        keys = keys,
        area = Area.CREATE_TOP,
        scale = 0.6f,
        popups = listOf(Popups.SWITCH_ACCOUNT)
    )
}

object ScreenWatcher {

    // Sela antar pembacaan. Jarak screenshot minimal (345/420 ms) tetap dijaga OcrA11yService.
    private const val READ_GAP = 50L

    // Tambahan waktu tunggu setelah popup pengganggu ditutup (maksimal 3 kali per penantian)
    private const val POPUP_GRACE_MS = 10000L

    // Periksa layar berulang sampai target terlihat atau batas waktu habis.
    // stop() = cek tombol Hentikan. log() = catat per pembacaan.
    // Panggil dari thread latar.
    fun waitFor(
        target: ScreenTarget,
        timeoutMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): WatchResult {
        if (OcrA11yService.instance == null) {
            return WatchResult.NotFound("Aksesibilitas belum aktif", 0)
        }
        val t0 = SystemClock.uptimeMillis()
        var deadline = t0 + timeoutMs
        var popupExt = 0
        var reads = 0
        var lastText = ""
        var lastErr = ""

        while (true) {
            if (stop()) return WatchResult.NotFound("dihentikan", reads)
            if (reads > 0) Thread.sleep(READ_GAP)
            val left = deadline - SystemClock.uptimeMillis()
            if (left <= 0) break

            val svc = OcrA11yService.instance
                ?: return WatchResult.NotFound("Aksesibilitas mati di tengah jalan", reads)
            val shot = svc.capture(minOf(2000L, maxOf(200L, left)))
            reads++
            val bmp = shot.bmp
            if (bmp == null) {
                lastErr = OcrA11yService.errName(shot.code)
                log("baca #$reads: screenshot gagal setelah ${shot.ms} ms: $lastErr")
                // Kode 2 & 6 tidak akan berubah dengan mencoba lagi
                if (shot.code == 2 || shot.code == 6) return WatchResult.NotFound(lastErr, reads)
                continue
            }

            var keep = false // true = jangan recycle (ML Kit masih memakai)
            try {
                val w = bmp.width
                val h = bmp.height

                // Cek piksel dulu: kalau belum cocok, OCR tidak perlu dijalankan
                if (target.needPixels.isNotEmpty() && !PixelCheck.all(bmp, target.needPixels)) {
                    log("baca #$reads: screenshot ${shot.ms} ms, piksel belum cocok, OCR dilewati")
                    continue
                }
                if (target.pixelOnly) {
                    val p = target.needPixels.firstOrNull()
                    val box = if (p == null) null
                    else Rect((p.x * w).toInt(), (p.y * h).toInt(), (p.x * w).toInt() + 1, (p.y * h).toInt() + 1)
                    val at = SystemClock.uptimeMillis() - t0
                    log("baca #$reads: screenshot ${shot.ms} ms, piksel cocok (tanpa OCR)")
                    return WatchResult.Found(target.name, box, at, reads, w, h)
                }

                val r = ScreenOcr.read(bmp, target.area, target.scale)
                keep = r.timedOut
                val pct = (target.scale.coerceIn(ScreenOcr.MIN_SCALE, 1f) * 100).toInt()
                if (r.error != null) {
                    lastErr = r.error
                    log("baca #$reads: screenshot ${shot.ms} ms, OCR ${r.ms} ms GAGAL: ${r.error}")
                    continue
                }
                // Popup pengganggu dicek lebih dulu: tutup, lalu cari target lagi
                val pop = target.popups.firstOrNull { pp -> pp.keys.any { TextMatch.matches(r.text, it) } }
                if (pop != null) {
                    val svc2 = OcrA11yService.instance
                    val okTap = svc2 != null && svc2.tap(pop.tapX * w, pop.tapY * h)
                    // Popup ini berarti game sudah sampai halaman Create Character (ada di belakangnya):
                    // beri waktu tambahan supaya halamannya sempat terbaca setelah popup ditutup
                    var ext = ""
                    if (popupExt < 3) {
                        popupExt++
                        deadline = maxOf(deadline, SystemClock.uptimeMillis() + POPUP_GRACE_MS)
                        ext = ", waktu tunggu diperpanjang"
                    }
                    log("baca #$reads: popup '${pop.name}' terlihat, ketuk tutup di (${(pop.tapX * w).toInt()}, ${(pop.tapY * h).toInt()}): " + (if (okTap) "OK" else "GAGAL") + ext)
                    continue
                }
                val hit = TextMatch.find(r, target.keys)
                val tail = if (hit != null) "cocok '${hit.first}'" else "belum cocok"
                log("baca #$reads: screenshot ${shot.ms} ms, OCR ${r.ms} ms (${target.area.name} $pct%), $tail")
                if (hit != null) {
                    val at = SystemClock.uptimeMillis() - t0
                    return WatchResult.Found(hit.first, hit.second.box, at, reads, w, h)
                }
                lastText = r.text
            } finally {
                if (!keep) bmp.recycle()
            }
        }

        val sb = StringBuilder("batas $timeoutMs ms habis, '${target.name}' tidak terlihat ($reads kali dibaca)")
        if (lastErr.isNotEmpty()) sb.append("; error terakhir: ").append(lastErr)
        if (lastText.isNotEmpty()) {
            sb.append("; teks terakhir: ").append(lastText.replace('\n', ' ').take(100))
        }
        return WatchResult.NotFound(sb.toString(), reads)
    }

    // Tunggu target terlihat, lalu langsung ketuk SATU kali.
    fun waitAndTap(
        target: ScreenTarget,
        timeoutMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): WatchResult {
        val r = waitFor(target, timeoutMs, stop, log)
        if (r !is WatchResult.Found) return r
        val svc = OcrA11yService.instance ?: return WatchResult.NotFound("Aksesibilitas mati sebelum mengetuk", r.reads)

        val tx = target.tapX
        val ty = target.tapY
        val box = r.box
        val x: Float
        val y: Float
        if (tx != null && ty != null) {
            x = tx * r.screenW
            y = ty * r.screenH
        } else if (box != null) {
            x = box.exactCenterX()
            y = box.exactCenterY()
        } else {
            return WatchResult.NotFound("'${r.key}' terlihat tapi posisinya tidak diketahui, tidak diketuk", r.reads)
        }
        val ok = svc.tap(x, y)
        log("ketuk '${r.key}' di (${x.toInt()}, ${y.toInt()}): " + if (ok) "OK" else "GAGAL")
        return if (ok) r else WatchResult.NotFound("ketukan ke '${r.key}' gagal", r.reads)
    }
}
