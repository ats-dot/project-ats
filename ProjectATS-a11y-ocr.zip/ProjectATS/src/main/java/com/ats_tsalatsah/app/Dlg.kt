package com.ats_tsalatsah.app

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// Dialog bertema (pengganti AlertDialog bawaan): kartu membulat, tombol berbentuk pil,
// warna mengikuti tema aplikasi, muncul dengan animasi halus.
class Dlg(private val act: Activity, private val pal: Palette) {

    private val dens = act.resources.displayMetrics.density
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var titleText: String? = null
    private var titleMono = false
    private var msgText: String? = null
    private var codeText: String? = null
    private var noteText: String? = null
    private var bodyView: View? = null
    private var pos: Pair<String, () -> Unit>? = null
    private var neg: Pair<String, () -> Unit>? = null
    private var neu: Pair<String, () -> Unit>? = null
    private var itemLabels: List<String>? = null
    private var itemDanger = -1
    private var itemClick: ((Int) -> Unit)? = null
    private var wantKeyboard = false

    private fun dp(v: Int): Int = (v * dens).toInt()

    fun title(s: String, mono: Boolean = false): Dlg {
        titleText = s
        titleMono = mono
        return this
    }

    fun message(s: String): Dlg {
        msgText = s
        return this
    }

    fun code(s: String): Dlg {
        codeText = s
        return this
    }

    fun note(s: String): Dlg {
        noteText = s
        return this
    }

    fun view(v: View): Dlg {
        bodyView = v
        return this
    }

    fun positive(label: String, f: () -> Unit = {}): Dlg {
        pos = Pair(label, f)
        return this
    }

    fun negative(label: String, f: () -> Unit = {}): Dlg {
        neg = Pair(label, f)
        return this
    }

    fun neutral(label: String, f: () -> Unit = {}): Dlg {
        neu = Pair(label, f)
        return this
    }

    fun items(labels: List<String>, danger: Int = -1, f: (Int) -> Unit): Dlg {
        itemLabels = labels
        itemDanger = danger
        itemClick = f
        return this
    }

    fun keyboard(): Dlg {
        wantKeyboard = true
        return this
    }

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = radiusDp * dens
        if (stroke != null) g.setStroke(maxOf(1, (0.6f * dens).toInt()), stroke)
        return g
    }

    private fun ripple(bg: GradientDrawable): RippleDrawable {
        val rip = if (pal.dark) 0x33FFFFFF else 0x22000000
        return RippleDrawable(ColorStateList.valueOf(rip), bg, null)
    }

    private fun txt(s: String, sp: Float, color: Int, style: Int = Typeface.NORMAL): TextView {
        val t = TextView(act)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.DEFAULT, style)
        return t
    }

    private fun pill(label: String, filled: Boolean, onClick: () -> Unit): TextView {
        val t = txt(label, 14f, if (filled) pal.onPrimary else pal.text, Typeface.BOLD)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(18), dp(10), dp(18), dp(10))
        val bg = if (filled) rounded(pal.primary, 999f) else rounded(Color.TRANSPARENT, 999f, pal.borderStrong)
        t.background = ripple(bg)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    fun show(): Dialog {
        val dlg = Dialog(act)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(pal.card, 26f, pal.border)
        card.setPadding(dp(20), dp(20), dp(20), dp(16))

        val tt = titleText
        if (tt != null) {
            val t = if (titleMono) {
                val x = txt(tt, 15f, pal.text, Typeface.BOLD)
                x.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                x
            } else {
                txt(tt, 18f, pal.text, Typeface.BOLD)
            }
            t.setPadding(0, 0, 0, dp(10))
            card.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val mt = msgText
        if (mt != null) {
            val m = txt(mt, 14f, pal.text)
            m.setLineSpacing(0f, 1.25f)
            m.setPadding(0, 0, 0, dp(10))
            card.addView(m, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val ct = codeText
        if (ct != null) {
            val c = txt(ct, 12f, pal.text)
            c.typeface = Typeface.MONOSPACE
            c.setTextIsSelectable(true)
            c.setLineSpacing(0f, 1.3f)
            c.background = rounded(pal.field, 14f, pal.border)
            c.setPadding(dp(12), dp(10), dp(12), dp(10))
            card.addView(c, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val nt = noteText
        if (nt != null) {
            val n = txt(nt, 12f, pal.muted)
            n.setLineSpacing(0f, 1.25f)
            n.setPadding(0, dp(10), 0, 0)
            card.addView(n, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val bv = bodyView
        if (bv != null) card.addView(bv, LinearLayout.LayoutParams(MATCH, WRAP))

        val labels = itemLabels
        if (labels != null) {
            labels.forEachIndexed { i, s ->
                if (i > 0) {
                    val line = View(act)
                    line.setBackgroundColor(pal.border)
                    card.addView(line, LinearLayout.LayoutParams(MATCH, 1))
                }
                val r = txt(s, 15f, if (i == itemDanger) pal.danger else pal.text)
                r.setPadding(dp(4), dp(14), dp(4), dp(14))
                r.background = ripple(rounded(Color.TRANSPARENT, 12f))
                r.isClickable = true
                r.setOnClickListener {
                    dlg.dismiss()
                    itemClick?.invoke(i)
                }
                card.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }

        val p = pos
        val q = neg
        val u = neu
        if (p != null || q != null || u != null) {
            val stack = u != null
            val row = LinearLayout(act)
            row.orientation = if (stack) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            row.gravity = Gravity.END
            val lpTop = { LinearLayout.LayoutParams(if (stack) MATCH else WRAP, WRAP).also { it.topMargin = dp(8) } }
            if (stack) {
                if (p != null) row.addView(pill(p.first, true) { dlg.dismiss(); p.second() }, lpTop())
                if (u != null) row.addView(pill(u.first, false) { dlg.dismiss(); u.second() }, lpTop())
                if (q != null) row.addView(pill(q.first, false) { dlg.dismiss(); q.second() }, lpTop())
            } else {
                if (q != null) row.addView(pill(q.first, false) { dlg.dismiss(); q.second() }, LinearLayout.LayoutParams(WRAP, WRAP))
                if (p != null) {
                    val lp = LinearLayout.LayoutParams(WRAP, WRAP)
                    if (q != null) lp.leftMargin = dp(8)
                    row.addView(pill(p.first, true) { dlg.dismiss(); p.second() }, lp)
                }
            }
            val rlp = LinearLayout.LayoutParams(MATCH, WRAP)
            rlp.topMargin = dp(10)
            card.addView(row, rlp)
        }

        val sv = ScrollView(act)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(card, ViewGroup.LayoutParams(MATCH, WRAP))
        dlg.setContentView(sv)
        dlg.setCanceledOnTouchOutside(true)

        val w = dlg.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.setDimAmount(if (pal.dark) 0.6f else 0.32f)
            val width = minOf((act.resources.displayMetrics.widthPixels * 0.92f).toInt(), dp(460))
            w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
            if (wantKeyboard) {
                w.setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                        WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                )
            }
        }
        dlg.show()

        card.alpha = 0f
        card.scaleX = 0.94f
        card.scaleY = 0.94f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(IOS_EASE).start()
        return dlg
    }
}
