package com.ats_tsalatsah.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// Remote halaman Cek batas apk: orbit putus-putus yang lebih kecil dari Cabang, jumlah apk dengan tombol minus dan plus,
// dan bola kaca di tengah (ikon kartu memori; saat berjalan jadi kotak Hentikan, orbit jadi ruas progres)
class MemRemoteView(ctx: Context, private val pal: Palette) : View(ctx) {

    var onPlay: (() -> Unit)? = null
    var onStep: ((Int) -> Unit)? = null

    private val d = ctx.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    // Kotak acuan sama dengan remote Cabang (328 x 400) supaya letaknya sejajar. Zona: 0 bola, 1 minus, 2 plus
    private val refW = 328f
    private val refH = 400f
    private val cx0 = 164f
    private val cy0 = 200f
    private val orbitR = 98f
    private val zx = floatArrayOf(164f, 92f, 236f)
    private val zy = floatArrayOf(200f, 108f, 108f)
    private val zr = floatArrayOf(46f, 17f, 17f)
    private val bubR = 34f

    private var count = 30
    private var runMode = false
    private var runDone = 0
    private var runTotal = 0
    private var scaleU = 1f
    private var offX = 0f
    private var pressed = -1
    private var downX = 0f
    private var downY = 0f

    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rc = RectF()
    private val ICON = 0xFFE6E9E9.toInt()
    private val dashOrbit = DashPathEffect(floatArrayOf(3f, 9f), 0f)
    private val glass: Shader
    private val orbG: Shader

    init {
        glass = LinearGradient(
            -bubR, -bubR, bubR, bubR,
            intArrayOf(alphaOf(pal.text, 0.12f), alphaOf(pal.text, 0.03f), alphaOf(pal.text, 0.07f)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        orbG = RadialGradient(
            -0.24f * 46f, -0.4f * 46f, 1.7f * 46f,
            intArrayOf(0xFF4A5053.toInt(), 0xFF1A1D1F.toInt(), 0xFF080909.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun alphaOf(c: Int, a: Float): Int {
        val al = (Color.alpha(c) * a).toInt().coerceIn(0, 255)
        return Color.argb(al, Color.red(c), Color.green(c), Color.blue(c))
    }

    fun setCount(n: Int) {
        if (n == count) return
        count = n
        invalidate()
    }

    fun setRun(on: Boolean, doneN: Int, totalN: Int) {
        if (on == runMode && doneN == runDone && totalN == runTotal) return
        runMode = on
        runDone = doneN
        runTotal = totalN
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val ws = MeasureSpec.getSize(widthMeasureSpec)
        val w = if (ws > 0) ws else (refW * d).toInt()
        scaleU = minOf(w / refW, d * 1.15f)
        offX = (w - refW * scaleU) / 2f
        setMeasuredDimension(w, (refH * scaleU).toInt())
    }

    private fun hit(x: Float, y: Float): Int {
        val rx = (x - offX) / scaleU
        val ry = y / scaleU
        for (z in 0..2) {
            val extra = if (z == 0) 6f else 14f
            val dx = rx - zx[z]
            val dy = ry - zy[z]
            if (dx * dx + dy * dy <= (zr[z] + extra) * (zr[z] + extra)) return z
        }
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                pressed = hit(e.x, e.y)
                if (pressed >= 0) invalidate()
                return pressed >= 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (pressed >= 0 && (abs(e.x - downX) > slop || abs(e.y - downY) > slop)) {
                    pressed = -1
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val z = pressed
                pressed = -1
                invalidate()
                if (z >= 0 && hit(e.x, e.y) == z) {
                    when (z) {
                        0 -> onPlay?.invoke()
                        1 -> onStep?.invoke(-1)
                        2 -> onStep?.invoke(1)
                    }
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                pressed = -1
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (width == 0) return
        c.save()
        c.translate(offX, 0f)
        c.scale(scaleU, scaleU)
        drawOrbit(c)
        drawBubble(c)
        drawMini(c, 1)
        drawMini(c, 2)
        drawSphere(c)
        c.restore()
    }

    private fun drawOrbit(c: Canvas) {
        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.STROKE
        if (runMode) {
            val n = (if (runTotal > 0) runTotal else 24).coerceIn(1, 60)
            val lit = runDone.coerceIn(0, n)
            val step = 360f / n
            val gap = minOf(6f, step * 0.3f)
            pa.strokeWidth = 4f
            pa.strokeCap = Paint.Cap.ROUND
            rc.set(cx0 - orbitR, cy0 - orbitR, cx0 + orbitR, cy0 + orbitR)
            for (i in 0 until n) {
                pa.color = when {
                    i < lit -> alphaOf(pal.text, 0.92f)
                    i == lit -> alphaOf(pal.text, 0.5f)
                    else -> alphaOf(pal.text, 0.14f)
                }
                c.drawArc(rc, -90f + i * step + gap / 2f, step - gap, false, pa)
            }
            return
        }
        pa.strokeWidth = 2f
        pa.pathEffect = dashOrbit
        pa.color = alphaOf(pal.text, 0.13f)
        c.drawCircle(cx0, cy0, orbitR, pa)
        pa.pathEffect = null
    }

    // Gelembung jumlah apk di puncak orbit
    private fun drawBubble(c: Canvas) {
        c.save()
        c.translate(cx0, cy0 - orbitR)
        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.FILL
        pa.color = alphaOf(Color.BLACK, 0.55f)
        c.drawCircle(0f, 0f, bubR, pa)
        pa.shader = glass
        c.drawCircle(0f, 0f, bubR, pa)
        pa.shader = null
        pa.style = Paint.Style.STROKE
        pa.strokeWidth = 1.2f
        pa.color = alphaOf(pal.text, 0.22f)
        c.drawCircle(0f, 0f, bubR - 0.6f, pa)
        tp.reset()
        tp.isAntiAlias = true
        tp.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        tp.color = pal.text
        tp.textAlign = Paint.Align.CENTER
        val s = count.toString()
        tp.textSize = if (s.length >= 3) 22f else 30f
        c.drawText(s, 0f, tp.textSize * 0.35f, tp)
        c.restore()
    }

    private fun drawMini(c: Canvas, z: Int) {
        val k = if (pressed == z) 0.92f else 1f
        c.save()
        c.translate(zx[z], zy[z])
        c.scale(k, k)
        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.STROKE
        pa.strokeWidth = 1.2f
        pa.color = alphaOf(pal.text, if (pressed == z) 0.5f else 0.3f)
        c.drawCircle(0f, 0f, zr[z] - 0.6f, pa)
        pa.strokeWidth = 3f
        pa.strokeCap = Paint.Cap.ROUND
        pa.color = alphaOf(pal.text, 0.9f)
        c.drawLine(-6f, 0f, 6f, 0f, pa)
        if (z == 2) c.drawLine(0f, -6f, 0f, 6f, pa)
        c.restore()
    }

    private fun drawSphere(c: Canvas) {
        val r = 46f
        val sc = if (pressed == 0) 0.94f else 1f
        c.save()
        c.translate(cx0, cy0)
        c.scale(sc, sc)
        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.FILL
        pa.color = alphaOf(ICON, 0.05f)
        c.drawCircle(0f, 0f, r + 9f, pa)
        pa.color = alphaOf(ICON, 0.08f)
        c.drawCircle(0f, 0f, r + 4.5f, pa)
        pa.shader = orbG
        c.drawCircle(0f, 0f, r, pa)
        pa.shader = null
        pa.style = Paint.Style.STROKE
        pa.strokeWidth = 1f
        pa.color = alphaOf(Color.WHITE, 0.28f)
        c.drawCircle(0f, 0f, r - 0.5f, pa)
        pa.color = alphaOf(Color.WHITE, 0.14f)
        c.drawCircle(0f, 0f, r * 0.8f, pa)
        pa.style = Paint.Style.FILL
        pa.color = alphaOf(Color.WHITE, 0.20f + (if (pressed == 0) 0.08f else 0f))
        c.save()
        c.rotate(-28f, -0.26f * r, -0.48f * r)
        rc.set(-0.74f * r, -0.70f * r, 0.22f * r, -0.26f * r)
        c.drawOval(rc, pa)
        c.restore()
        if (runMode) {
            pa.style = Paint.Style.FILL
            pa.color = ICON
            rc.set(-12f, -12f, 12f, 12f)
            c.drawRoundRect(rc, 6f, 6f, pa)
        } else {
            // ikon kartu memori: badan, tiga kaki di atas dan bawah, garis tengah
            pa.style = Paint.Style.STROKE
            pa.strokeCap = Paint.Cap.ROUND
            pa.color = ICON
            pa.strokeWidth = 4.5f
            rc.set(-16f, -10f, 16f, 10f)
            c.drawRoundRect(rc, 4f, 4f, pa)
            pa.strokeWidth = 4f
            for (i in -1..1) {
                val x = i * 8f
                c.drawLine(x, -10f, x, -17f, pa)
                c.drawLine(x, 10f, x, 17f, pa)
            }
            pa.strokeWidth = 3.4f
            c.drawLine(-7f, 0f, 7f, 0f, pa)
        }
        c.restore()
    }
}

// Dua halaman pada satu "bola dunia" vertikal: Cabang dan Cek batas apk. Seret ke atas: Cabang berputar ke atas dan ke belakang
// sampai tak terlihat, Cek batas apk naik dari bawah. Seret ke bawah untuk kembali. Hanya halaman di depan yang menerima sentuhan.
class DrumLayout(ctx: Context) : FrameLayout(ctx) {

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var p = 0f              // 0 = Cabang di depan, 1 = Cek batas apk di depan
    private var anim: ValueAnimator? = null
    private var dragging = false
    private var startX = 0f
    private var startY = 0f
    private var startP = 0f
    private val m = Matrix()
    private val src = FloatArray(8)
    private val dst = FloatArray(8)
    private val dim = Paint()

    init {
        setWillNotDraw(false)
    }

    fun isCek(): Boolean = p >= 0.5f

    fun showCek(v: Boolean, animate: Boolean = true) {
        settle(if (v) 1f else 0f, animate)
    }

    private fun settle(to: Float, animate: Boolean) {
        anim?.cancel()
        if (!animate) {
            p = to
            updateVis()
            layers(false)
            invalidate()
            return
        }
        layers(true)
        val a = ValueAnimator.ofFloat(p, to)
        a.duration = (360f * abs(to - p)).toLong().coerceAtLeast(120L)
        a.interpolator = DecelerateInterpolator(1.6f)
        a.addUpdateListener {
            p = it.animatedValue as Float
            updateVis()
            invalidate()
        }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                p = to
                updateVis()
                layers(false)
                invalidate()
                anim = null
            }
        })
        anim = a
        a.start()
    }

    // Saat diam hanya satu halaman yang tampil dan menerima sentuhan; saat berputar keduanya digambar
    private fun updateVis() {
        if (childCount < 2) return
        val a = getChildAt(0)
        val b = getChildAt(1)
        val va = if (p >= 0.999f) View.INVISIBLE else View.VISIBLE
        val vb = if (p <= 0.001f) View.INVISIBLE else View.VISIBLE
        if (a.visibility != va) a.visibility = va
        if (b.visibility != vb) b.visibility = vb
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        updateVis()
    }

    override fun addView(child: View?, index: Int, params: ViewGroup.LayoutParams?) {
        super.addView(child, index, params)
        updateVis()
    }

    private fun span(): Float = height * 0.6f

    private var layersOn = false

    // Selama berputar tiap halaman digambar sekali ke lapisan GPU lalu hanya dimiringkan: jauh lebih halus daripada
    // menggambar ulang seluruh isi halaman di setiap bingkai
    private fun layers(on: Boolean) {
        if (layersOn == on) return
        layersOn = on
        for (i in 0 until childCount) getChildAt(i).setLayerType(if (on) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
    }

    // Mulai menyeret kalau gerakan cukup jauh dan dominan vertikal. Dari Cabang hanya ke atas, dari Cek hanya ke bawah;
    // isi yang masih bisa digulir tidak dicuri
    private fun tryStartDrag(ev: MotionEvent): Boolean {
        val dx = ev.x - startX
        val dy = ev.y - startY
        if (abs(dy) > slop && abs(dy) > abs(dx) * 1.3f) {
            val front = getChildAt(if (p >= 0.5f) 1 else 0)
            val okDir = if (p < 0.5f) dy < 0f else dy > 0f
            val scrolls = front != null && front.canScrollVertically(if (dy < 0f) 1 else -1)
            if (okDir && !scrolls) {
                dragging = true
                startY = ev.y
                layers(true)
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
        }
        return false
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (anim != null) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = ev.x
                startY = ev.y
                startP = p
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && tryStartDrag(ev)) return true
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (anim != null) return true
        when (ev.actionMasked) {
            // Kalau tidak ada anak yang memakai sentuhan awal (mis. jari mendarat di area kosong halaman Cek), drum sendiri
            // yang jadi sasarannya, supaya geseran ke bawah tetap sampai ke sini
            MotionEvent.ACTION_DOWN -> {
                startX = ev.x
                startY = ev.y
                startP = p
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) tryStartDrag(ev)
                if (dragging) {
                    val dy = ev.y - startY
                    p = (startP - dy / span()).coerceIn(0f, 1f)
                    updateVis()
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    val open = if (startP < 0.5f) p > 0.33f else p > 0.65f
                    settle(if (open) 1f else 0f, true)
                }
                return true
            }
        }
        return dragging
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (childCount < 2) {
            super.dispatchDraw(canvas)
            return
        }
        val w = width.toFloat()
        val h = height.toFloat()
        // Diam: gambar halaman depan apa adanya
        if (p <= 0.001f) {
            drawChild(canvas, getChildAt(0), drawingTime)
            return
        }
        if (p >= 0.999f) {
            drawChild(canvas, getChildAt(1), drawingTime)
            return
        }
        val rad = h / 2f              // jari-jari drum
        val dist = h * 2.15f          // jarak mata ke layar (perspektif)
        val phi = Math.toRadians((p * 90f).toDouble())
        val cp = cos(phi).toFloat()
        val sp = sin(phi).toFloat()
        // Muka A (Cabang) tampak kalau cos > 0; muka B (Cek) tampak kalau sin > 0
        for (idx in 0..1) {
            val child = getChildAt(idx)
            val vis = if (idx == 0) cp > 0.002f else sp > 0.002f
            if (!vis) continue
            for (k in 0 until 4) {
                // sudut lokal terhadap pusat, urutan (0,0) (w,0) (w,h) (0,h)
                val x = if (k == 0 || k == 3) -w / 2f else w / 2f
                val y = if (k < 2) -h / 2f else h / 2f
                // muka A: (x, y, R). muka B: diputar -90 derajat pada sumbu mendatar: (x, R, -y)
                val y1 = if (idx == 0) y else rad
                val z1 = if (idx == 0) rad else -y
                // putar drum sebesar phi, lalu geser mundur sejauh R
                val y2 = y1 * cp - z1 * sp
                val z2 = y1 * sp + z1 * cp
                val z3 = z2 - rad
                val s = dist / (dist - z3)
                dst[k * 2] = w / 2f + x * s
                dst[k * 2 + 1] = h / 2f + y2 * s
            }
            src[0] = 0f; src[1] = 0f
            src[2] = w; src[3] = 0f
            src[4] = w; src[5] = h
            src[6] = 0f; src[7] = h
            m.reset()
            if (!m.setPolyToPoly(src, 0, dst, 0, 4)) continue
            canvas.save()
            canvas.concat(m)
            drawChild(canvas, child, drawingTime)
            // meredup saat menjauh (efek bola)
            val dark = if (idx == 0) p * 0.55f else (1f - p) * 0.55f
            dim.color = Color.argb((dark * 255f).toInt().coerceIn(0, 255), 0, 0, 0)
            canvas.drawRect(0f, 0f, w, h, dim)
            canvas.restore()
        }
    }
}
