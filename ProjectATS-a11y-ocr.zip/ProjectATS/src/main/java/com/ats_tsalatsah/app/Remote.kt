package com.ats_tsalatsah.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration

// ---------------------------------------------------------------------
// Remote melingkar di halaman Cabang. Tombol putar (Mulai) di pusat, tiga satelit kaca di orbitnya:
// jumlah target server (dengan tombol kecil minus dan plus), nickname otomatis, dan kaitkan email.
// Semua digambar di satu View memakai palet tema yang sama dengan sisa aplikasi. Gerakan: tekan mengecil halus,
// saklar menyala dengan transisi, angka target "membal" saat berubah, kemunculan bertahap, dan cincin pusat
// yang bernapas pelan (hanya saat tab Cabang terlihat).
// ---------------------------------------------------------------------
class RemoteView(ctx: Context, private val pal: Palette) : View(ctx) {

    var onPlay: (() -> Unit)? = null
    var onTarget: (() -> Unit)? = null
    var onNick: (() -> Unit)? = null
    var onKait: (() -> Unit)? = null
    var onStep: ((Int) -> Unit)? = null

    // Tab Cabang sedang terlihat: hanya saat itu cincin pusat bernapas
    var active = true

    // Tampilan berjalan: orbit jadi ruas progres, satelit target menampilkan didapat/target, tombol tengah jadi kotak Hentikan
    private var runMode = false
    private var runDone = 0
    private var runTotal = 0

    fun setRun(on: Boolean, doneN: Int, totalN: Int) {
        if (on == runMode && doneN == runDone && totalN == runTotal) return
        runMode = on
        runDone = doneN
        runTotal = totalN
        kick()
        invalidate()
    }
        set(v) {
            field = v
            kick()
        }

    private val d = ctx.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    // Kotak acuan 328 x 400. Zona: 0 putar, 1 target, 2 nickname, 3 email, 4 minus, 5 plus
    private val refW = 328f
    private val refH = 400f
    private val cx0 = 164f
    private val cy0 = 200f
    private val zx = floatArrayOf(164f, 164f, 68f, 260f, 68f, 260f)
    private val zy = floatArrayOf(200f, 68f, 296f, 296f, 68f, 68f)
    private val zr = floatArrayOf(62f, 46f, 46f, 46f, 18f, 18f)

    private var target = 0
    private var hasTarget = false
    private var nickText = ""
    private var kaitText = ""
    private var nickT = 0f
    private var kaitT = 0f
    private var nickTo = 0f
    private var kaitTo = 0f
    private var nickInit = false
    private var kaitInit = false
    private var popX = 0f
    private var popV = 0f
    private val press = FloatArray(6)
    private val pressTo = FloatArray(6)
    private var pressed = -1
    private var downX = 0f
    private var downY = 0f
    private var entStart = 0L
    private var lastT = 0L
    private var running = false
    private var scaleU = 1f
    private var offX = 0f

    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pth = Path()
    private val rc = RectF()
    private val tfBold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    private val tfMono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
    private val tfMonoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    private val dashOrbit = DashPathEffect(floatArrayOf(3f, 9f), 0f)
    private val ICON = 0xFFE6E9E9.toInt()
    private val glass: Shader
    private val orbG: Shader

    init {
        // Kaca satelit: lapisan putih tipis bergradasi diagonal di atas dasar gelap (seperti mockup)
        glass = LinearGradient(
            -32f, -32f, 32f, 32f,
            intArrayOf(alphaOf(pal.text, 0.12f), alphaOf(pal.text, 0.03f), alphaOf(pal.text, 0.07f)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        // Bola kaca gelap: terang di kiri atas, menggelap ke tepi (di koordinat lokal pusat tombol)
        orbG = RadialGradient(
            -0.24f * 62f, -0.4f * 62f, 1.7f * 62f,
            intArrayOf(0xFF4A5053.toInt(), 0xFF1A1D1F.toInt(), 0xFF080909.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    // ---------- keadaan dari luar ----------

    fun setTarget(n: Int) {
        if (hasTarget && n != target) popV = if (n > target) 3.3f else -3.3f
        target = n
        hasTarget = true
        kick()
        invalidate()
    }

    fun setNick(text: String, on: Boolean) {
        nickText = text
        nickTo = if (on) 1f else 0f
        if (!nickInit) {
            nickInit = true
            nickT = nickTo
        }
        kick()
        invalidate()
    }

    fun setKait(text: String, on: Boolean) {
        kaitText = text
        kaitTo = if (on) 1f else 0f
        if (!kaitInit) {
            kaitInit = true
            kaitT = kaitTo
        }
        kick()
        invalidate()
    }

    // ---------- warna ----------

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    private fun lighter(c: Int, t: Float): Int = mix(c, Color.WHITE, t)

    private fun darker(c: Int, t: Float): Int = mix(c, Color.BLACK, t)

    private fun alphaOf(c: Int, a: Float): Int =
        Color.argb((a.coerceIn(0f, 1f) * 255f).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    // ---------- ukuran ----------

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val ws = MeasureSpec.getSize(widthMeasureSpec)
        val w = if (ws > 0) ws else (refW * d).toInt()
        scaleU = minOf(w / refW, d * 1.15f)
        offX = (w - refW * scaleU) / 2f
        setMeasuredDimension(w, (refH * scaleU).toInt())
    }

    // ---------- gerakan ----------

    private fun kick() {
        if (running || !isAttachedToWindow || !isShown) return
        running = true
        lastT = SystemClock.uptimeMillis()
        postOnAnimation(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            running = false
            if (!isAttachedToWindow || !isShown) return
            val now = SystemClock.uptimeMillis()
            var dt = (now - lastT) / 1000f
            lastT = now
            if (dt > 0.05f) dt = 0.05f
            val busy = step(dt, now)
            invalidate()
            if (busy) {
                running = true
                postOnAnimation(this)
            }
        }
    }

    private fun step(dt: Float, now: Long): Boolean {
        var busy = false
        val kp = (1.0 - Math.exp(-dt / 0.055)).toFloat()
        for (i in 0 until 6) {
            val diff = pressTo[i] - press[i]
            if (Math.abs(diff) > 0.003f) {
                press[i] += diff * kp
                busy = true
            } else {
                press[i] = pressTo[i]
            }
        }
        val ks = (1.0 - Math.exp(-dt / 0.12)).toFloat()
        var df = nickTo - nickT
        if (Math.abs(df) > 0.004f) {
            nickT += df * ks
            busy = true
        } else {
            nickT = nickTo
        }
        df = kaitTo - kaitT
        if (Math.abs(df) > 0.004f) {
            kaitT += df * ks
            busy = true
        } else {
            kaitT = kaitTo
        }
        if (Math.abs(popX) > 0.001f || Math.abs(popV) > 0.01f) {
            popV += (-420f * popX - 22f * popV) * dt
            popX += popV * dt
            busy = true
        } else {
            popX = 0f
            popV = 0f
        }
        if (now - entStart < 420L + 5L * 70L + 60L) busy = true
        return busy
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (entStart == 0L) entStart = SystemClock.uptimeMillis()
        kick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        removeCallbacks(repeat)
        running = false
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) kick()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) kick()
    }

    // ---------- sentuhan ----------

    private fun hit(x: Float, y: Float): Int {
        val rx = (x - offX) / scaleU
        val ry = y / scaleU
        var best = -1
        var bestD = Float.MAX_VALUE
        for (z in 0 until 6) {
            val dx = rx - zx[z]
            val dy = ry - zy[z]
            val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            val lim = zr[z] + (if (z >= 4) 8f else 4f)
            if (dist <= lim && dist < bestD) {
                best = z
                bestD = dist
            }
        }
        return best
    }

    private val repeat = object : Runnable {
        override fun run() {
            if (pressed == 4 || pressed == 5) {
                onStep?.invoke(if (pressed == 4) -1 else 1)
                postDelayed(this, 90)
            }
        }
    }

    private fun setPress(z: Int, v: Float) {
        pressTo[z] = v
        kick()
    }

    private fun cancelPress() {
        removeCallbacks(repeat)
        if (pressed >= 0) pressTo[pressed] = 0f
        pressed = -1
        kick()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val z = hit(e.x, e.y)
                if (z < 0 || (runMode && z != 0)) return false
                pressed = z
                downX = e.x
                downY = e.y
                setPress(z, 1f)
                if (z >= 4) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    onStep?.invoke(if (z == 4) -1 else 1)
                    postDelayed(repeat, 420)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (pressed in 0..3) {
                    if (Math.abs(e.x - downX) > slop * 2 || Math.abs(e.y - downY) > slop * 2) cancelPress()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val z = pressed
                cancelPress()
                when (z) {
                    0 -> onPlay?.invoke()
                    1 -> onTarget?.invoke()
                    2 -> onNick?.invoke()
                    3 -> onKait?.invoke()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelPress()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    // ---------- gambar ----------

    // Kemunculan bertahap: 0..1 dengan perlambatan di ujung
    private fun ent(z: Int, now: Long): Float {
        if (entStart == 0L) return 1f
        val x = ((now - entStart - z * 70L) / 420f).coerceIn(0f, 1f)
        val inv = 1f - x
        return 1f - inv * inv * inv
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (width == 0) return
        val now = SystemClock.uptimeMillis()
        c.save()
        c.translate(offX, 0f)
        c.scale(scaleU, scaleU)
        drawOrbit(c)
        drawSat(c, 1, now)
        drawSat(c, 2, now)
        drawSat(c, 3, now)
        drawMini(c, 4, "\u2212", now)
        drawMini(c, 5, "+", now)
        drawPlay(c, now)
        c.restore()
    }

    // Satu lingkaran orbit putus-putus, tanpa hiasan lain
    private fun drawOrbit(c: Canvas) {
        if (runMode) {
            val n = (if (runTotal > 0) runTotal else 24).coerceIn(1, 60)
            val lit = runDone.coerceIn(0, n)
            val step = 360f / n
            val gap = minOf(6f, step * 0.3f)
            pa.reset()
            pa.isAntiAlias = true
            pa.style = Paint.Style.STROKE
            pa.strokeWidth = 4f
            pa.strokeCap = Paint.Cap.ROUND
            rc.set(cx0 - 132f, cy0 - 132f, cx0 + 132f, cy0 + 132f)
            for (i in 0 until n) {
                pa.color = when {
                    i < lit -> alphaOf(pal.text, 0.92f)
                    i == lit -> alphaOf(pal.text, 0.5f)
                    else -> alphaOf(pal.text, 0.14f)
                }
                c.drawArc(rc, -90f + i * step + gap / 2f, step - gap, false, pa)
            }
            return
        }
        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.STROKE
        pa.strokeWidth = 2f
        pa.pathEffect = dashOrbit
        pa.color = alphaOf(pal.text, 0.13f)
        c.drawCircle(cx0, cy0, 132f, pa)
        pa.pathEffect = null
    }

    // Satelit kaca: dasar tak tembus, lapisan kaca, garis tepi tipis, isi, dan titik status
    private fun drawSat(c: Canvas, z: Int, now: Long) {
        val e = ent(z, now)
        if (e <= 0f) return
        val r = zr[z]
        var sc = (0.72f + 0.28f * e) * (1f - 0.07f * press[z])
        if (z == 1) sc *= 1f + popX
        val on = when (z) {
            2 -> nickT
            3 -> kaitT
            else -> 1f
        }
        c.save()
        c.translate(zx[z], zy[z])
        c.scale(sc, sc)
        // Saat berjalan, satelit nickname dan email meredup
        val dimLayer = runMode && z >= 2
        if (dimLayer) c.saveLayerAlpha(-r - 12f, -r - 12f, r + 12f, r + 12f, 115)

        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.FILL
        pa.color = alphaOf(pal.bg, e)
        c.drawCircle(0f, 0f, r, pa)
        pa.shader = glass
        pa.alpha = (255f * e * (0.7f + 0.3f * on)).toInt().coerceIn(0, 255)
        c.drawCircle(0f, 0f, r, pa)
        pa.shader = null
        pa.style = Paint.Style.STROKE
        pa.strokeWidth = 1f
        pa.color = alphaOf(pal.text, e * (0.12f + 0.08f * on))
        c.drawCircle(0f, 0f, r - 0.5f, pa)

        val ta = e * (0.55f + 0.45f * on)
        tp.reset()
        tp.isAntiAlias = true
        tp.textAlign = Paint.Align.CENTER
        when (z) {
            1 -> {
                if (runMode) {
                    tp.typeface = tfMonoBold
                    tp.color = alphaOf(pal.text, ta)
                    val s = fit(tp, runDone.toString(), 62f, 30f, 16f)
                    val fm = tp.fontMetrics
                    c.drawText(s, 0f, -6f - (fm.ascent + fm.descent) / 2f, tp)
                    tp.typeface = tfMono
                    tp.color = alphaOf(pal.muted, ta)
                    val s2 = fit(tp, "/ " + (if (runTotal > 0) runTotal.toString() else "-"), 62f, 12f, 8f)
                    val fm2 = tp.fontMetrics
                    c.drawText(s2, 0f, 20f - (fm2.ascent + fm2.descent) / 2f, tp)
                } else {
                    tp.typeface = tfMonoBold
                    tp.color = alphaOf(pal.text, ta)
                    val s = fit(tp, target.toString(), 62f, 34f, 18f)
                    val fm = tp.fontMetrics
                    c.drawText(s, 0f, -(fm.ascent + fm.descent) / 2f, tp)
                }
            }
            else -> {
                tp.typeface = tfBold
                tp.color = alphaOf(pal.text, ta)
                tp.textSize = if (z == 2) 22f else 24f
                val fm = tp.fontMetrics
                c.drawText(if (z == 2) "Aa" else "@", 0f, -7f - (fm.ascent + fm.descent) / 2f, tp)
                tp.typeface = tfMono
                tp.color = alphaOf(pal.muted, ta)
                val s = fit(tp, if (z == 2) nickText else kaitText, 66f, 11f, 7f)
                val fm2 = tp.fontMetrics
                c.drawText(s, 0f, 17f - (fm2.ascent + fm2.descent) / 2f, tp)
            }
        }

        if (z >= 2) {
            pa.reset()
            pa.isAntiAlias = true
            pa.style = Paint.Style.FILL
            pa.color = alphaOf(mix(pal.dotOff, pal.dotOn, on), e)
            c.drawCircle(r * 0.64f, -r * 0.68f, 4.5f, pa)
        }
        if (dimLayer) c.restore()
        c.restore()
    }

    // Tombol kecil minus dan plus di sisi satelit target
    private fun drawMini(c: Canvas, z: Int, g: String, now: Long) {
        if (runMode) return
        val e = ent(z, now)
        if (e <= 0f) return
        val sc = (0.72f + 0.28f * e) * (1f - 0.12f * press[z])
        c.save()
        c.translate(zx[z], zy[z])
        c.scale(sc, sc)
        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.FILL
        pa.color = alphaOf(pal.text, 0.10f * press[z] * e)
        c.drawCircle(0f, 0f, 18f, pa)
        pa.style = Paint.Style.STROKE
        pa.strokeWidth = 1f
        pa.color = alphaOf(pal.text, 0.2f * e)
        c.drawCircle(0f, 0f, 17.5f, pa)
        tp.reset()
        tp.isAntiAlias = true
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = tfBold
        tp.textSize = 21f
        tp.color = alphaOf(pal.text, e)
        val fm = tp.fontMetrics
        c.drawText(g, 0f, -(fm.ascent + fm.descent) / 2f, tp)
        c.restore()
    }

    // Tombol mulai: bola kaca gelap dengan kilau di kiri atas dan ikon daya perak yang menyala
    private fun drawPlay(c: Canvas, now: Long) {
        val e = ent(0, now)
        if (e <= 0f) return
        val r = 62f
        c.save()
        c.translate(cx0, cy0)
        val sc = (0.8f + 0.2f * e) * (1f - 0.06f * press[0])
        c.scale(sc, sc)
        // cahaya lembut di sekelilingnya (lingkaran bertingkat, tanpa blur supaya ringan)
        pa.reset()
        pa.isAntiAlias = true
        pa.style = Paint.Style.FILL
        pa.color = alphaOf(ICON, e * 0.05f)
        c.drawCircle(0f, 0f, r + 11f, pa)
        pa.color = alphaOf(ICON, e * 0.07f)
        c.drawCircle(0f, 0f, r + 6f, pa)
        pa.color = alphaOf(ICON, e * 0.09f)
        c.drawCircle(0f, 0f, r + 2.5f, pa)
        // bola
        pa.shader = orbG
        pa.alpha = (255f * e).toInt().coerceIn(0, 255)
        c.drawCircle(0f, 0f, r, pa)
        pa.shader = null
        pa.style = Paint.Style.STROKE
        pa.strokeWidth = 1f
        pa.color = alphaOf(Color.WHITE, e * 0.28f)
        c.drawCircle(0f, 0f, r - 0.5f, pa)
        pa.color = alphaOf(Color.WHITE, e * 0.14f)
        c.drawCircle(0f, 0f, r * 0.8f, pa)
        // kilau di kiri atas; makin terang sedikit saat ditekan
        pa.style = Paint.Style.FILL
        pa.color = alphaOf(Color.WHITE, e * (0.20f + 0.08f * press[0]))
        c.save()
        c.rotate(-28f, -0.26f * r, -0.48f * r)
        rc.set(-0.74f * r, -0.70f * r, 0.22f * r, -0.26f * r)
        c.drawOval(rc, pa)
        c.restore()
        if (runMode) {
            // Saat berjalan: kotak Hentikan
            pa.style = Paint.Style.FILL
            pa.color = alphaOf(ICON, e)
            rc.set(-16f, -16f, 16f, 16f)
            c.drawRoundRect(rc, 8f, 8f, pa)
        } else {
            // ikon daya: busur hampir penuh yang terbuka di atas, dengan garis tegak di celahnya
            pa.style = Paint.Style.STROKE
            pa.strokeWidth = 8f
            pa.strokeCap = Paint.Cap.ROUND
            pa.color = alphaOf(ICON, e)
            rc.set(-25f, -22f, 25f, 28f)
            c.drawArc(rc, 305f, 290f, false, pa)
            c.drawLine(0f, -27f, 0f, -3f, pa)
        }
        c.restore()
    }

    // Kecilkan huruf sampai muat, lalu potong dengan titik tiga kalau masih kepanjangan
    private fun fit(p: Paint, s: String, maxW: Float, start: Float, min: Float): String {
        var size = start
        p.textSize = size
        while (p.measureText(s) > maxW && size > min) {
            size -= 0.5f
            p.textSize = size
        }
        if (p.measureText(s) <= maxW) return s
        var t = s
        while (t.length > 1 && p.measureText(t + "\u2026") > maxW) t = t.substring(0, t.length - 1)
        return t + "\u2026"
    }
}

// Ikon kaca pembesar kecil untuk kolom pencarian
class SearchIconDrawable(private val color: Int, private val sizePx: Int) : Drawable() {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun getIntrinsicWidth(): Int = sizePx

    override fun getIntrinsicHeight(): Int = sizePx

    override fun draw(c: Canvas) {
        val s = bounds.width().toFloat()
        val x = bounds.left.toFloat()
        val y = bounds.top.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeWidth = s * 0.11f
        p.strokeCap = Paint.Cap.ROUND
        p.color = color
        c.drawCircle(x + s * 0.43f, y + s * 0.43f, s * 0.27f, p)
        c.drawLine(x + s * 0.63f, y + s * 0.63f, x + s * 0.86f, y + s * 0.86f, p)
    }

    override fun setAlpha(alpha: Int) {
        p.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        p.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
