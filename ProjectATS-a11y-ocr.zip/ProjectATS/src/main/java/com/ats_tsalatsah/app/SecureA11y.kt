package com.ats_tsalatsah.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings

// Menyalakan layanan Aksesibilitas aplikasi ini lewat Settings.Secure (Jalur A).
// Butuh izin WRITE_SECURE_SETTINGS yang diberikan SATU KALI lewat ADB (pm grant).
// Android mematikan layanan itu tiap aplikasi di-force stop, jadi ensure() dipanggil ulang
// tiap aplikasi dibuka dan sebelum proses Mulai.
object SecureA11y {

    const val PERM = "android.permission.WRITE_SECURE_SETTINGS"

    // Waktu terakhir pengaturan diubah oleh ensure() (untuk tahu apakah layanan sedang disambungkan)
    @Volatile private var lastChangeAt = 0L

    fun granted(ctx: Context): Boolean =
        ctx.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    fun grantCommand(ctx: Context): String = "pm grant ${ctx.packageName} $PERM"

    // true = baru mengubah pengaturan. false = tidak ada yang diubah (sudah aktif, atau izin belum ada).
    fun ensure(ctx: Context): Boolean {
        if (!granted(ctx)) return false
        return try {
            val cn = ComponentName(ctx, OcrA11yService::class.java)
            val full = cn.flattenToString()
            val short = cn.flattenToShortString()
            val cr = ctx.contentResolver

            val cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val parts = cur.split(':').filter { it.isNotBlank() }
            val listed = parts.any { it.equals(full, true) || it.equals(short, true) }
            val enabled = Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1

            if (listed && enabled) return false

            if (!listed) {
                // Layanan aplikasi lain dipertahankan; punya kita ditambahkan di belakang
                val nv = if (parts.isEmpty()) full else parts.joinToString(":") + ":" + full
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, nv)
            }
            if (!enabled) {
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            }
            lastChangeAt = SystemClock.uptimeMillis()
            true
        } catch (e: Throwable) {
            false
        }
    }

    // Untuk tombol Mulai. PANGGIL DARI THREAD LATAR (menunggu).
    // Kalau layanan belum tersambung: ensure(), lalu tunggu tersambung maksimal maxMs.
    // Tersambung lebih cepat = langsung lanjut. Hasil: true kalau layanan tersambung.
    fun ensureAndWait(ctx: Context, maxMs: Long, log: (String) -> Unit): Boolean {
        if (OcrA11yService.isRunning()) return true
        if (!granted(ctx)) return false
        val changed = ensure(ctx)
        // Menunggu hanya kalau pengaturan baru diubah (kini atau beberapa detik lalu)
        val recent = changed || (SystemClock.uptimeMillis() - lastChangeAt) < maxMs + 3000L
        if (!recent) return false

        val t0 = SystemClock.uptimeMillis()
        while (SystemClock.uptimeMillis() - t0 < maxMs) {
            if (OcrA11yService.isRunning()) {
                log("Aksesibilitas tersambung ${SystemClock.uptimeMillis() - t0} ms setelah dinyalakan otomatis")
                return true
            }
            try {
                Thread.sleep(100)
            } catch (e: InterruptedException) {
                return false
            }
        }
        val ok = OcrA11yService.isRunning()
        if (!ok) log("Aksesibilitas belum tersambung setelah ${maxMs / 1000} detik")
        return ok
    }
}
