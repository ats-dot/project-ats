package com.ats_tsalatsah.app

import android.content.Context
import android.graphics.Rect
import android.os.SystemClock
import kotlin.math.abs

// Pengaturan geser daftar server (halaman Character List). Nilai bawaan sama dengan Klaim & Kirim; diatur sendiri di Setelan
object SwipeCfg {
    private const val PREFS = "ats_swipe"
    private var ctx: Context? = null

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    class Vals(
        val fastMs: Int, val fastStart: Int, val fastEnd: Int,
        val slowMs: Int, val slowStart: Int, val slowEnd: Int,
        val backMs: Int, val backStart: Int, val backEnd: Int,
        val x: Int, val count: Int
    )

    private val DEF = mapOf(
        "fm" to 50, "fs" to 55, "fe" to 10,
        "sm" to 170, "ss" to 58, "se" to 45,
        "bm" to 200, "bs" to 45, "be" to 58,
        "x" to 77, "n" to 20
    )

    fun def(key: String): Int = DEF[key] ?: 0

    fun get(key: String): Int {
        val c = ctx ?: return def(key)
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(key, def(key))
    }

    fun set(key: String, v: Int) {
        val c = ctx ?: return
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(key, v.coerceIn(0, 100000)).apply()
    }

    fun reset() {
        val c = ctx ?: return
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun vals(): Vals = Vals(
        get("fm"), get("fs"), get("fe"),
        get("sm"), get("ss"), get("se"),
        get("bm"), get("bs"), get("be"),
        get("x"), get("n")
    )
}

// Membaca dan menggeser daftar server di halaman "Character List"
class ServerList(
    private val svc: OcrA11yService,
    private val stop: () -> Boolean,
    private val log: (String) -> Unit
) {
    class Row(val num: Int, val box: Rect)
    class View(val rows: List<Row>, val isList: Boolean, val w: Int, val h: Int)

    sealed class Loc {
        class Exists(val row: Row, val w: Int, val h: Int) : Loc()
        object Missing : Loc()
        class Lost(val why: String) : Loc()
        object Stopped : Loc()
    }

    companion object {
        // Panel daftar (pecahan layar). Baris "All Servers" mulai sekitar 40% tinggi; baris yang terpotong di bawah
        // (lewat 69%) tidak dihitung supaya hanya baris yang utuh yang dipakai
        private val LIST_AREA = Area("daftar karakter", 0.14f, 0.12f, 0.86f, 0.76f)
        private const val ROW_MIN_Y = 0.37f
        private const val ROW_MAX_Y = 0.69f
        private val RX = Regex("\\d{5,6}")
        private const val ERR_NOTICE = "NOTICE"
        private const val SETTLE_FAST_MS = 700L
        private const val SETTLE_SLOW_MS = 450L
    }

    private var fastUsed = false
    private var lastSwipeMs = 0L
    private var lastSettleMs = 0L

    // Rincian pembacaan terakhir (untuk log uji): screenshot, menunggu jarak minimal, OCR, dan berapa kali membaca
    private var accShot = 0L
    private var accWait = 0L
    private var accOcr = 0L
    private var accTries = 0
    private var accNoList = 0

    private fun fix(token: String): Int? {
        // "s57007" kadang terbaca "557007": huruf s dibaca angka 5
        val t = if (token.length == 6 && token[0] == '5') token.substring(1) else token
        val n = t.toIntOrNull() ?: return null
        return if (n in 50000..59999) n else null
    }

    fun read(): View? {
        val shot = svc.capture(1500L)
        accShot += shot.ms
        accWait += shot.waitMs
        accTries++
        val b = shot.bmp ?: return null
        val w = b.width
        val h = b.height
        val r = ScreenOcr.read(b, LIST_AREA, 0.8f)
        accOcr += r.ms
        if (!r.timedOut) b.recycle()
        if (r.error != null) return null
        val isList = listOf("All Servers", "Current Server", "Semua Server", "Server Saat Ini").any { TextMatch.matches(r.text, it) }
        val rows = ArrayList<Row>()
        for (ln in r.lines) {
            val box = ln.box ?: continue
            val cy = box.exactCenterY()
            if (cy < ROW_MIN_Y * h || cy > ROW_MAX_Y * h) continue
            for (m in RX.findAll(ln.text)) {
                val n = fix(m.value) ?: continue
                if (rows.none { it.num == n }) rows.add(Row(n, box))
            }
        }
        rows.sortBy { it.box.exactCenterY() }
        return View(rows, isList, w, h)
    }

    // Baca sampai halaman daftar terlihat dan ada baris server (maks limitMs)
    fun readList(limitMs: Long): View? {
        accShot = 0L
        accWait = 0L
        accOcr = 0L
        accTries = 0
        accNoList = 0
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val v = read() ?: continue
            if (v.isList && v.rows.isNotEmpty()) return v
            accNoList++
        }
        return null
    }

    private fun readDetail(): String =
        "screenshot " + accShot + " + tunggu jarak " + accWait + " + OCR " + accOcr + ", " + accTries + "x baca" +
            (if (accNoList > 0) ", " + accNoList + " ditolak (bukan daftar atau tanpa baris)" else "")

    private fun sig(v: View): String = v.rows.joinToString(",") { it.num.toString() }

    private var stepNo = 0

    // Catatan satu geseran di pencarian nyata (aturan 1 dan 2), format sama dengan uji: jenis, layar, server baru dan lama,
    // serta rincian waktu (geser + jeda tetap + baca [screenshot + tunggu jarak + OCR])
    private fun logSwipe(kind: String, tStep: Long, readMs: Long, prev: View, cur: View) {
        stepNo++
        val prevSet = prev.rows.map { it.num }.toSet()
        val newCount = cur.rows.count { !prevSet.contains(it.num) }
        val oldCount = cur.rows.count { prevSet.contains(it.num) }
        log("Geseran " + stepNo + " (" + kind + "): layar " + rng(cur) + ", " + newCount + " server baru, " + oldCount + " lama" +
            (if (oldCount == 0) " MELOMPAT" else "") + ". " + (SystemClock.uptimeMillis() - tStep) + " ms (geser " + lastSwipeMs +
            " + jeda tetap " + lastSettleMs + " + baca " + readMs + " [" + readDetail() + "])")
    }

    // Geser isi daftar KE BAWAH (jari bergerak naik). Geseran cepat dipakai sekali per daftar, sisanya pelan
    private fun swipeDown(w: Int, h: Int, allowFast: Boolean) {
        val c = SwipeCfg.vals()
        val fast = allowFast && !fastUsed
        if (fast) fastUsed = true
        val x = c.x / 100f * w
        val y1 = (if (fast) c.fastStart else c.slowStart) / 100f * h
        val y2 = (if (fast) c.fastEnd else c.slowEnd) / 100f * h
        val ms = (if (fast) c.fastMs else c.slowMs).toLong()
        val t0 = SystemClock.uptimeMillis()
        svc.swipe(x, y1, x, y2, ms)
        lastSwipeMs = SystemClock.uptimeMillis() - t0
        lastSettleMs = if (fast) SETTLE_FAST_MS else SETTLE_SLOW_MS
        sleep(lastSettleMs)
    }

    // Geser balik: isi daftar naik ke atas (jari bergerak turun). Jaga-jaga kalau geseran cepat pertama kelewatan
    private fun swipeBack(w: Int, h: Int) {
        val c = SwipeCfg.vals()
        val x = c.x / 100f * w
        val t0 = SystemClock.uptimeMillis()
        svc.swipe(x, c.backStart / 100f * h, x, c.backEnd / 100f * h, c.backMs.toLong())
        lastSwipeMs = SystemClock.uptimeMillis() - t0
        lastSettleMs = SETTLE_SLOW_MS
        sleep(lastSettleMs)
    }

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    // Cari baris TEPAT di bawah patokan (server apk sebelumnya; ref = 0 untuk apk pertama = baris paling atas).
    // Karena daftar urut naik, "baris tepat di bawah patokan" = baris pertama yang nomornya lebih besar dari ref;
    // cara ini tetap benar kalau patokan sedang jadi "Current Server" (tidak ada di All Servers).
    //  - baris itu >= next (server apk sesudahnya)  -> server yang dicari tidak ada (Missing)
    //  - selain itu                                  -> itu server yang belum dinamai (Exists)
    fun locateBelow(ref: Int, next: Int?): Loc {
        fastUsed = false
        stepNo = 0
        val tAll = SystemClock.uptimeMillis()
        var v = readList(8000L) ?: return Loc.Lost("daftar karakter tidak terbaca")
        log("Daftar terbaca dalam " + (SystemClock.uptimeMillis() - tAll) + " ms (" + readDetail() + "): " + rng(v))
        var atTop = true
        var same = 0
        var backs = 0
        for (step in 0 until 100) {
            if (stop()) return Loc.Stopped
            val rows = v.rows
            val c = rows.indexOfFirst { it.num > ref }
            if (c >= 0) {
                if (c > 0 || atTop) {
                    val below = rows[c]
                    log("Baris tepat di bawah patokan " + (if (ref > 0) "s$ref" else "(atas)") + ": s" + below.num + ", sesudah " + stepNo +
                        " geseran, " + (SystemClock.uptimeMillis() - tAll) + " ms")
                    return if (next != null && below.num >= next) Loc.Missing else Loc.Exists(below, v.w, v.h)
                }
                // Baris pertama yang terlihat sudah lebih besar dari patokan, tapi mungkin ada baris di atasnya yang tersembunyi
                backs++
                if (backs > 10) return Loc.Lost("geser balik tidak menemukan patokan $ref")
                val before = sig(v)
                val tStepB = SystemClock.uptimeMillis()
                swipeBack(v.w, v.h)
                val tReadB = SystemClock.uptimeMillis()
                val v2 = readList(5000L) ?: return Loc.Lost("daftar tidak terbaca setelah geser balik")
                logSwipe("balik", tStepB, SystemClock.uptimeMillis() - tReadB, v, v2)
                if (sig(v2) == before) atTop = true
                v = v2
                continue
            }
            // Semua baris yang terlihat <= patokan: geser ke bawah
            val before = sig(v)
            val kindD = if (!fastUsed) "cepat" else "pelan"
            val tStepD = SystemClock.uptimeMillis()
            swipeDown(v.w, v.h, true)
            atTop = false
            val tReadD = SystemClock.uptimeMillis()
            val v2 = readList(5000L) ?: return Loc.Lost("daftar tidak terbaca setelah geser")
            logSwipe(kindD, tStepD, SystemClock.uptimeMillis() - tReadD, v, v2)
            if (sig(v2) == before) {
                same++
                if (same >= 2) return Loc.Missing
            } else {
                same = 0
            }
            v = v2
        }
        return Loc.Lost("batas geseran habis")
    }

    // Cari baris dengan nomor tertentu (aturan Select a hero). Arah geser ditentukan dari nomor baris yang terlihat
    fun locateNumber(n: Int): Loc {
        fastUsed = false
        stepNo = 0
        val tAll = SystemClock.uptimeMillis()
        var v = readList(8000L) ?: return Loc.Lost("daftar karakter tidak terbaca")
        log("Daftar terbaca dalam " + (SystemClock.uptimeMillis() - tAll) + " ms (" + readDetail() + "): " + rng(v))
        var same = 0
        var backs = 0
        for (step in 0 until 100) {
            if (stop()) return Loc.Stopped
            val rows = v.rows
            val hit = rows.firstOrNull { it.num == n }
            if (hit != null) {
                log("Server s$n terlihat sesudah " + stepNo + " geseran, " + (SystemClock.uptimeMillis() - tAll) + " ms")
                return Loc.Exists(hit, v.w, v.h)
            }
            val lo = rows.first().num
            val hi = rows.last().num
            if (n > lo && n < hi) return Loc.Lost("server $n tidak ada di daftar")
            val before = sig(v)
            val kindN: String
            val tStepN = SystemClock.uptimeMillis()
            if (n < lo) {
                backs++
                if (backs > 12) return Loc.Lost("geser balik tidak menemukan server $n")
                kindN = "balik"
                swipeBack(v.w, v.h)
            } else {
                kindN = if (!fastUsed) "cepat" else "pelan"
                swipeDown(v.w, v.h, true)
            }
            val tReadN = SystemClock.uptimeMillis()
            val v2 = readList(5000L) ?: return Loc.Lost("daftar tidak terbaca setelah geser")
            logSwipe(kindN, tStepN, SystemClock.uptimeMillis() - tReadN, v, v2)
            if (sig(v2) == before) {
                same++
                if (same >= 2) return Loc.Lost("server $n tidak ada di daftar (ujung daftar)")
            } else {
                same = 0
            }
            v = v2
        }
        return Loc.Lost("batas geseran habis")
    }

    private val OKAY_PROBES = listOf(
        0.46f to 0.700f, 0.50f to 0.7139f, 0.54f to 0.725f, 0.47f to 0.725f, 0.53f to 0.700f
    )

    // Okay emas: selisih merah-biru positif besar (abu-abu/memuat: negatif)
    private fun okayGold(b: android.graphics.Bitmap): Boolean {
        var sum = 0
        for ((x, y) in OKAY_PROBES) {
            val c = PixelCheck.at(b, x, y)
            sum += android.graphics.Color.red(c) - android.graphics.Color.blue(c)
        }
        return sum / OKAY_PROBES.size >= 20
    }

    private val NOTICE_KEYS = listOf("Server switched", "restart the game", "System Notice", "Server telah diganti")

    private fun noticeVisible(): Boolean {
        val sh = svc.capture(1500L)
        val bb = sh.bmp ?: return false
        val rr = ScreenOcr.read(bb, Area.FULL, 0.6f)
        if (!rr.timedOut) bb.recycle()
        return rr.error == null && NOTICE_KEYS.any { TextMatch.matches(rr.text, it) }
    }

    // Pilih baris, ketuk Switch Server (emas), tunggu System Notice, lalu ketuk Okay begitu sudah coklat keemasan.
    // Kalau System Notice tidak muncul dalam beberapa detik, ketukan baris dan Switch Server kemungkinan tidak diterima:
    // diulang (maks 3 kali). null = berhasil (Okay diketuk), selain itu = alasan gagal
    fun selectAndSwitch(row: Row): String? {
        for (attempt in 0 until 3) {
            if (stop()) return "dihentikan"
            // System Notice yang muncul terlambat: langsung ke Okay, jangan memilih baris lagi
            if (attempt > 0 && noticeVisible()) return awaitNoticeAndOkay(3000L)
            var r = row
            for (k in 0 until 3) {
                val v = read() ?: continue
                val m = v.rows.firstOrNull { it.num == row.num } ?: return "baris server ${row.num} hilang sebelum diketuk"
                val stable = abs(m.box.exactCenterY() - r.box.exactCenterY()) <= 0.012f * v.h
                r = m
                if (stable) break
            }
            val ok1 = svc.tap(r.box.exactCenterX(), r.box.exactCenterY())
            log("ketuk baris server ${row.num}: " + (if (ok1) "OK" else "GAGAL"))
            sleep(300L)
            val e0 = tapSwitch()
            if (e0 != null) return e0
            val e = awaitNoticeAndOkay(if (attempt < 2) 3500L else 10000L)
            if (e != ERR_NOTICE) return e
            log("System Notice belum muncul, ulangi memilih baris dan Switch Server (${attempt + 1})")
        }
        return "System Notice (Server switched) tidak muncul dalam 3 percobaan"
    }

    // Ketuk tombol Switch Server (posisi dari OCR, cadangan 50% lebar dan 79,7% tinggi)
    private fun tapSwitch(): String? {
        val s = svc.capture(1500L)
        val b = s.bmp ?: return "layar tidak terbaca saat mencari tombol Switch Server"
        val w = b.width
        val h = b.height
        val rr = ScreenOcr.read(b, Area("tombol switch", 0.35f, 0.72f, 0.65f, 0.88f), 0.8f)
        if (!rr.timedOut) b.recycle()
        val box = if (rr.error == null) TextMatch.find(rr, listOf("Switch Server", "Ganti Server"))?.second?.box else null
        val tapX = box?.exactCenterX() ?: (0.5f * w)
        val tapY = box?.exactCenterY() ?: (0.797f * h)
        val ok2 = svc.tap(tapX, tapY)
        log("ketuk Switch Server: " + (if (ok2) "OK" else "GAGAL"))
        return null
    }

    // Tunggu System Notice ("Server switched. Please restart the game!") lalu ketuk Okay yang sudah emas.
    // ERR_NOTICE = System Notice tidak muncul dalam noticeMs (boleh diulang)
    private fun awaitNoticeAndOkay(noticeMs: Long): String? {
        val end = SystemClock.uptimeMillis() + noticeMs
        var notice = false
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val sh = svc.capture(1500L)
            val bb = sh.bmp ?: continue
            val rr = ScreenOcr.read(bb, Area.FULL, 0.6f)
            if (!rr.timedOut) bb.recycle()
            if (rr.error != null) continue
            if (NOTICE_KEYS.any { TextMatch.matches(rr.text, it) }) {
                notice = true
                break
            }
        }
        if (!notice) return ERR_NOTICE

        // Okay diketuk begitu sudah coklat keemasan (abu-abu = masih memuat)
        val end2 = SystemClock.uptimeMillis() + 15000L
        while (!stop() && SystemClock.uptimeMillis() < end2) {
            val sh = svc.capture(1500L)
            val bb = sh.bmp ?: continue
            val gold = okayGold(bb)
            val bw = bb.width
            val bh = bb.height
            bb.recycle()
            if (gold) {
                val ok3 = svc.tap(0.5f * bw, 0.7139f * bh)
                log("ketuk Okay (sudah emas): " + (if (ok3) "OK" else "GAGAL"))
                return null
            }
        }
        return "tombol Okay belum berwarna emas dalam 15 detik"
    }

    private fun rng(v: View): String {
        val k = v.rows.map { "s" + it.num }
        return if (k.isEmpty()) "kosong" else if (k.size == 1) k[0] else k[0] + " sampai " + k[k.size - 1] + " (" + k.size + " baris)"
    }

    // Uji geser: dari baris paling atas sampai ujung bawah. Tiap geseran dicatat ke log (seperti Klaim & Kirim) lengkap dengan
    // rincian waktunya: lama gerakan jari, jeda tetap sesudahnya, dan lama membaca daftar (screenshot + OCR).
    // Hasil akhir berupa teks ringkas untuk ditampilkan
    fun test(expected: Int): String {
        val t0 = SystemClock.uptimeMillis()
        val c = SwipeCfg.vals()
        log("Uji geser dimulai. Jumlah server (uji) " + expected + ". Cepat " + c.fastMs + " ms " + c.fastStart + "% ke " + c.fastEnd +
            "%, pelan " + c.slowMs + " ms " + c.slowStart + "% ke " + c.slowEnd + "%, balik " + c.backMs + " ms " + c.backStart + "% ke " + c.backEnd +
            "%, posisi X " + c.x + "%. Jeda tetap sesudah geser: cepat " + SETTLE_FAST_MS + " ms, pelan " + SETTLE_SLOW_MS + " ms")
        val tr0 = SystemClock.uptimeMillis()
        var v = readList(6000L) ?: return "Daftar karakter tidak terbaca. Buka halaman Character List di game dulu."
        log("Daftar terbaca dalam " + (SystemClock.uptimeMillis() - tr0) + " ms (" + readDetail() + "): " + rng(v))
        fastUsed = false
        val seen = LinkedHashSet<Int>()
        v.rows.forEach { seen.add(it.num) }
        val goal = maxOf(1, expected - 1)
        var swipes = 0
        var same = 0
        var jumps = 0
        var sumSwipe = 0L
        var sumSettle = 0L
        var sumRead = 0L
        while (swipes < 120 && !stop() && seen.size < goal) {
            val tStep = SystemClock.uptimeMillis()
            val before = sig(v)
            val beforeSet = v.rows.map { it.num }.toSet()
            val seenBefore = HashSet(seen)
            val fast = !fastUsed
            swipeDown(v.w, v.h, true)
            swipes++
            val tRead = SystemClock.uptimeMillis()
            val v2 = readList(4000L)
            val readMs = SystemClock.uptimeMillis() - tRead
            if (v2 == null) {
                log("Geseran " + swipes + " (" + (if (fast) "cepat" else "pelan") + "): daftar tidak terbaca setelah geser (" + readMs + " ms)")
                break
            }
            v2.rows.forEach { seen.add(it.num) }
            val newCount = v2.rows.count { !seenBefore.contains(it.num) }
            val oldCount = v2.rows.count { beforeSet.contains(it.num) }
            val jumped = oldCount == 0
            if (jumped) jumps++
            sumSwipe += lastSwipeMs
            sumSettle += lastSettleMs
            sumRead += readMs
            log("Geseran " + swipes + " (" + (if (fast) "cepat" else "pelan") + "): layar " + rng(v2) + ", " + newCount + " server baru, " + oldCount + " lama" +
                (if (jumped) " MELOMPAT" else "") + ". " + (SystemClock.uptimeMillis() - tStep) + " ms (geser " + lastSwipeMs +
                " + jeda tetap " + lastSettleMs + " + baca " + readMs + " [" + readDetail() + "]), terlihat " + seen.size + " dari " + goal)
            if (sig(v2) == before) {
                same++
                log("  layar tidak berubah (" + same + " kali)")
                if (same >= 2) break
            } else {
                same = 0
            }
            v = v2
        }
        val total = SystemClock.uptimeMillis() - t0
        val sec = total / 1000L
        val avg = if (swipes > 0) (sumSwipe + sumSettle + sumRead) / swipes else 0L
        val head = if (seen.size >= goal) "Uji geser: semua server terlihat" else "Uji geser: belum semua terlihat"
        val res = head + " (" + seen.size + " dari " + goal + "), " + swipes + " geseran, " + jumps + " kali melompat, " + sec + " detik"
        if (swipes > 0) {
            log("Rata-rata per geseran " + avg + " ms: geser " + (sumSwipe / swipes) + " + jeda tetap " + (sumSettle / swipes) + " + baca " + (sumRead / swipes) +
                ". Jeda tetap = " + (if (avg > 0) (sumSettle * 100 / (sumSwipe + sumSettle + sumRead)) else 0) + "% dari waktu geser")
        }
        log(res)
        return res
    }
}
