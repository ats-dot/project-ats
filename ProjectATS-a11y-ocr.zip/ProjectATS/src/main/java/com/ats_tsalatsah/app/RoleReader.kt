package com.ats_tsalatsah.app

import android.os.SystemClock

// Membaca ID akun dari tulisan "Role:2287584109" di pojok kanan atas layar loading game.
// ID sama untuk semua apk dalam satu sesi, jadi cukup dibaca sekali.
object RoleReader {

    private val AREA = Area("role", 0.5f, 0.0f, 1.0f, 0.1f)
    private val RX = Regex("Role\\s*[:;]?\\s*(\\d{9,11})")

    // Baca berulang sampai batas waktu. ID baru diterima kalau dua bacaan berturut-turut sama.
    // Hasil: ID, atau null kalau tidak ketemu.
    fun readUntil(deadline: Long, stop: () -> Boolean): String? {
        var prev: String? = null
        while (!stop() && SystemClock.uptimeMillis() < deadline - 100L) {
            val svc = OcrA11yService.instance ?: return null
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val r = ScreenOcr.read(b, AREA, 1.0f)
            if (!r.timedOut) b.recycle()
            if (r.error != null) continue
            val id = RX.find(r.text.replace('\n', ' '))?.groupValues?.get(1)
            if (id != null) {
                if (id == prev) return id
                prev = id
            } else {
                prev = null
            }
        }
        return null
    }
}
