package com.ats_tsalatsah.app

import android.graphics.Bitmap
import android.os.SystemClock

// Membaca ID akun dari tulisan "Role:2287584109" di pojok kanan atas layar loading game.
// ID sama untuk semua apk dalam satu sesi, jadi cukup dibaca sekali.
object RoleReader {

    private val AREA = Area("role", 0.5f, 0.0f, 1.0f, 0.1f)
    private val AREA_ALL = Area("role2", 0f, 0f, 1f, 1f)
    private val RX = Regex("Role\\s*[:;]?\\s*(\\d{9,11})")

    // Catatan untuk log kalau kedua skala OCR tidak sepakat sampai batas waktu (kosong kalau semuanya normal)
    @Volatile
    var lastNote: String = ""

    private fun idFrom(text: String): String? =
        RX.find(text.replace('\n', ' '))?.groupValues?.get(1)

    // Baca berulang sampai batas waktu. Tiap bacaan dilakukan di DUA skala gambar (biasa dan 2x lebih besar) dan ID baru
    // diterima kalau kedua skala menghasilkan angka yang sama, di dua bacaan berturut-turut. Ini mencegah satu angka yang
    // hilang karena salah baca (misal 2289920947 terbaca 228920947). ID 9 digit tetap diterima kalau kedua skala sepakat.
    // Kalau kedua skala terus berbeda sampai batas waktu, dipakai yang lebih panjang (salah baca biasanya menghilangkan angka)
    // Hasil: ID, atau null kalau tidak ketemu.
    fun readUntil(deadline: Long, stop: () -> Boolean): String? {
        lastNote = ""
        var prev: String? = null
        var best: String? = null
        var note = ""
        while (!stop() && SystemClock.uptimeMillis() < deadline - 100L) {
            val svc = OcrA11yService.instance ?: return null
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val r1 = ScreenOcr.read(b, AREA, 1.0f)
            val id1 = if (r1.error == null) idFrom(r1.text) else null
            // skala 2x: potong area ID lalu perbesar, dibaca sebagai gambar penuh
            var big: Bitmap? = null
            var id2: String? = null
            var bigTimedOut = false
            try {
                val rect = AREA.toRect(b.width, b.height)
                val crop = Bitmap.createBitmap(b, rect.left, rect.top, rect.width(), rect.height())
                big = Bitmap.createScaledBitmap(crop, crop.width * 2, crop.height * 2, true)
                if (crop !== b && crop !== big) crop.recycle()
                val r2 = ScreenOcr.read(big, AREA_ALL, 1.0f)
                bigTimedOut = r2.timedOut
                if (r2.error == null) id2 = idFrom(r2.text)
            } catch (e: Throwable) {
            }
            if (!bigTimedOut) big?.recycle()
            if (!r1.timedOut) b.recycle()
            if (id1 == null && id2 == null) {
                prev = null
                continue
            }
            if (id1 != null && id2 != null && id1 == id2) {
                if (id1 == prev) {
                    lastNote = ""
                    return id1
                }
                prev = id1
                continue
            }
            // dua skala tidak sepakat (atau salah satunya kosong): simpan yang lebih panjang
            prev = null
            val longer = listOfNotNull(id1, id2).maxByOrNull { it.length }
            if (longer != null && (best == null || longer.length >= best.length)) best = longer
            note = "skala biasa=" + (id1 ?: "kosong") + ", skala 2x=" + (id2 ?: "kosong")
        }
        if (best != null) {
            lastNote = "Dua skala OCR tidak sepakat sampai batas waktu ($note), memakai yang lebih panjang: $best"
            return best
        }
        return null
    }
}
