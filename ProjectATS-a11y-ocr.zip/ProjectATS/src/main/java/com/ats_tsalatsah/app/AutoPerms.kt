package com.ats_tsalatsah.app

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

// Memberi izin yang masih kurang secara otomatis lewat Shizuku, tanpa dialog dan tanpa log.
// Shizuku sendiri tetap harus diizinkan manual. Aksesibilitas dinyalakan oleh SecureA11y
// setelah izin WRITE_SECURE_SETTINGS tersedia.
object AutoPerms {

    private const val NOTIF = "android.permission.POST_NOTIFICATIONS"

    // Hasil percobaan izin "Tampil di atas aplikasi", ditampilkan di Setelan kalau tetap gagal
    @Volatile var overlayTried = 0
    @Volatile var overlayError = ""

    fun notifOk(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(NOTIF) == PackageManager.PERMISSION_GRANTED

    fun overlayOk(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun batteryOk(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (e: Throwable) {
        false
    }

    fun hasMissing(ctx: Context): Boolean =
        !SecureA11y.granted(ctx) || !notifOk(ctx) || !overlayOk(ctx) || !batteryOk(ctx)

    // Jalankan perintah untuk tiap izin yang masih kurang. Hasil tidak dicatat di log.
    @Synchronized
    fun run(ctx: Context) {
        if (!ShizukuHelper.hasPermission()) return
        val pkg = ctx.packageName
        try {
            if (!SecureA11y.granted(ctx)) {
                ShizukuHelper.exec(arrayOf("pm", "grant", pkg, SecureA11y.PERM), 6000L)
            }
            if (!notifOk(ctx)) {
                ShizukuHelper.exec(arrayOf("pm", "grant", pkg, NOTIF), 6000L)
            }
            if (!overlayOk(ctx)) {
                overlayTried++
                val msgs = ArrayList<String>()
                var anyFailed = false
                val cmds = listOf(
                    arrayOf("appops", "set", pkg, "SYSTEM_ALERT_WINDOW", "allow"),
                    arrayOf("pm", "grant", pkg, "android.permission.SYSTEM_ALERT_WINDOW"),
                    arrayOf("cmd", "appops", "set", "--user", "0", pkg, "SYSTEM_ALERT_WINDOW", "allow")
                )
                for (c in cmds) {
                    val r = ShizukuHelper.exec(c, 6000L)
                    if (!r.first) {
                        anyFailed = true
                        msgs.add(c[0] + ": " + r.second.take(70))
                    }
                    try {
                        Thread.sleep(250)
                    } catch (e: InterruptedException) {
                    }
                    if (overlayOk(ctx)) break
                }
                overlayError = if (overlayOk(ctx)) {
                    ""
                } else if (anyFailed) {
                    msgs.joinToString("; ").take(160)
                } else {
                    "perintah berhasil dijalankan tapi izin tetap mati (kemungkinan dikunci oleh sistem merek HP)"
                }
            } else {
                overlayError = ""
                overlayTried = 0
            }
            if (!batteryOk(ctx)) {
                val cmd = "dumpsys deviceidle whitelist +$pkg; " +
                    "appops set $pkg RUN_ANY_IN_BACKGROUND allow; " +
                    "appops set $pkg RUN_IN_BACKGROUND allow"
                ShizukuHelper.exec(arrayOf("sh", "-c", cmd), 8000L)
            }
            // Izin WRITE_SECURE_SETTINGS baru saja diberikan? Nyalakan Aksesibilitas sekarang.
            SecureA11y.ensure(ctx)
        } catch (e: Throwable) {
        }
    }
}
