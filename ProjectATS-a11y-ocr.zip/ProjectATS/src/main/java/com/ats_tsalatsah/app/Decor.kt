package com.ats_tsalatsah.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

// Kurva perlambatan ala iOS: cepat di awal, mendarat lembut
val IOS_EASE = PathInterpolator(0.32f, 0.72f, 0f, 1f)

private fun col(s: String): Int = Color.parseColor(s)

private fun Paint.poly(c: Canvas, pts: FloatArray) {
    val p = Path()
    p.moveTo(pts[0], pts[1])
    var i = 2
    while (i < pts.size) {
        p.lineTo(pts[i], pts[i + 1])
        i += 2
    }
    p.close()
    c.drawPath(p, this)
}

// ---------------------------------------------------------------------
// Logo berlian
// Gelap: garis bulat di atas ubin kabut hutan.
// Terang: geometri tajam (atas hitam, bawah abu-abu).
// rich = true untuk ukuran besar (kabut, pinus, tanda siku ikut digambar)
// ---------------------------------------------------------------------
class LogoView(ctx: Context, private val pal: Palette, private val rich: Boolean) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val clip = Path()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height) / 100f
        c.save()
        c.translate((width - 100f * s) / 2f, (height - 100f * s) / 2f)
        c.scale(s, s)
        if (pal.dark) drawDark(c) else drawLight(c)
        c.restore()
    }

    private fun drawDark(c: Canvas) {
        clip.reset()
        clip.addRoundRect(0f, 0f, 100f, 100f, 26f, 26f, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        if (rich) {
            p.color = col("#151717")
            c.drawRect(0f, 0f, 100f, 100f, p)
            p.color = Color.WHITE
            p.alpha = 20
            c.drawOval(-30f, -10f, 90f, 34f, p)
            p.alpha = 15
            c.drawOval(30f, 14f, 130f, 46f, p)
            p.alpha = 255
            p.color = col("#0A0B0B")
            p.poly(c, floatArrayOf(10f, 100f, 18f, 78f, 14f, 78f, 22f, 62f, 30f, 78f, 26f, 78f, 34f, 100f))
            p.poly(c, floatArrayOf(66f, 100f, 76f, 74f, 71f, 74f, 80f, 56f, 89f, 74f, 84f, 74f, 94f, 100f))
        } else {
            p.color = col("#262A2A")
            c.drawRect(0f, 0f, 100f, 100f, p)
        }
        c.restore()
        if (rich) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            p.color = col("#2E3333")
            c.drawRoundRect(0.5f, 0.5f, 99.5f, 99.5f, 26f, 26f, p)
        }

        c.save()
        c.translate(14f, 12f)
        c.scale(0.72f, 0.72f)
        p.color = col("#E9ECEB")
        p.style = Paint.Style.STROKE
        p.strokeWidth = 7f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        path.reset()
        path.moveTo(80f, 37f); path.lineTo(68f, 22f); path.lineTo(32f, 22f); path.lineTo(15f, 42f); path.lineTo(43f, 42f)
        c.drawPath(path, p)
        path.reset()
        path.moveTo(23f, 54f); path.lineTo(50f, 85f); path.lineTo(85f, 43f); path.lineTo(58f, 43f)
        c.drawPath(path, p)
        path.reset()
        path.moveTo(43f, 42f); path.quadTo(50f, 42f, 50f, 50f); path.lineTo(50f, 62f)
        c.drawPath(path, p)
        p.style = Paint.Style.FILL_AND_STROKE
        p.strokeWidth = 3f
        path.reset()
        path.moveTo(41f, 60f); path.lineTo(50f, 72f); path.lineTo(59f, 60f); path.close()
        c.drawPath(path, p)
        c.restore()
    }

    private fun drawLight(c: Canvas) {
        p.style = Paint.Style.FILL
        p.color = col("#ECEEED")
        c.drawRoundRect(0f, 0f, 100f, 100f, 14f, 14f, p)
        clip.reset()
        clip.addRoundRect(0f, 0f, 100f, 100f, 14f, 14f, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.color = col("#DADDDC")
        p.poly(c, floatArrayOf(0f, 64f, 34f, 46f, 34f, 100f, 0f, 100f))
        p.poly(c, floatArrayOf(100f, 70f, 62f, 100f, 100f, 100f))
        c.restore()

        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.strokeJoin = Paint.Join.MITER
        if (rich) {
            p.strokeWidth = 2f
            p.color = col("#3A3F3E")
            path.reset(); path.moveTo(78f, 8f); path.lineTo(92f, 8f); path.lineTo(92f, 22f)
            c.drawPath(path, p)
            p.color = col("#8E9493")
            path.reset(); path.moveTo(84f, 14f); path.lineTo(88f, 14f); path.lineTo(88f, 18f)
            c.drawPath(path, p)
        }
        p.strokeWidth = 1f
        p.color = col("#C9CDCC")
        c.drawRoundRect(0.5f, 0.5f, 99.5f, 99.5f, 14f, 14f, p)

        c.save()
        c.translate(14f, 13f)
        c.scale(0.72f, 0.72f)
        p.style = Paint.Style.FILL
        p.color = col("#141616")
        p.poly(c, floatArrayOf(22.5f, 7.4f, 77.9f, 7.4f, 95.5f, 30.3f, 84.2f, 30.3f, 73.4f, 16.5f, 27.3f, 16.5f,
            12.8f, 35.2f, 41.2f, 35.2f, 41.2f, 44.1f, 9.6f, 44.1f, 1.5f, 34.6f))
        p.poly(c, floatArrayOf(45.7f, 35.2f, 54.7f, 35.2f, 54.7f, 61f, 61.2f, 61f, 50.2f, 73f, 39.2f, 61f, 45.7f, 61f))
        p.color = col("#8E9493")
        p.poly(c, floatArrayOf(59.2f, 35.2f, 98.5f, 35.2f, 50.2f, 92f, 13.7f, 48.9f, 25.5f, 48.9f, 50.2f, 77.9f,
            78.7f, 44.1f, 59.2f, 44.1f))
        c.restore()
    }
}

// ---------------------------------------------------------------------
// Hiasan di belakang header
// Gelap: kabut + siluet pinus. Terang: puncak gunung salju.
// ---------------------------------------------------------------------
class HeaderDecor(ctx: Context, private val pal: Palette) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    // Tinggi tambahan di atas (bilah status). Hiasan tetap berskala sama dan digeser turun, sedangkan kabut meluas ke atas
    var extraTop = 0
        set(v) {
            field = v
            invalidate()
        }

    // Kabut lembut: lingkaran bergradasi yang dipipihkan jadi elips
    private fun fog(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, alpha: Int) {
        c.save()
        c.translate(cx, cy)
        c.scale(1f, ry / rx)
        p.shader = RadialGradient(
            0f, 0f, rx,
            intArrayOf(Color.argb(alpha, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        p.color = Color.WHITE
        p.alpha = 255
        c.drawCircle(0f, 0f, rx, p)
        p.shader = null
        c.restore()
    }

    // (x tengah, dasar, lebar, tinggi) dalam kotak 340 x 170
    private val trees = arrayOf(
        floatArrayOf(20f, 150f, 40f, 70f), floatArrayOf(60f, 140f, 34f, 60f),
        floatArrayOf(105f, 160f, 46f, 85f), floatArrayOf(150f, 145f, 36f, 62f),
        floatArrayOf(195f, 165f, 50f, 90f), floatArrayOf(245f, 150f, 38f, 66f),
        floatArrayOf(290f, 158f, 44f, 80f), floatArrayOf(330f, 145f, 34f, 58f)
    )

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (width == 0 || height - extraTop <= 0) return
        c.save()
        c.translate(0f, extraTop.toFloat())
        c.scale(width / 340f, (height - extraTop) / 170f)
        p.style = Paint.Style.FILL
        if (pal.dark) {
            fog(c, 90f, 20f, 170f, 70f, 0x30)
            fog(c, 260f, 40f, 150f, 60f, 0x28)
            fog(c, 170f, 90f, 210f, 50f, 0x1E)
            p.shader = null
            p.color = pal.bg
            p.alpha = 230
            for (t in trees) {
                val x = t[0]; val b = t[1] + 10f; val w = t[2]; val h = t[3]; val y = b - h
                p.poly(c, floatArrayOf(
                    x, y, x + w * .22f, y + h * .3f, x + w * .12f, y + h * .3f, x + w * .36f, y + h * .62f,
                    x + w * .2f, y + h * .62f, x + w * .5f, b, x - w * .5f, b, x - w * .2f, y + h * .62f,
                    x - w * .36f, y + h * .62f, x - w * .12f, y + h * .3f, x - w * .22f, y + h * .3f
                ))
            }
        } else {
            p.color = col("#E6E8E7")
            p.poly(c, floatArrayOf(120f, 140f, 200f, 70f, 250f, 40f, 300f, 82f, 340f, 100f, 340f, 140f))
            p.color = col("#D3D7D6")
            p.poly(c, floatArrayOf(160f, 140f, 250f, 40f, 262f, 52f, 236f, 72f, 270f, 64f, 252f, 90f, 300f, 82f,
                340f, 120f, 340f, 140f))
            p.color = col("#3A3F3E")
            p.alpha = 140; p.poly(c, floatArrayOf(250f, 40f, 244f, 58f, 236f, 72f, 246f, 62f))
            p.alpha = 115; p.poly(c, floatArrayOf(262f, 52f, 258f, 74f, 252f, 90f, 266f, 70f))
            p.alpha = 90; p.poly(c, floatArrayOf(226f, 80f, 214f, 98f, 206f, 112f, 222f, 94f))
            p.alpha = 90; p.poly(c, floatArrayOf(300f, 82f, 292f, 104f, 286f, 118f, 304f, 96f))
            p.alpha = 255
            p.color = pal.bg
            p.poly(c, floatArrayOf(0f, 140f, 60f, 118f, 120f, 128f, 180f, 112f, 240f, 124f, 340f, 116f,
                340f, 170f, 0f, 170f))
        }
        c.restore()
    }
}

// ---------------------------------------------------------------------
// Hiasan di dalam kartu Target server
// Gelap: goresan kuas diagonal. Terang: lelehan tinta + cipratan.
// ---------------------------------------------------------------------
class CardDecor(ctx: Context, private val pal: Palette) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    // Hiasan tidak boleh menentukan tinggi kartu: ikut ukuran isi kartu saja
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY)
            MeasureSpec.getSize(heightMeasureSpec) else 0
        setMeasuredDimension(w, h)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (width == 0 || height == 0) return
        p.style = Paint.Style.FILL
        if (pal.dark) {
            c.save()
            c.scale(width / 300f, height / 160f)
            p.color = Color.WHITE
            p.alpha = 6; p.poly(c, floatArrayOf(40f, 160f, 120f, 0f, 150f, 0f, 70f, 160f))
            p.alpha = 8; p.poly(c, floatArrayOf(150f, 160f, 240f, 0f, 258f, 0f, 168f, 160f))
            p.color = Color.BLACK
            p.alpha = 64; p.poly(c, floatArrayOf(200f, 160f, 290f, 0f, 300f, 0f, 300f, 40f, 222f, 160f))
            c.restore()
        } else {
            // Tinta di pojok kanan atas, ukurannya mengikuti tinggi kartu
            val s = height / 170f * 0.85f
            c.save()
            c.translate(width - 300f * s, 0f)
            c.scale(s, s)
            p.color = col("#141616")
            p.alpha = 230
            path.reset()
            path.moveTo(300f, 0f); path.lineTo(220f, 0f)
            path.cubicTo(232f, 10f, 226f, 24f, 238f, 30f)
            path.cubicTo(250f, 36f, 246f, 50f, 256f, 58f)
            path.cubicTo(262f, 64f, 258f, 78f, 268f, 84f)
            path.cubicTo(276f, 90f, 274f, 104f, 284f, 110f)
            path.cubicTo(292f, 114f, 296f, 126f, 300f, 132f)
            path.close()
            c.drawPath(path, p)
            p.alpha = 255
            p.color = col("#535353")
            path.reset()
            path.moveTo(300f, 0f); path.lineTo(262f, 0f)
            path.cubicTo(268f, 12f, 264f, 22f, 274f, 30f)
            path.cubicTo(282f, 38f, 280f, 48f, 290f, 56f)
            path.cubicTo(296f, 62f, 298f, 70f, 300f, 74f)
            path.close()
            c.drawPath(path, p)
            p.color = col("#141616")
            c.drawCircle(214f, 40f, 3f, p)
            c.drawCircle(206f, 58f, 2f, p)
            c.drawCircle(230f, 70f, 2.5f, p)
            c.drawCircle(244f, 96f, 1.8f, p)
            c.drawCircle(222f, 22f, 1.5f, p)
            c.restore()
        }
    }
}

// ---------------------------------------------------------------------
// Garis tanah putus-putus (3 bagian, ada celah di tengah)
// ---------------------------------------------------------------------
class GroundLine(ctx: Context, pal: Palette) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        color = pal.ground
        alpha = 128
        pathEffect = DashPathEffect(floatArrayOf(4f * d, 3f * d), 0f)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val y = height / 2f
        val gap = 6f * d
        val unit = (width - 2 * gap) / 6f
        c.drawLine(0f, y, unit * 3, y, p)
        c.drawLine(unit * 4 + 2 * gap, y, width.toFloat(), y, p)
    }
}

// ---------------------------------------------------------------------
// Gambar untuk layar kosong (arsip belum ada)
// Gelap: tiga pinus berkabut. Terang: pohon tunggal dengan pantulan.
// ---------------------------------------------------------------------
class EmptyArt(ctx: Context, private val pal: Palette) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width / 160f, height / 150f)
        c.save()
        c.translate((width - 160f * s) / 2f, (height - 150f * s) / 2f)
        c.scale(s, s)
        if (pal.dark) {
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            p.alpha = 14
            c.drawOval(10f, 70f, 150f, 120f, p)
            p.alpha = 255
            drawPine(c, 58f, 112f, 34f, 56f, col("#1C1F1F"))
            drawPine(c, 104f, 112f, 30f, 48f, col("#1C1F1F"))
            drawPine(c, 80f, 116f, 42f, 78f, col("#2A2E2E"))
            p.color = pal.ground
            p.alpha = 128
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f
            p.pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
            c.drawLine(20f, 120f, 140f, 120f, p)
            p.pathEffect = null
            p.alpha = 255
        } else {
            p.style = Paint.Style.STROKE
            p.color = col("#D5D8D7")
            p.strokeWidth = 1f
            c.drawLine(10f, 75f, 150f, 75f, p)
            drawTree(c, 255)
            c.save()
            c.translate(0f, 150f)
            c.scale(1f, -1f)
            drawTree(c, 46)
            c.restore()
        }
        c.restore()
    }

    private fun drawPine(c: Canvas, x: Float, b: Float, w: Float, h: Float, color: Int) {
        val y = b - h
        p.style = Paint.Style.FILL
        p.color = color
        p.poly(c, floatArrayOf(
            x, y, x + w * .22f, y + h * .3f, x + w * .12f, y + h * .3f, x + w * .36f, y + h * .62f,
            x + w * .2f, y + h * .62f, x + w * .5f, b, x - w * .5f, b, x - w * .2f, y + h * .62f,
            x - w * .36f, y + h * .62f, x - w * .12f, y + h * .3f, x - w * .22f, y + h * .3f
        ))
    }

    private fun drawTree(c: Canvas, alpha: Int) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = col("#141616")
        p.alpha = alpha
        p.strokeWidth = 3f
        path.reset(); path.moveTo(80f, 75f); path.cubicTo(80f, 66f, 78f, 58f, 82f, 50f)
        c.drawPath(path, p)
        p.strokeWidth = 1.5f
        path.reset(); path.moveTo(81f, 56f); path.cubicTo(72f, 50f, 64f, 48f, 58f, 46f)
        path.moveTo(82f, 52f); path.cubicTo(92f, 46f, 100f, 44f, 106f, 44f)
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        p.color = col("#3A3F3E")
        p.alpha = alpha * 217 / 255
        c.drawOval(52f, 21f, 112f, 55f, p)
        p.color = col("#535353")
        p.alpha = alpha
        c.drawOval(52f, 33f, 80f, 51f, p)
        c.drawOval(87f, 32f, 113f, 50f, p)
    }
}

// ---------------------------------------------------------------------
// Lingkaran centang untuk daftar aplikasi
// ---------------------------------------------------------------------
class CheckDot(ctx: Context, private val pal: Palette) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var prog = 0f
    private var anim: ValueAnimator? = null
    private var on = false

    // Tanpa animasi (dipakai saat baris daftar didaur ulang)
    var checked: Boolean
        get() = on
        set(v) = setChecked(v, false)

    // animate = true untuk ketukan pengguna: lingkaran terisi membesar dan centang muncul halus
    fun setChecked(v: Boolean, animate: Boolean) {
        on = v
        anim?.cancel()
        val to = if (v) 1f else 0f
        if (!animate) {
            prog = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(prog, to)
        a.duration = 240
        a.interpolator = IOS_EASE
        a.addUpdateListener {
            prog = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 1.5f * d
        val e = prog
        if (e < 1f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * d
            p.color = pal.borderStrong
            p.alpha = (255 * (1f - e)).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, r, p)
        }
        if (e > 0f) {
            p.style = Paint.Style.FILL
            p.color = pal.primary
            p.alpha = 255
            c.drawCircle(cx, cy, r * e, p)
            val k = ((e - 0.45f) / 0.55f).coerceIn(0f, 1f)
            if (k > 0f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * d
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
                p.color = pal.onPrimary
                p.alpha = (255 * k).toInt()
                path.reset()
                path.moveTo(cx - r * 0.45f, cy + r * 0.02f)
                path.lineTo(cx - r * 0.1f, cy + r * 0.36f)
                path.lineTo(cx + r * 0.48f, cy - r * 0.3f)
                c.drawPath(path, p)
            }
        }
    }
}

// ---------------------------------------------------------------------
// Baris tab dengan pil yang meluncur.
// pos = posisi pil (0..n-1, boleh pecahan saat digeser).
// ---------------------------------------------------------------------
class TabBar(
    ctx: Context,
    private val pal: Palette,
    names: Array<String>,
    textSp: Float,
    private val onTap: (Int) -> Unit
) : LinearLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val n = names.size
    private val labels = ArrayList<TextView>()
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.primary }
    private val rect = RectF()
    private val eval = ArgbEvaluator()
    private var anim: ValueAnimator? = null

    var pos = 0f
        set(v) {
            field = v
            recolor()
            invalidate()
        }

    init {
        orientation = HORIZONTAL
        setWillNotDraw(false)
        names.forEachIndexed { i, s ->
            val t = TextView(ctx)
            t.text = s
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
            t.typeface = android.graphics.Typeface.DEFAULT_BOLD
            t.gravity = Gravity.CENTER
            t.setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
            t.setOnClickListener { onTap(i) }
            addView(t, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            labels.add(t)
        }
        recolor()
    }

    private fun recolor() {
        labels.forEachIndexed { i, t ->
            val f = (1f - minOf(1f, abs(pos - i)))
            t.setTextColor(eval.evaluate(f, pal.muted, pal.onPrimary) as Int)
        }
    }

    // Untuk tab yang tidak terhubung ke penggeser halaman
    fun animateTo(i: Int) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(pos, i.toFloat()).apply {
            duration = 420
            interpolator = IOS_EASE
            addUpdateListener { pos = it.animatedValue as Float }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val inner = (width - paddingLeft - paddingRight).toFloat()
        if (inner <= 0 || n == 0) return
        val pw = inner / n
        val l = paddingLeft + pos * pw
        rect.set(l, paddingTop.toFloat(), l + pw, (height - paddingBottom).toFloat())
        val r = rect.height() / 2f
        c.drawRoundRect(rect, r, r, pill)
    }
}

// ---------------------------------------------------------------------
// Penggeser halaman horizontal (pengganti ViewPager, tanpa AndroidX).
// Bisa digeser dengan jari; geseran vertikal tetap milik ScrollView/ListView.
// ---------------------------------------------------------------------
class PagerView(ctx: Context) : ViewGroup(ctx) {

    var onScroll: ((Float) -> Unit)? = null
    var onSelected: ((Int) -> Unit)? = null
    var current = 0
        private set

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val minFling = ViewConfiguration.get(ctx).scaledMinimumFlingVelocity
    private var vt: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragging = false
    private var anim: ValueAnimator? = null

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val cw = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
        val ch = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(cw, ch)
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        for (i in 0 until childCount) getChildAt(i).layout(i * w, 0, (i + 1) * w, h)
        if (!dragging && anim?.isRunning != true) scrollTo(current * w, 0)
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (width > 0) onScroll?.invoke(l.toFloat() / width)
    }

    private fun track(e: MotionEvent) {
        val v = vt ?: VelocityTracker.obtain().also { vt = it }
        v.addMovement(e)
    }

    private fun releaseTracker() {
        vt?.recycle()
        vt = null
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                releaseTracker()
                track(e)
                downX = e.x
                downY = e.y
                lastX = e.x
                dragging = false
                if (anim?.isRunning == true) {
                    anim?.cancel()
                    dragging = true
                }
                return dragging
            }
            MotionEvent.ACTION_MOVE -> {
                track(e)
                val dx = e.x - downX
                val dy = e.y - downY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy) * 1.2f) {
                    dragging = true
                    lastX = e.x
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                return dragging
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) releaseTracker()
                return dragging
            }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        track(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                lastX = e.x
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) {
                    val dx = e.x - downX
                    if (abs(dx) > slop && abs(dx) > abs(e.y - downY) * 1.2f) {
                        dragging = true
                        lastX = e.x
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }
                }
                if (dragging) {
                    val delta = lastX - e.x
                    lastX = e.x
                    val max = ((childCount - 1) * width).toFloat()
                    var nx = scrollX + delta
                    // Efek karet di halaman pertama dan terakhir
                    if (nx < 0f || nx > max) nx = scrollX + delta * 0.35f
                    scrollTo(nx.roundToInt(), 0)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    val v = vt
                    var vx = 0f
                    if (v != null) {
                        v.computeCurrentVelocity(1000)
                        vx = v.xVelocity
                    }
                    val pagePos = if (width > 0) scrollX.toFloat() / width else 0f
                    var target = pagePos.roundToInt()
                    if (abs(vx) > minFling * 4 && abs(e.x - downX) > slop) {
                        target = if (vx < 0) ceil(pagePos).toInt() else floor(pagePos).toInt()
                    }
                    dragging = false
                    animateTo(target)
                }
                releaseTracker()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    animateTo(if (width > 0) (scrollX.toFloat() / width).roundToInt() else current)
                }
                releaseTracker()
                return true
            }
        }
        return true
    }

    fun animateTo(i: Int, animate: Boolean = true) {
        val t = i.coerceIn(0, maxOf(0, childCount - 1))
        val changed = t != current
        current = t
        anim?.cancel()
        val to = t * width
        if (!animate || width == 0) {
            scrollTo(to, 0)
        } else {
            anim = ValueAnimator.ofInt(scrollX, to).apply {
                duration = 480
                interpolator = IOS_EASE
                addUpdateListener { scrollTo(it.animatedValue as Int, 0) }
                start()
            }
        }
        if (changed) onSelected?.invoke(t)
    }
}
