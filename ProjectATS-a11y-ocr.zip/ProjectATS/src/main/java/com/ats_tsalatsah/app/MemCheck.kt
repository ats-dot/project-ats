package com.ats_tsalatsah.app

import android.content.Context
import java.io.File

// Pengaturan uji memori (disimpan terpisah)
object MemCfg {
    private const val PREFS = "ats_mem"
    private var ctx: Context? = null

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    private fun p() = ctx?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // am kill-all di awal sesi dan awal uji (bawaan nyala)
    var killAll: Boolean
        get() = p()?.getBoolean("ka", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("ka", v)?.apply()
        }

    // Tutup (force stop) semua klon sesudah uji selesai (bawaan nyala)
    var closeAfter: Boolean
        get() = p()?.getBoolean("ca", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("ca", v)?.apply()
        }

    // Kecilkan resolusi layar selama uji dan sesi (bawaan mati). Hemat memori buffer grafis tiap klon
    var resOn: Boolean
        get() = p()?.getBoolean("rs", false) ?: false
        set(v) {
            p()?.edit()?.putBoolean("rs", v)?.apply()
        }

    // Persen resolusi (30 sampai 100), bawaan 67 (sekitar 720 dari 1080)
    var resPct: Int
        get() = (p()?.getInt("rp", 67) ?: 67).coerceIn(30, 100)
        set(v) {
            p()?.edit()?.putInt("rp", v.coerceIn(30, 100))?.apply()
        }

    // Tutup semua aplikasi yang sedang aktif saat uji atau sesi dimulai (bawaan nyala)
    var closeActive: Boolean
        get() = p()?.getBoolean("ac", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("ac", v)?.apply()
        }

    // Putaran 2: tutup apk yang sudah selesai dinamai (force stop dan buang dari recent), bawaan nyala
    var closeDone: Boolean
        get() = p()?.getBoolean("cd", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("cd", v)?.apply()
        }

    // Resolusi masih diturunkan dan belum dikembalikan (mis. aplikasi mati di tengah jalan): dipulihkan saat aplikasi dibuka lagi
    var resPending: Boolean
        get() = p()?.getBoolean("rq", false) ?: false
        set(v) {
            p()?.edit()?.putBoolean("rq", v)?.apply()
        }

    // Jumlah apk yang dibuka saat uji (0 = semua yang dicentang)
    var count: Int
        get() = p()?.getInt("n", 0) ?: 0
        set(v) {
            p()?.edit()?.putInt("n", v)?.apply()
        }
}

// Pembaca RAM dan pengatur memori lewat Shizuku. Semua pembacaan bersifat baca-saja,
// kecuali kill-all (membersihkan RAM) dan pengaturan resolusi layar.
object MemCheck {
    class Mem(val pssKb: Long, val rssKb: Long, val swapKb: Long, val procs: List<String> = emptyList())
    class Sys(val totalMb: Long, val availMb: Long, val swapUsedMb: Long, val swapTotalMb: Long = 0L)

    // Benar selama uji geser yang menurunkan resolusi sedang berjalan: layar Project ats bisa dibuat ulang saat resolusi berganti,
    // dan pemulihan otomatis saat aplikasi dibuka tidak boleh mengembalikan resolusi di tengah uji
    @Volatile var keepRes = false

    private val PKG_RX = Regex("^[A-Za-z0-9._]+$")

    fun valid(pkg: String): Boolean = pkg.isNotEmpty() && PKG_RX.matches(pkg)

    // RAM seluruh HP dari /proc/meminfo (bisa dibaca aplikasi biasa)
    fun sys(): Sys? {
        return try {
            val t = File("/proc/meminfo").readText()
            fun kb(key: String): Long = Regex("^$key:\\s+(\\d+)", RegexOption.MULTILINE).find(t)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val total = kb("MemTotal")
            val avail = kb("MemAvailable")
            val swapT = kb("SwapTotal")
            val swapF = kb("SwapFree")
            Sys(total / 1024, avail / 1024, maxOf(0L, swapT - swapF) / 1024, swapT / 1024)
        } catch (e: Throwable) {
            null
        }
    }

    // Peta nama paket -> PID untuk paket-paket tertentu, dari satu kali "ps"
    fun pidMap(pkgs: Collection<String>): Map<String, Int> {
        val want = pkgs.toHashSet()
        val out = HashMap<String, Int>()
        val r = ShizukuHelper.shell(arrayOf("ps", "-A", "-o", "PID,ARGS"))
        if (r.first != 0 || r.second.isEmpty()) return out
        for (line in r.second.lines()) {
            val t = line.trim()
            val sp = t.indexOf(' ')
            if (sp < 1) continue
            val pid = t.substring(0, sp).toIntOrNull() ?: continue
            val name = t.substring(sp + 1).trim().split(' ')[0]
            if (want.contains(name)) {
                val old = out[name]
                if (old == null || pid < old) out[name] = pid
            }
        }
        return out
    }

    fun uidOf(pkg: String): Int? {
        if (!valid(pkg)) return null
        val r = ShizukuHelper.shell(arrayOf("pm", "list", "packages", "-U", pkg))
        for (line in r.second.lines()) {
            val m = Regex("^package:" + Regex.escape(pkg) + "\\s+uid:(\\d+)").find(line.trim())
            if (m != null) return m.groupValues[1].toIntOrNull()
        }
        return null
    }

    // Memori SELURUH proses satu paket (satuan KB): tiap proses punya blok sendiri di "dumpsys meminfo", jadi semua blok
    // yang namanya paket atau paket:sub dijumlahkan. null = tidak ada proses
    fun procMem(pkg: String): Mem? {
        if (!valid(pkg)) return null
        var r = ShizukuHelper.shell(arrayOf("dumpsys", "meminfo", "--package", pkg))
        var m = parseMem(pkg, r.second, r.first)
        if (m == null) {
            r = ShizukuHelper.shell(arrayOf("dumpsys", "meminfo", pkg))
            m = parseMem(pkg, r.second, r.first)
        }
        return m
    }

    private fun parseMem(pkg: String, t: String, code: Int): Mem? {
        if (code != 0 || t.isEmpty() || t.contains("No process found")) return null
        val heads = Regex("\\*\\* MEMINFO in pid (\\d+) \\[([^\\]]+)\\] \\*\\*").findAll(t).toList()
        if (heads.isEmpty()) return null
        var pss = 0L
        var rss = 0L
        var swap = 0L
        val procs = ArrayList<String>()
        for (i in heads.indices) {
            val name = heads[i].groupValues[2]
            if (name != pkg && !name.startsWith("$pkg:")) continue
            val from = heads[i].range.first
            val to = if (i + 1 < heads.size) heads[i + 1].range.first else t.length
            val b = t.substring(from, to)
            fun num(rx: String): Long? = Regex(rx).find(b)?.groupValues?.get(1)?.toLongOrNull()
            var p1 = num("TOTAL PSS:\\s+(\\d+)")
            if (p1 == null) p1 = Regex("^\\s*TOTAL\\s+(\\d+)", RegexOption.MULTILINE).find(b)?.groupValues?.get(1)?.toLongOrNull()
            if (p1 == null) continue
            val r1 = num("TOTAL RSS:\\s+(\\d+)") ?: 0L
            val s1 = num("TOTAL SWAP PSS:\\s+(\\d+)") ?: 0L
            pss += p1
            rss += r1
            swap += s1
            procs.add(name + " (pid " + heads[i].groupValues[1] + "): PSS " + (p1 / 1024) + " MB, RSS " + (r1 / 1024) + " MB, zRAM " + (s1 / 1024) + " MB")
        }
        if (procs.isEmpty()) return null
        return Mem(pss, rss, swap, procs)
    }

    // Semua proses tiap paket dari satu kali "ps": paket -> (nama proses -> PID). Nama proses game biasanya "paket:UnityKillsMe"
    fun procMapAll(pkgs: Collection<String>): Map<String, Map<String, Int>> {
        val want = pkgs.toHashSet()
        val out = HashMap<String, HashMap<String, Int>>()
        val r = ShizukuHelper.shell(arrayOf("ps", "-A", "-o", "PID,ARGS"))
        if (r.first != 0 || r.second.isEmpty()) return out
        for (line in r.second.lines()) {
            val t = line.trim()
            val sp = t.indexOf(' ')
            if (sp < 1) continue
            val pid = t.substring(0, sp).toIntOrNull() ?: continue
            val name = t.substring(sp + 1).trim().split(' ')[0]
            val base = name.substringBefore(':')
            if (want.contains(base)) out.getOrPut(base) { HashMap() }[name] = pid
        }
        return out
    }

    // Ukuran dan kepadatan layar FISIK (bukan yang sedang di-override) dari "wm size" dan "wm density"
    private fun physical(): Triple<Int, Int, Int>? {
        val a = ShizukuHelper.shell(arrayOf("wm", "size"))
        val b = ShizukuHelper.shell(arrayOf("wm", "density"))
        val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(a.second) ?: return null
        val dn = Regex("Physical density:\\s*(\\d+)").find(b.second) ?: return null
        val w = sz.groupValues[1].toIntOrNull() ?: return null
        val h = sz.groupValues[2].toIntOrNull() ?: return null
        val d = dn.groupValues[1].toIntOrNull() ?: return null
        return Triple(w, h, d)
    }

    // Turunkan resolusi dan kepadatan layar dengan rasio sama. Hasil: keterangan untuk log. OCR dikompensasi otomatis
    fun applyRes(pct: Int): String {
        if (!ShizukuHelper.hasPermission()) return "Shizuku belum diizinkan"
        val ph = physical() ?: return "ukuran layar fisik tidak terbaca, resolusi tidak diubah"
        val p = pct.coerceIn(30, 100)
        if (p >= 100) return "persen resolusi 100, tidak diubah"
        // kelipatan 8 supaya 67% dari 1080 jatuh tepat di 720
        fun even(v: Double): Int = (Math.round(v / 8.0) * 8L).toInt().coerceAtLeast(8)
        val w = even(ph.first * p / 100.0)
        val h = even(ph.second * p / 100.0)
        val d = Math.round(ph.third * p / 100.0).toInt().coerceAtLeast(120)
        MemCfg.resPending = true
        val r1 = ShizukuHelper.shell(arrayOf("wm", "size", w.toString() + "x" + h.toString()))
        val r2 = ShizukuHelper.shell(arrayOf("wm", "density", d.toString()))
        ScreenOcr.comp = ph.first.toFloat() / w.toFloat()
        val now = ShizukuHelper.shell(arrayOf("wm", "size")).second.replace("\n", " | ")
        return "Resolusi layar " + ph.first + "x" + ph.second + " (kepadatan " + ph.third + ") menjadi " + w + "x" + h + " (kepadatan " + d + ", " + p + "%). " +
            "Kompensasi OCR x" + String.format("%.2f", ScreenOcr.comp) + ". wm size sekarang: " + now +
            (if (r1.first == 0 && r2.first == 0) "" else " [PERINGATAN: kode size ${r1.first}, density ${r2.first}]")
    }

    // Samakan kompensasi OCR dengan resolusi yang SEDANG dipakai (mis. aplikasi baru dibuka lagi sesudah resolusi diturunkan)
    fun syncComp(): String {
        val a = ShizukuHelper.shell(arrayOf("wm", "size")).second
        val ph = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(a)
        val ov = Regex("Override size:\\s*(\\d+)x(\\d+)").find(a)
        ScreenOcr.comp = if (ph != null && ov != null) {
            val pw = ph.groupValues[1].toFloat()
            val ow = ov.groupValues[1].toFloat()
            if (ow > 0f) (pw / ow).coerceIn(1f, 4f) else 1f
        } else {
            1f
        }
        return "Kompensasi OCR x" + String.format("%.2f", ScreenOcr.comp)
    }

    // Kembalikan resolusi dan kepadatan layar ke bawaan
    fun resetRes(): String {
        val a = ShizukuHelper.shell(arrayOf("wm", "size", "reset"))
        val b = ShizukuHelper.shell(arrayOf("wm", "density", "reset"))
        ScreenOcr.comp = 1f
        if (a.first == 0 && b.first == 0) MemCfg.resPending = false
        val now = ShizukuHelper.shell(arrayOf("wm", "size")).second.replace("\n", " | ")
        return "Resolusi layar dikembalikan: " + now + (if (a.first == 0 && b.first == 0) "" else " [GAGAL: kode size ${a.first}, density ${b.first}]")
    }

    // Aplikasi yang sedang AKTIF (ada di recent apps atau prosesnya berjalan), tanpa yang dilindungi.
    // Dilindungi: Project ats sendiri, Shizuku, layar utama (launcher), keyboard, layanan aksesibilitas yang nyala, dan sistem inti.
    // Hasil: (yang akan ditutup, yang dilindungi tapi aktif)
    fun activeApps(ownPkg: String): Pair<List<String>, List<String>> {
        val prot = HashSet<String>()
        prot.add(ownPkg)
        prot.add("moe.shizuku.privileged.api")
        prot.add("com.android.systemui")
        prot.add("android")
        // layar utama
        val h = ShizukuHelper.shell(arrayOf("pm", "resolve-activity", "--brief", "-a", "android.intent.action.MAIN", "-c", "android.intent.category.HOME"))
        h.second.lines().map { it.trim() }.lastOrNull { it.contains("/") }?.substringBefore('/')?.let { if (valid(it)) prot.add(it) }
        // keyboard
        val ime = ShizukuHelper.shell(arrayOf("settings", "get", "secure", "default_input_method")).second.trim()
        if (ime.contains("/")) prot.add(ime.substringBefore('/'))
        // layanan aksesibilitas yang nyala
        val acc = ShizukuHelper.shell(arrayOf("settings", "get", "secure", "enabled_accessibility_services")).second.trim()
        if (acc.isNotEmpty() && acc != "null") for (x in acc.split(':')) if (x.contains("/")) prot.add(x.substringBefore('/'))
        // aplikasi pihak ketiga (bukan bawaan sistem)
        val tp = ShizukuHelper.shell(arrayOf("pm", "list", "packages", "-3")).second.lines()
            .mapNotNull { Regex("^package:([A-Za-z0-9._]+)").find(it.trim())?.groupValues?.get(1) }.toHashSet()
        val all = LinkedHashSet<String>()
        // recent apps
        val rec = ShizukuHelper.shell(arrayOf("dumpsys", "activity", "recents")).second
        Regex("A=\\d+:([A-Za-z0-9._]+)").findAll(rec).forEach { all.add(it.groupValues[1]) }
        Regex("realActivity=([A-Za-z0-9._]+)/").findAll(rec).forEach { all.add(it.groupValues[1]) }
        // proses berjalan milik aplikasi pihak ketiga
        val ps = ShizukuHelper.shell(arrayOf("ps", "-A", "-o", "USER,ARGS")).second
        val userRx = Regex("^u\\d+_a\\d+$")
        for (line in ps.lines()) {
            val t = line.trim()
            val sp = t.indexOf(' ')
            if (sp < 1) continue
            if (!userRx.matches(t.substring(0, sp))) continue
            val name = t.substring(sp + 1).trim().split(' ')[0].substringBefore(':')
            if (tp.contains(name)) all.add(name)
        }
        val close = all.filter { valid(it) && !prot.contains(it) && !it.startsWith("com.android.systemui") }.sorted()
        val keep = all.filter { prot.contains(it) }.sorted()
        return Pair(close, keep)
    }

    // Alasan terakhir sebuah paket berhenti, dari catatan Android (ApplicationExitInfo): mis. LOW MEMORY, CRASH, USER REQUESTED
    fun exitReason(pkg: String): String {
        if (!valid(pkg)) return "-"
        val r = ShizukuHelper.shell(arrayOf("dumpsys", "activity", "exit-info", pkg))
        if (r.first != 0) return "tidak terbaca (kode ${r.first})"
        val lines = r.second.lines()
        val i = lines.indexOfFirst { it.contains("reason=") }
        if (i < 0) return "tidak ada catatan berhenti"
        val sb = StringBuilder(lines[i].trim())
        for (k in 1..3) {
            val l = lines.getOrNull(i + k)?.trim() ?: break
            if (l.startsWith("ApplicationExitInfo")) break
            if (l.contains("description=") || l.contains("importance=")) sb.append(" | ").append(l)
        }
        return sb.toString().take(260)
    }

    // Buang semua proses latar milik aplikasi lain
    fun killAll(): Pair<Boolean, String> {
        val r = ShizukuHelper.shell(arrayOf("am", "kill-all"))
        return Pair(r.first == 0, if (r.first == 0) "" else "kode ${r.first} ${r.third.take(120)}")
    }

    // Paksa Android memampatkan memori aplikasi di latar (pindah ke zRAM)
    fun compact(pkg: String, uid: Int): Pair<Boolean, String> {
        if (!valid(pkg)) return Pair(false, "nama paket tidak valid")
        val r = ShizukuHelper.shell(arrayOf("cmd", "activity", "compact", "full", pkg, uid.toString()))
        val all = (r.second + " " + r.third).trim()
        val ok = r.first == 0 && !all.contains("Unknown", true) && !all.contains("Exception", true) && !all.contains("Error", true)
        return Pair(ok, all.take(160))
    }

    // Batas proses latar milik Android (kosong/null = pakai bawaan)
    fun limits(): List<String> {
        val res = ArrayList<String>()
        fun dc(k: String): String {
            val r = ShizukuHelper.shell(arrayOf("device_config", "get", "activity_manager", k))
            return if (r.first == 0) r.second.ifEmpty { "(kosong)" } else "(tidak terbaca: ${r.third.take(60)})"
        }
        res.add("max_cached_processes = " + dc("max_cached_processes"))
        res.add("max_phantom_processes = " + dc("max_phantom_processes"))
        val s = ShizukuHelper.shell(arrayOf("settings", "get", "global", "activity_manager_constants"))
        res.add("activity_manager_constants = " + (if (s.first == 0) s.second.ifEmpty { "(kosong)" } else "(tidak terbaca)"))
        return res
    }
}
