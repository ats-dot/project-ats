package com.ats_tsalatsah.app

import android.content.Context
import java.io.File

// Pengaturan uji memori (disimpan terpisah)
object MemCfg {
    private const val PREFS = "ats_mem"
    private var ctx: Context? = null

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    private fun p() = ctx?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // am kill-all di awal sesi dan awal uji (bawaan nyala)
    var killAll: Boolean
        get() = p()?.getBoolean("ka", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("ka", v)?.apply()
        }

    // Tutup (force stop) semua klon sesudah uji selesai (bawaan nyala)
    var closeAfter: Boolean
        get() = p()?.getBoolean("ca", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("ca", v)?.apply()
        }

    // Jumlah apk yang dibuka saat uji (0 = semua yang dicentang)
    var count: Int
        get() = p()?.getInt("n", 0) ?: 0
        set(v) {
            p()?.edit()?.putInt("n", v)?.apply()
        }
}

// Pembaca RAM dan pengatur memori lewat Shizuku. Semua pembacaan bersifat baca-saja,
// kecuali kill-all, send-trim-memory, dan compact yang memang dipakai untuk menghemat RAM.
object MemCheck {
    class Mem(val pssKb: Long, val rssKb: Long, val swapKb: Long)
    class Sys(val totalMb: Long, val availMb: Long, val swapUsedMb: Long)

    private val PKG_RX = Regex("^[A-Za-z0-9._]+$")

    fun valid(pkg: String): Boolean = pkg.isNotEmpty() && PKG_RX.matches(pkg)

    // RAM seluruh HP dari /proc/meminfo (bisa dibaca aplikasi biasa)
    fun sys(): Sys? {
        return try {
            val t = File("/proc/meminfo").readText()
            fun kb(key: String): Long = Regex("^$key:\\s+(\\d+)", RegexOption.MULTILINE).find(t)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val total = kb("MemTotal")
            val avail = kb("MemAvailable")
            val swapT = kb("SwapTotal")
            val swapF = kb("SwapFree")
            Sys(total / 1024, avail / 1024, maxOf(0L, swapT - swapF) / 1024)
        } catch (e: Throwable) {
            null
        }
    }

    // Peta nama paket -> PID untuk paket-paket tertentu, dari satu kali "ps"
    fun pidMap(pkgs: Collection<String>): Map<String, Int> {
        val want = pkgs.toHashSet()
        val out = HashMap<String, Int>()
        val r = ShizukuHelper.shell(arrayOf("ps", "-A", "-o", "PID,ARGS"))
        if (r.first != 0 || r.second.isEmpty()) return out
        for (line in r.second.lines()) {
            val t = line.trim()
            val sp = t.indexOf(' ')
            if (sp < 1) continue
            val pid = t.substring(0, sp).toIntOrNull() ?: continue
            val name = t.substring(sp + 1).trim().split(' ')[0]
            if (want.contains(name)) {
                val old = out[name]
                if (old == null || pid < old) out[name] = pid
            }
        }
        return out
    }

    fun uidOf(pkg: String): Int? {
        if (!valid(pkg)) return null
        val r = ShizukuHelper.shell(arrayOf("pm", "list", "packages", "-U", pkg))
        for (line in r.second.lines()) {
            val m = Regex("^package:" + Regex.escape(pkg) + "\\s+uid:(\\d+)").find(line.trim())
            if (m != null) return m.groupValues[1].toIntOrNull()
        }
        return null
    }

    // Memori satu paket dari "dumpsys meminfo" (satuan KB). null = proses tidak ada
    fun procMem(pkg: String): Mem? {
        if (!valid(pkg)) return null
        val r = ShizukuHelper.shell(arrayOf("dumpsys", "meminfo", pkg))
        val t = r.second
        if (r.first != 0 || t.isEmpty() || t.contains("No process found")) return null
        fun num(rx: String): Long? = Regex(rx).find(t)?.groupValues?.get(1)?.toLongOrNull()
        var pss = num("TOTAL PSS:\\s+(\\d+)")
        if (pss == null) pss = Regex("^\\s*TOTAL\\s+(\\d+)", RegexOption.MULTILINE).find(t)?.groupValues?.get(1)?.toLongOrNull()
        if (pss == null) return null
        val rss = num("TOTAL RSS:\\s+(\\d+)") ?: 0L
        val swap = num("TOTAL SWAP PSS:\\s+(\\d+)") ?: 0L
        return Mem(pss, rss, swap)
    }

    // Buang semua proses latar milik aplikasi lain
    fun killAll(): Pair<Boolean, String> {
        val r = ShizukuHelper.shell(arrayOf("am", "kill-all"))
        return Pair(r.first == 0, if (r.first == 0) "" else "kode ${r.first} ${r.third.take(120)}")
    }

    // Minta aplikasi melepas cache (tingkat COMPLETE)
    fun trim(pid: Int): Boolean {
        val r = ShizukuHelper.shell(arrayOf("am", "send-trim-memory", "--user", "0", pid.toString(), "COMPLETE"))
        return r.first == 0
    }

    // Paksa Android memampatkan memori aplikasi di latar (pindah ke zRAM)
    fun compact(pkg: String, uid: Int): Pair<Boolean, String> {
        if (!valid(pkg)) return Pair(false, "nama paket tidak valid")
        val r = ShizukuHelper.shell(arrayOf("cmd", "activity", "compact", "full", pkg, uid.toString()))
        val all = (r.second + " " + r.third).trim()
        val ok = r.first == 0 && !all.contains("Unknown", true) && !all.contains("Exception", true) && !all.contains("Error", true)
        return Pair(ok, all.take(160))
    }

    // Batas proses latar milik Android (kosong/null = pakai bawaan)
    fun limits(): List<String> {
        val res = ArrayList<String>()
        fun dc(k: String): String {
            val r = ShizukuHelper.shell(arrayOf("device_config", "get", "activity_manager", k))
            return if (r.first == 0) r.second.ifEmpty { "(kosong)" } else "(tidak terbaca: ${r.third.take(60)})"
        }
        res.add("max_cached_processes = " + dc("max_cached_processes"))
        res.add("max_phantom_processes = " + dc("max_phantom_processes"))
        val s = ShizukuHelper.shell(arrayOf("settings", "get", "global", "activity_manager_constants"))
        res.add("activity_manager_constants = " + (if (s.first == 0) s.second.ifEmpty { "(kosong)" } else "(tidak terbaca)"))
        return res
    }
}
