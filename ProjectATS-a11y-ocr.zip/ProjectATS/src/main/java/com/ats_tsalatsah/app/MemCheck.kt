package com.ats_tsalatsah.app

import android.content.Context
import java.io.File

// Pengaturan uji memori (disimpan terpisah)
object MemCfg {
    private const val PREFS = "ats_mem"
    private var ctx: Context? = null

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    private fun p() = ctx?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // am kill-all di awal sesi dan awal uji (bawaan nyala)
    var killAll: Boolean
        get() = p()?.getBoolean("ka", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("ka", v)?.apply()
        }

    // Tutup (force stop) semua klon sesudah uji selesai (bawaan nyala)
    var closeAfter: Boolean
        get() = p()?.getBoolean("ca", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("ca", v)?.apply()
        }

    // Kirim trim memori ke PROSES GAME tiap klon yang sudah di latar (bawaan mati, hanya di uji)
    var trim: Boolean
        get() = p()?.getBoolean("tr", false) ?: false
        set(v) {
            p()?.edit()?.putBoolean("tr", v)?.apply()
        }

    // Jumlah apk yang dibuka saat uji (0 = semua yang dicentang)
    var count: Int
        get() = p()?.getInt("n", 0) ?: 0
        set(v) {
            p()?.edit()?.putInt("n", v)?.apply()
        }
}

// Pembaca RAM dan pengatur memori lewat Shizuku. Semua pembacaan bersifat baca-saja,
// kecuali kill-all, send-trim-memory, dan compact yang memang dipakai untuk menghemat RAM.
object MemCheck {
    class Mem(val pssKb: Long, val rssKb: Long, val swapKb: Long, val procs: List<String> = emptyList())
    class Sys(val totalMb: Long, val availMb: Long, val swapUsedMb: Long, val swapTotalMb: Long = 0L)

    private val PKG_RX = Regex("^[A-Za-z0-9._]+$")

    fun valid(pkg: String): Boolean = pkg.isNotEmpty() && PKG_RX.matches(pkg)

    // RAM seluruh HP dari /proc/meminfo (bisa dibaca aplikasi biasa)
    fun sys(): Sys? {
        return try {
            val t = File("/proc/meminfo").readText()
            fun kb(key: String): Long = Regex("^$key:\\s+(\\d+)", RegexOption.MULTILINE).find(t)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val total = kb("MemTotal")
            val avail = kb("MemAvailable")
            val swapT = kb("SwapTotal")
            val swapF = kb("SwapFree")
            Sys(total / 1024, avail / 1024, maxOf(0L, swapT - swapF) / 1024, swapT / 1024)
        } catch (e: Throwable) {
            null
        }
    }

    // Peta nama paket -> PID untuk paket-paket tertentu, dari satu kali "ps"
    fun pidMap(pkgs: Collection<String>): Map<String, Int> {
        val want = pkgs.toHashSet()
        val out = HashMap<String, Int>()
        val r = ShizukuHelper.shell(arrayOf("ps", "-A", "-o", "PID,ARGS"))
        if (r.first != 0 || r.second.isEmpty()) return out
        for (line in r.second.lines()) {
            val t = line.trim()
            val sp = t.indexOf(' ')
            if (sp < 1) continue
            val pid = t.substring(0, sp).toIntOrNull() ?: continue
            val name = t.substring(sp + 1).trim().split(' ')[0]
            if (want.contains(name)) {
                val old = out[name]
                if (old == null || pid < old) out[name] = pid
            }
        }
        return out
    }

    fun uidOf(pkg: String): Int? {
        if (!valid(pkg)) return null
        val r = ShizukuHelper.shell(arrayOf("pm", "list", "packages", "-U", pkg))
        for (line in r.second.lines()) {
            val m = Regex("^package:" + Regex.escape(pkg) + "\\s+uid:(\\d+)").find(line.trim())
            if (m != null) return m.groupValues[1].toIntOrNull()
        }
        return null
    }

    // Memori SELURUH proses satu paket (satuan KB): tiap proses punya blok sendiri di "dumpsys meminfo", jadi semua blok
    // yang namanya paket atau paket:sub dijumlahkan. null = tidak ada proses
    fun procMem(pkg: String): Mem? {
        if (!valid(pkg)) return null
        var r = ShizukuHelper.shell(arrayOf("dumpsys", "meminfo", "--package", pkg))
        var m = parseMem(pkg, r.second, r.first)
        if (m == null) {
            r = ShizukuHelper.shell(arrayOf("dumpsys", "meminfo", pkg))
            m = parseMem(pkg, r.second, r.first)
        }
        return m
    }

    private fun parseMem(pkg: String, t: String, code: Int): Mem? {
        if (code != 0 || t.isEmpty() || t.contains("No process found")) return null
        val heads = Regex("\\*\\* MEMINFO in pid (\\d+) \\[([^\\]]+)\\] \\*\\*").findAll(t).toList()
        if (heads.isEmpty()) return null
        var pss = 0L
        var rss = 0L
        var swap = 0L
        val procs = ArrayList<String>()
        for (i in heads.indices) {
            val name = heads[i].groupValues[2]
            if (name != pkg && !name.startsWith("$pkg:")) continue
            val from = heads[i].range.first
            val to = if (i + 1 < heads.size) heads[i + 1].range.first else t.length
            val b = t.substring(from, to)
            fun num(rx: String): Long? = Regex(rx).find(b)?.groupValues?.get(1)?.toLongOrNull()
            var p1 = num("TOTAL PSS:\\s+(\\d+)")
            if (p1 == null) p1 = Regex("^\\s*TOTAL\\s+(\\d+)", RegexOption.MULTILINE).find(b)?.groupValues?.get(1)?.toLongOrNull()
            if (p1 == null) continue
            val r1 = num("TOTAL RSS:\\s+(\\d+)") ?: 0L
            val s1 = num("TOTAL SWAP PSS:\\s+(\\d+)") ?: 0L
            pss += p1
            rss += r1
            swap += s1
            procs.add(name + " (pid " + heads[i].groupValues[1] + "): PSS " + (p1 / 1024) + " MB, RSS " + (r1 / 1024) + " MB, zRAM " + (s1 / 1024) + " MB")
        }
        if (procs.isEmpty()) return null
        return Mem(pss, rss, swap, procs)
    }

    // Semua proses tiap paket dari satu kali "ps": paket -> (nama proses -> PID). Nama proses game biasanya "paket:UnityKillsMe"
    fun procMapAll(pkgs: Collection<String>): Map<String, Map<String, Int>> {
        val want = pkgs.toHashSet()
        val out = HashMap<String, HashMap<String, Int>>()
        val r = ShizukuHelper.shell(arrayOf("ps", "-A", "-o", "PID,ARGS"))
        if (r.first != 0 || r.second.isEmpty()) return out
        for (line in r.second.lines()) {
            val t = line.trim()
            val sp = t.indexOf(' ')
            if (sp < 1) continue
            val pid = t.substring(0, sp).toIntOrNull() ?: continue
            val name = t.substring(sp + 1).trim().split(' ')[0]
            val base = name.substringBefore(':')
            if (want.contains(base)) out.getOrPut(base) { HashMap() }[name] = pid
        }
        return out
    }

    // Alasan terakhir sebuah paket berhenti, dari catatan Android (ApplicationExitInfo): mis. LOW MEMORY, CRASH, USER REQUESTED
    fun exitReason(pkg: String): String {
        if (!valid(pkg)) return "-"
        val r = ShizukuHelper.shell(arrayOf("dumpsys", "activity", "exit-info", pkg))
        if (r.first != 0) return "tidak terbaca (kode ${r.first})"
        val lines = r.second.lines()
        val i = lines.indexOfFirst { it.contains("reason=") }
        if (i < 0) return "tidak ada catatan berhenti"
        val sb = StringBuilder(lines[i].trim())
        for (k in 1..3) {
            val l = lines.getOrNull(i + k)?.trim() ?: break
            if (l.startsWith("ApplicationExitInfo")) break
            if (l.contains("description=") || l.contains("importance=")) sb.append(" | ").append(l)
        }
        return sb.toString().take(260)
    }

    // Buang semua proses latar milik aplikasi lain
    fun killAll(): Pair<Boolean, String> {
        val r = ShizukuHelper.shell(arrayOf("am", "kill-all"))
        return Pair(r.first == 0, if (r.first == 0) "" else "kode ${r.first} ${r.third.take(120)}")
    }

    // Minta SATU proses (PID) melepas cache (tingkat COMPLETE). Android menolak untuk proses yang masih di layar depan
    fun trim(pid: Int, level: String = "COMPLETE"): Pair<Boolean, String> {
        val r = ShizukuHelper.shell(arrayOf("am", "send-trim-memory", "--user", "0", pid.toString(), level))
        val msg = (r.second + " " + r.third).trim().take(160)
        val bad = msg.contains("Exception", true) || msg.contains("Unable", true) || msg.contains("Unknown", true) || msg.contains("Error", true)
        return Pair(r.first == 0 && !bad, msg)
    }

    // Paksa Android memampatkan memori aplikasi di latar (pindah ke zRAM)
    fun compact(pkg: String, uid: Int): Pair<Boolean, String> {
        if (!valid(pkg)) return Pair(false, "nama paket tidak valid")
        val r = ShizukuHelper.shell(arrayOf("cmd", "activity", "compact", "full", pkg, uid.toString()))
        val all = (r.second + " " + r.third).trim()
        val ok = r.first == 0 && !all.contains("Unknown", true) && !all.contains("Exception", true) && !all.contains("Error", true)
        return Pair(ok, all.take(160))
    }

    // Batas proses latar milik Android (kosong/null = pakai bawaan)
    fun limits(): List<String> {
        val res = ArrayList<String>()
        fun dc(k: String): String {
            val r = ShizukuHelper.shell(arrayOf("device_config", "get", "activity_manager", k))
            return if (r.first == 0) r.second.ifEmpty { "(kosong)" } else "(tidak terbaca: ${r.third.take(60)})"
        }
        res.add("max_cached_processes = " + dc("max_cached_processes"))
        res.add("max_phantom_processes = " + dc("max_phantom_processes"))
        val s = ShizukuHelper.shell(arrayOf("settings", "get", "global", "activity_manager_constants"))
        res.add("activity_manager_constants = " + (if (s.first == 0) s.second.ifEmpty { "(kosong)" } else "(tidak terbaca)"))
        return res
    }
}
