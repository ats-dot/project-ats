package com.ats_tsalatsah.app

import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.provider.Settings

// Menyalakan layanan Aksesibilitas aplikasi ini lewat Shizuku, tanpa membuka Setelan.
// Android mematikan layanan itu saat aplikasi di-force stop, crash, atau diperbarui.
object A11yEnabler {

    private const val KEY = "enabled_accessibility_services"

    private fun ours(ctx: Context): ComponentName = ComponentName(ctx, OcrA11yService::class.java)

    private fun entries(ctx: Context): List<String> {
        val raw = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return raw.split(':').filter { it.isNotBlank() }
    }

    private fun isOurs(ctx: Context, entry: String): Boolean {
        val cn = ComponentName.unflattenFromString(entry) ?: return false
        return cn == ours(ctx)
    }

    fun isListed(ctx: Context): Boolean = entries(ctx).any { isOurs(ctx, it) }

    // Tulis daftar layanan. Layanan aplikasi lain tidak diubah.
    private fun write(list: List<String>): Pair<Boolean, String> {
        if (list.isEmpty()) {
            return ShizukuHelper.exec(arrayOf("settings", "delete", "secure", KEY), 4000L)
        }
        return ShizukuHelper.exec(arrayOf("settings", "put", "secure", KEY, list.joinToString(":")), 4000L)
    }

    private fun waitRunning(ms: Long): Boolean {
        val end = SystemClock.uptimeMillis() + ms
        while (SystemClock.uptimeMillis() < end) {
            if (OcrA11yService.isRunning()) return true
            try {
                Thread.sleep(100)
            } catch (e: InterruptedException) {
                return false
            }
        }
        return OcrA11yService.isRunning()
    }

    // Pastikan layanan Aksesibilitas menyala. true = sudah tersambung.
    // @Synchronized: pemanggil kedua menunggu yang pertama selesai, lalu langsung lolos.
    @Synchronized
    fun ensure(ctx: Context, log: (String) -> Unit): Boolean {
        if (OcrA11yService.isRunning()) return true
        if (!ShizukuHelper.hasPermission()) {
            log("Aksesibilitas mati dan Shizuku belum diizinkan, tidak bisa dinyalakan otomatis")
            return false
        }
        val t0 = SystemClock.uptimeMillis()
        try {
            // Sudah terdaftar tapi belum tersambung (misal habis crash):
            // tunggu sebentar, kalau tetap belum jalan, matikan lalu nyalakan lagi.
            if (isListed(ctx)) {
                if (waitRunning(1500L)) return true
                write(entries(ctx).filterNot { isOurs(ctx, it) })
                Thread.sleep(400)
            }

            val list = entries(ctx).filterNot { isOurs(ctx, it) } + ours(ctx).flattenToString()
            val r1 = write(list)
            if (!r1.first) {
                log("Gagal menyalakan Aksesibilitas otomatis: ${r1.second}")
                return false
            }
            ShizukuHelper.exec(arrayOf("settings", "put", "secure", "accessibility_enabled", "1"), 4000L)

            if (waitRunning(4000L)) {
                log("Aksesibilitas dinyalakan otomatis lewat Shizuku (${SystemClock.uptimeMillis() - t0} ms)")
                return true
            }
            log("Aksesibilitas sudah didaftarkan tapi belum tersambung setelah 4 detik. Coba nyalakan manual di Setelan.")
            return false
        } catch (e: Throwable) {
            log("Gagal menyalakan Aksesibilitas otomatis: ${e.javaClass.simpleName}")
            return false
        }
    }
}
