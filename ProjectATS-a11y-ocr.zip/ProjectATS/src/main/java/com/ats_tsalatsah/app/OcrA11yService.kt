package com.ats_tsalatsah.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

// Layanan Aksesibilitas: screenshot cepat + ketukan + titik melayang tak terlihat.
// Semua fungsi capture()/tap() MEMBLOKIR, jadi panggil dari thread latar, jangan dari main thread.
class OcrA11yService : AccessibilityService() {

    companion object {
        @Volatile var instance: OcrA11yService? = null
            private set

        fun isRunning(): Boolean = instance != null

        // Jarak minimal antar screenshot (ms). Naik ke GAP_SLOW kalau sistem menolak (kode 3).
        const val GAP_NORMAL = 345L
        const val GAP_SLOW = 420L

        const val CODE_OK = 0
        const val CODE_TIMEOUT = -2

        fun errName(code: Int): String = when (code) {
            CODE_OK -> "OK"
            CODE_TIMEOUT -> "tidak ada jawaban dari sistem (timeout)"
            1 -> "error internal sistem (kode 1)"
            2 -> "tidak ada akses Aksesibilitas (kode 2)"
            3 -> "terlalu sering, jeda dinaikkan ke $GAP_SLOW ms (kode 3)"
            4 -> "display tidak valid (kode 4)"
            5 -> "jendela tidak valid (kode 5)"
            6 -> "layar dilindungi FLAG_SECURE, tidak bisa difoto (kode 6)"
            else -> "gagal (kode $code)"
        }
    }

    // bmp = gambar ARGB_8888 (boleh getPixel & ML Kit), atau null kalau gagal.
    // ms = lama screenshot sampai salinan selesai, waitMs = lama menunggu jeda minimal.
    class Shot(val bmp: Bitmap?, val code: Int, val ms: Long, val waitMs: Long)

    private lateinit var cbExec: ExecutorService
    private val shotLock = Any()
    @Volatile private var gap = GAP_NORMAL
    @Volatile private var lastShot = 0L
    private var dot: View? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        CrashLog.install(this)
        cbExec = Executors.newSingleThreadExecutor()
        instance = this
        addDot()
        RunnerService.initStore(this)
        RunnerService.addLog("Aksesibilitas aktif, titik melayang dipasang")
        val w = Thread { ScreenOcr.warmUp() }
        w.isDaemon = true
        w.start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        removeDot()
        if (instance === this) instance = null
        if (::cbExec.isInitialized) cbExec.shutdown()
    }

    // -----------------------------------------------------------------
    // Titik melayang 14 dp, tanpa warna, tidak bisa disentuh/difokus.
    // Membuat sistem menganggap aplikasi punya jendela terlihat saat game di depan.
    // -----------------------------------------------------------------

    private fun addDot() {
        if (dot != null) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val v = View(this)
            v.setBackgroundColor(Color.TRANSPARENT)
            val size = (14f * resources.displayMetrics.density).toInt()
            val lp = WindowManager.LayoutParams(
                size,
                size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.START
            wm.addView(v, lp)
            dot = v
        } catch (e: Throwable) {
            RunnerService.addLog("Titik melayang gagal dipasang: ${e.javaClass.simpleName}")
        }
    }

    private fun removeDot() {
        val v = dot ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Throwable) {
        }
        dot = null
    }

    // -----------------------------------------------------------------
    // Screenshot
    // -----------------------------------------------------------------

    fun capture(timeoutMs: Long = 2000L): Shot {
        synchronized(shotLock) {
            // Jaga jarak minimal dari screenshot sebelumnya
            val wait = lastShot + gap - SystemClock.uptimeMillis()
            if (wait > 0) Thread.sleep(wait)

            val t0 = SystemClock.uptimeMillis()
            lastShot = t0
            var bmp: Bitmap? = null
            var code = CODE_TIMEOUT
            val abandoned = AtomicBoolean(false)
            val latch = CountDownLatch(1)

            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    cbExec,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                            var copy: Bitmap? = null
                            var c = 1
                            try {
                                val hb = result.hardwareBuffer
                                val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                                // Salin ke memori biasa supaya getPixel & ML Kit bisa memakainya
                                copy = hw?.copy(Bitmap.Config.ARGB_8888, false)
                                hw?.recycle()
                                hb.close()
                                if (copy != null) c = CODE_OK
                            } catch (e: Throwable) {
                                c = 1
                            }
                            if (abandoned.get()) {
                                copy?.recycle()
                            } else {
                                bmp = copy
                                code = c
                            }
                            latch.countDown()
                        }

                        override fun onFailure(errorCode: Int) {
                            code = errorCode
                            latch.countDown()
                        }
                    }
                )
            } catch (e: Throwable) {
                return Shot(null, 1, SystemClock.uptimeMillis() - t0, maxOf(0L, wait))
            }

            if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) {
                abandoned.set(true)
                return Shot(null, CODE_TIMEOUT, SystemClock.uptimeMillis() - t0, maxOf(0L, wait))
            }
            if (code == 3) gap = GAP_SLOW
            return Shot(bmp, code, SystemClock.uptimeMillis() - t0, maxOf(0L, wait))
        }
    }

    // -----------------------------------------------------------------
    // Ketukan satu kali di koordinat layar penuh (piksel)
    // -----------------------------------------------------------------

    fun tap(x: Float, y: Float, timeoutMs: Long = 1000L): Boolean {
        return try {
            val p = Path()
            p.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0L, 50L))
                .build()
            var ok = false
            val latch = CountDownLatch(1)
            val sent = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            }, null)
            if (!sent) return false
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            ok
        } catch (e: Throwable) {
            false
        }
    }
}
