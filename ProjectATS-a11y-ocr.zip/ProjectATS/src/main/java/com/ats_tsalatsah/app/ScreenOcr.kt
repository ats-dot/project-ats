package com.ats_tsalatsah.app

import android.graphics.Bitmap
import android.graphics.Rect
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

// Area layar dalam pecahan 0..1, jadi tidak tergantung resolusi.
data class Area(
    val name: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    fun toRect(w: Int, h: Int): Rect {
        val l = (left * w).toInt().coerceIn(0, w - 1)
        val t = (top * h).toInt().coerceIn(0, h - 1)
        val r = (right * w).toInt().coerceIn(l + 1, w)
        val b = (bottom * h).toInt().coerceIn(t + 1, h)
        return Rect(l, t, r, b)
    }

    companion object {
        val FULL = Area("layar penuh", 0f, 0f, 1f, 1f)
        val TOP_BAR = Area("bar atas", 0f, 0f, 1f, 0.15f)
        val BOTTOM_STRIP = Area("strip bawah", 0f, 0.82f, 1f, 1f)
        val LEFT_MENU = Area("menu kiri", 0f, 0f, 0.3f, 1f)
        // Popup "Info Sistem" di tengah layar (tombol Login kembali)
        val POPUP_CENTER = Area("popup tengah", 0.3f, 0.25f, 0.7f, 0.78f)
        // Judul "Create Character" (kanan atas panel)
        val RIGHT_TOP = Area("kanan atas", 0.5f, 0.15f, 1f, 0.45f)
    }
}

// Satu baris hasil OCR. box sudah di koordinat layar penuh (piksel), bisa null.
data class OcrLine(val text: String, val box: Rect?)

// timedOut = ML Kit tidak selesai dalam batas waktu; gambar masukan JANGAN di-recycle.
data class OcrResult(
    val lines: List<OcrLine>,
    val text: String,
    val ms: Long,
    val error: String?,
    val timedOut: Boolean
)

object ScreenOcr {

    const val MIN_SCALE = 0.5f
    private const val TIMEOUT_S = 6L

    // SATU instance untuk seluruh aplikasi, dibuat saat pertama dipakai
    private val recognizer: TextRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    // Panaskan model sekali supaya pembacaan pertama tidak lambat
    fun warmUp() {
        try {
            val b = Bitmap.createBitmap(64, 32, Bitmap.Config.ARGB_8888)
            Tasks.await(recognizer.process(InputImage.fromBitmap(b, 0)), TIMEOUT_S, TimeUnit.SECONDS)
            b.recycle()
        } catch (e: Throwable) {
        }
    }

    // Baca teks di area tertentu. full TIDAK di-recycle di sini (urusan pemanggil).
    // Panggil dari thread latar (Tasks.await memblokir).
    fun read(full: Bitmap, area: Area, scale: Float): OcrResult {
        val t0 = SystemClock.uptimeMillis()
        val s = scale.coerceIn(MIN_SCALE, 1f)
        val rect = area.toRect(full.width, full.height)
        var crop: Bitmap? = null
        var small: Bitmap? = null
        try {
            // (a) potong area
            val isFull = rect.left == 0 && rect.top == 0 &&
                rect.width() == full.width && rect.height() == full.height
            val c = if (isFull) full
            else Bitmap.createBitmap(full, rect.left, rect.top, rect.width(), rect.height())
            crop = c

            // (b) perkecil
            val sm = if (s < 0.999f) {
                Bitmap.createScaledBitmap(
                    c,
                    maxOf(1, (c.width * s).toInt()),
                    maxOf(1, (c.height * s).toInt()),
                    true
                )
            } else c
            small = sm

            val res = Tasks.await(
                recognizer.process(InputImage.fromBitmap(sm, 0)),
                TIMEOUT_S,
                TimeUnit.SECONDS
            )

            // (c) kembalikan koordinat ke layar penuh: bagi skala, tambah offset area
            val sx = sm.width.toFloat() / c.width
            val sy = sm.height.toFloat() / c.height
            val lines = ArrayList<OcrLine>()
            for (b in res.textBlocks) {
                for (l in b.lines) {
                    val bb = l.boundingBox
                    val box = if (bb == null) null else Rect(
                        (bb.left / sx).toInt() + rect.left,
                        (bb.top / sy).toInt() + rect.top,
                        (bb.right / sx).toInt() + rect.left,
                        (bb.bottom / sy).toInt() + rect.top
                    )
                    lines.add(OcrLine(l.text, box))
                }
            }

            if (sm !== c && sm !== full) sm.recycle()
            if (c !== full) c.recycle()
            return OcrResult(lines, res.text, SystemClock.uptimeMillis() - t0, null, false)
        } catch (e: Throwable) {
            val root = e.cause ?: e
            val timedOut = e is TimeoutException || root is TimeoutException
            // Gambar yang sedang dipakai ML Kit tidak di-recycle kalau timeout
            if (!timedOut) {
                val sm = small
                val c = crop
                if (sm != null && sm !== c && sm !== full) sm.recycle()
                if (c != null && c !== full) c.recycle()
            } else {
                val c = crop
                if (c != null && c !== full && c !== small) c.recycle()
            }
            return OcrResult(
                emptyList(), "",
                SystemClock.uptimeMillis() - t0,
                "OCR ${root.javaClass.simpleName} ${root.message ?: ""}".trim(),
                timedOut
            )
        }
    }
}
