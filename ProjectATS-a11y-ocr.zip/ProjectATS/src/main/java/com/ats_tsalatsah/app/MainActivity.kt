package com.ats_tsalatsah.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.Spanned
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.math.BigDecimal

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    // Tinggi hiasan header (kabut+pinus / gunung) dan jarak isi halaman
    // dari bawah judul, supaya hiasan terlihat utuh di atas kartu pertama
    private val DECOR_H = 130
    private val PAGE_TOP = 68
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    // ---------- Data ----------
    private data class AppItem(val name: String, val pkg: String)

    private class Ses(val head: String) {
        val rows = ArrayList<String>()
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var pal: Palette

    private var apps: List<AppItem> = emptyList()
    private var appsLoaded = false
    private var shown: List<AppItem> = emptyList()
    private val sel = HashSet<String>()
    private val openArc = HashSet<Int>()
    private var lastLogKey = ""
    private var loadingUi = false
    private var startTab = 0
    private var lastSes: Ses? = null
    private var lastSesNo = 0
    private var statusState = -1
    private var pulse: ObjectAnimator? = null
    private var sheetOpen = false

    private val rxDate = Regex("(\\d{4})-(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)")
    private val rxTime = Regex("\\d\\d:\\d\\d:\\d\\d(\\.\\d+)?")
    private val rxApk = Regex("^\\S+\\s+Buka [A-Za-z0-9_.]+\\s*$")
    private val rxSrv = Regex("Server \\d+ dicatat")
    private val mon = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    // ---------- View ----------
    private lateinit var root: FrameLayout
    private lateinit var pager: PagerView
    private lateinit var tabBar: TabBar
    private lateinit var navWrap: FrameLayout
    private lateinit var hdDot: View
    private lateinit var hdTxt: TextView

    // Cabang
    private lateinit var vReady: LinearLayout
    private lateinit var vRun: LinearLayout
    private lateinit var etTarget: EditText
    private lateinit var tvSel: TextView
    private lateinit var pSz: View
    private lateinit var pA11y: View
    private lateinit var pOv: View
    private lateinit var ring: RingView
    private lateinit var tvPhase: TextView
    private lateinit var tvFound: TextView
    private lateinit var tvTgt: TextView
    private lateinit var swNick: Switch
    private lateinit var etNick: EditText
    private lateinit var etNickStart: EditText
    private lateinit var tvNickWarn: TextView

    // Apps
    private lateinit var etQ: EditText
    private lateinit var etQf: EditText
    private lateinit var tvCount: TextView
    private lateinit var listView: ListView
    private lateinit var tvEmpty: TextView
    private val adapter = AppAdapter()

    // Aktivitas
    private lateinit var subBar: TabBar
    private lateinit var vLog: LinearLayout
    private lateinit var vArc: LinearLayout
    private lateinit var tvSrvTitle: TextView
    private lateinit var tvSrv: TextView
    private lateinit var tvNotesTop: TextView
    private lateinit var vNotesLine: View

    private lateinit var swKaitkan: Switch
    private lateinit var etKaitkan: EditText
    private lateinit var tvKaitkanWarn: TextView
    private var kaitkanSyncing = false
    private lateinit var stockPage: FrameLayout
    private lateinit var stockRows: LinearLayout
    private lateinit var tvStockCount: TextView
    private lateinit var swStock: Switch
    private lateinit var tvStockRow: TextView
    private lateinit var tvOvErr: TextView
    private var stockOpen = false
    private var stockSyncing = false
    private var stockVer = -1
    private lateinit var tvStockTitle: TextView
    private lateinit var tvStockHint: TextView
    private lateinit var stockCard: LinearLayout
    private lateinit var stockEmptyTv: TextView
    private var stockSrc: StockSrc = EmailSrc
    private var stockCountShown = -1
    private var stockCountAnim: ValueAnimator? = null
    private lateinit var tvNickStockRow: TextView
    private var nickFieldAuto = false
    private var manualNick = ""
    private lateinit var stockHeadNormal: LinearLayout
    private lateinit var stockHeadSel: LinearLayout
    private lateinit var tvStockSelCount: TextView
    private lateinit var stockBar: LinearLayout
    private lateinit var stockFab: TextView
    private lateinit var stockScroll: ScrollView
    private lateinit var stockMenuLayer: FrameLayout
    private lateinit var stockMenuCard: LinearLayout
    private var stockSelMode = false
    private val stockSel = LinkedHashSet<String>()
    private var stockSelShown: Set<String> = emptySet()
    private var stockDragging = false
    private var stockDragAnchor = -1
    private var stockDragBase: Set<String> = emptySet()
    private var stockLastRawY = 0f
    private var stockMenuOpen = false
    private val stockHandler = Handler(Looper.getMainLooper())
    private val dragScroller = object : Runnable {
        override fun run() {
            if (!stockDragging) return
            val loc = IntArray(2)
            stockScroll.getLocationOnScreen(loc)
            val top = loc[1].toFloat()
            val bottom = top + stockScroll.height
            val edge = dp(80).toFloat()
            if (stockLastRawY < top + edge) stockScroll.scrollBy(0, -dp(10))
            else if (stockLastRawY > bottom - edge) stockScroll.scrollBy(0, dp(10))
            dragSelectAt(stockLastRawY)
            stockHandler.postDelayed(this, 16)
        }
    }
    private lateinit var tvLogEmpty: TextView
    private lateinit var sesBox: LinearLayout
    private lateinit var tvLogTitle: TextView
    private lateinit var tvLogBody: TextView
    private lateinit var bDlLast: View
    private lateinit var arcBox: LinearLayout

    // Setelan
    private lateinit var etD1: EditText
    private lateinit var etD2: EditText
    private lateinit var etD3: EditText
    private lateinit var swAnim: Switch
    private lateinit var swTapOn: Switch
    private lateinit var etTapMs: EditText
    private lateinit var etTapX: EditText
    private lateinit var etTapY: EditText
    private lateinit var swFirst: Switch
    private lateinit var etFirstMax: EditText
    private lateinit var etAfterTap: EditText
    private lateinit var etLoginKeys: EditText
    private lateinit var dOv: View
    private lateinit var dSz: View
    private lateinit var dA11y: View
    private lateinit var dBat: View

    // Lembar bawah (menu titik tiga)
    private lateinit var dim: View
    private lateinit var sheet: LinearLayout
    private lateinit var sheetMenu: LinearLayout
    private lateinit var sheetHelp: LinearLayout
    private lateinit var helpScroll: ScrollView

    private val ticker = object : Runnable {
        override fun run() {
            if (!uiReady) return
            poll()
            if (uiReady) main.postDelayed(this, 700)
        }
    }

    // =====================================================================
    // Siklus hidup
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keyboard tidak muncul sendiri saat jendela dibuka lagi; baru muncul kalau kotak diketuk
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        CrashLog.install(this)
        RunnerService.initStore(this)
        prefs = getSharedPreferences("ats_ui", Context.MODE_PRIVATE)
        pal = Themes.of(prefs.getString("theme", "dark") != "light")
        startTab = savedInstanceState?.getInt("tab", 0) ?: 0

        autoEnableA11y()

        // Ada crash dari pembukaan sebelumnya? Tampilkan dulu pesannya.
        val crash = CrashLog.takeReport(this)
        if (crash != null) {
            showCrashScreen("Aplikasi sempat berhenti mendadak", crash)
            return
        }
        startNormal()
    }

    private var uiReady = false

    // Susun tampilan utama. Error di sini ditangkap dan ditampilkan.
    private fun startNormal() {
        uiReady = false
        try {
            window.statusBarColor = pal.bg
            window.navigationBarColor = pal.bg
            window.setBackgroundDrawable(ColorDrawable(pal.bg))
            setContentView(buildRoot())
            root.requestFocus()
            setupWindow()
            loadSettings()
            if (appsLoaded) {
                tvEmpty.text = "Tidak ada aplikasi."
                renderApps()
            } else {
                loadApps()
            }
            val tab = startTab
            pager.post {
                if (!uiReady) return@post
                pager.animateTo(tab, false)
                tabBar.pos = tab.toFloat()
            }
            uiReady = true
            poll()
            main.removeCallbacks(ticker)
            main.post(ticker)
        } catch (e: Throwable) {
            showCrashScreen("Tampilan gagal disusun", android.util.Log.getStackTraceString(e))
            return
        }
        // Izin notifikasi diminta setelah tampilan siap
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            // Ditunda: kalau Shizuku siap, izin ini diberikan otomatis dan dialognya tidak perlu muncul
            main.postDelayed({
                if (!isFinishing && !isDestroyed && !AutoPerms.notifOk(this)) {
                    requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                }
            }, 2500)
        }
    }

    // Layar darurat: pesan error lengkap + tombol salin / coba lagi / reset tema.
    // Sengaja dibuat sederhana supaya tidak ikut error.
    private fun showCrashScreen(title: String, report: String) {
        uiReady = false
        main.removeCallbacks(ticker)
        try {
            RunnerService.addLog("ERROR: $title")
            report.lines().filter { it.isNotBlank() }.take(14).forEach { RunnerService.addLog("  " + it.trim()) }
        } catch (e: Throwable) {
        }
        val bg = Color.parseColor("#111313")
        val fg = Color.parseColor("#E9ECEB")
        val mu = Color.parseColor("#8C9392")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(px(20), px(32), px(20), px(32))
        sv.addView(box)

        val t = TextView(this)
        t.text = title
        t.setTextColor(fg)
        t.textSize = 20f
        t.typeface = Typeface.DEFAULT_BOLD
        box.addView(t)

        val info = TextView(this)
        info.text = "Salin atau screenshot pesan di bawah ini lalu kirim ke pengembang. " +
            "Aplikasi tidak tertutup, jadi kamu bisa coba lagi."
        info.setTextColor(mu)
        info.textSize = 14f
        info.setPadding(0, px(8), 0, px(16))
        box.addView(info)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(label: String, onClick: () -> Unit) {
            val b = TextView(this)
            b.text = label
            b.setTextColor(Color.parseColor("#121414"))
            b.textSize = 14f
            b.typeface = Typeface.DEFAULT_BOLD
            b.setPadding(px(14), px(9), px(14), px(9))
            val g = GradientDrawable()
            g.setColor(Color.parseColor("#D9DEDD"))
            g.cornerRadius = px(99).toFloat()
            b.background = g
            b.setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = px(8)
            row.addView(b, lp)
        }
        btn("Salin") {
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("error", "$title\n$report"))
                Toast.makeText(this, "Pesan error disalin", Toast.LENGTH_SHORT).show()
            } catch (e: Throwable) {
            }
        }
        btn("Coba lagi") { startNormal() }
        btn("Reset tema") {
            prefs.edit().putString("theme", "dark").apply()
            pal = Themes.of(true)
            startNormal()
        }
        box.addView(row)

        val r = TextView(this)
        r.text = report
        r.setTextColor(fg)
        r.textSize = 11f
        r.typeface = Typeface.MONOSPACE
        r.setTextIsSelectable(true)
        r.setPadding(0, px(18), 0, 0)
        box.addView(r)

        setContentView(sv)
    }

    private fun setupWindow() {
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        val lightBars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (pal.dark) 0 else lightBars, lightBars)
    }

    // Ganti tema langsung di tempat (tanpa membuat ulang Activity)
    private fun applyTheme(dark: Boolean) {
        startTab = if (::pager.isInitialized) pager.current else 0
        pal = Themes.of(dark)
        pulse?.cancel()
        pulse = null
        statusState = -1
        lastLogKey = ""
        sheetOpen = false
        hideKeyboard()
        startNormal()
        if (uiReady) {
            root.alpha = 0f
            root.animate().alpha(1f).setDuration(280).start()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::pager.isInitialized) outState.putInt("tab", pager.current)
    }

    override fun onResume() {
        super.onResume()
        autoEnableA11y()
        main.removeCallbacks(ticker)
        if (uiReady) main.post(ticker)
    }

    // Jalur A: nyalakan layanan Aksesibilitas sendiri (kalau izin WRITE_SECURE_SETTINGS sudah ada)
    private fun autoEnableA11y() {
        try {
            SecureA11y.ensure(this)
        } catch (e: Throwable) {
        }
    }

    override fun onPause() {
        hideKeyboard()
        main.removeCallbacks(ticker)
        super.onPause()
    }

    // Tombol utama (Home) ditekan: tutup keyboard dulu
    override fun onUserLeaveHint() {
        hideKeyboard()
        super.onUserLeaveHint()
    }

    override fun onDestroy() {
        pulse?.cancel()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!uiReady) {
            super.onBackPressed()
            return
        }
        when {
            stockOpen -> stockBack()
            sheetOpen -> {
                if (sheetHelp.visibility == View.VISIBLE) showSheetMenu() else closeSheet()
            }
            pager.current != 0 -> showTab(0)
            else -> super.onBackPressed()
        }
    }

    // =====================================================================
    // Pembantu tampilan
    // =====================================================================

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun dp(v: Int): Int = dp(v.toFloat())

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) g.setStroke(maxOf(1, dp(0.6f)), stroke)
        return g
    }

    private fun pressable(bg: Drawable): RippleDrawable {
        val rip = if (pal.dark) 0x33FFFFFF else 0x22000000
        return RippleDrawable(ColorStateList.valueOf(rip), bg, null)
    }

    private fun lpMW(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = top
        lp.bottomMargin = bottom
        return lp
    }

    private fun lpWW(top: Int = 0, bottom: Int = 0, left: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = top
        lp.bottomMargin = bottom
        lp.leftMargin = left
        return lp
    }

    private fun lpWeight(left: Int = 0, right: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = left
        lp.rightMargin = right
        return lp
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    private fun text(s: String, sizeSp: Float, color: Int = pal.text, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun mono(s: String): TextView {
        val t = text(s, 12f, pal.text)
        t.typeface = Typeface.MONOSPACE
        t.setLineSpacing(0f, 1.4f)
        t.setTextIsSelectable(true)
        return t
    }

    private fun card(): LinearLayout {
        val c = vbox()
        c.background = rounded(pal.card, 22f, pal.border)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.layoutParams = lpMW(bottom = dp(10))
        return c
    }

    // Tombol kecil berbentuk pil
    private fun chip(s: String, filled: Boolean = false, onClick: () -> Unit): TextView {
        val t = text(s, 13f, if (filled) pal.onPrimary else pal.text, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(7), dp(14), dp(7))
        t.background = pressable(
            if (filled) rounded(pal.primary, 999f) else rounded(pal.card, 999f, pal.borderStrong)
        )
        t.isClickable = true
        t.setOnClickListener { onClick() }
        pressFx(t)
        return t
    }

    // Tombol bundar kecil berikon (Unduh, Hapus). kind: 0 unduh, 1 hapus
    private fun iconChip(kind: Int, desc: String, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.card)
        g.setStroke(maxOf(1, dp(0.6f)), pal.borderStrong)
        f.background = pressable(g)
        f.isClickable = true
        f.contentDescription = desc
        f.setOnClickListener { onClick() }
        f.addView(GlyphView(this, kind, pal.text), FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        pressFx(f)
        return f
    }

    private fun lpIcon(left: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(dp(36), dp(36))
        lp.leftMargin = left
        return lp
    }

    // Pil berikon + tulisan (untuk aksi yang butuh keterangan, misal Hapus semua arsip)
    private fun iconTextChip(kind: Int, s: String, onClick: () -> Unit): LinearLayout {
        val b = hbox()
        b.gravity = Gravity.CENTER
        b.background = pressable(rounded(pal.card, 999f, pal.borderStrong))
        b.setPadding(dp(12), dp(7), dp(14), dp(7))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        b.addView(GlyphView(this, kind, pal.text), LinearLayout.LayoutParams(dp(16), dp(16)))
        b.addView(text(s, 13f, pal.text, true), lpWW(left = dp(6)))
        pressFx(b)
        return b
    }

    // Tombol besar penuh lebar
    private fun bigButton(s: String, filled: Boolean, onClick: () -> Unit): LinearLayout {
        val b = hbox()
        b.gravity = Gravity.CENTER
        b.background = pressable(
            if (filled) rounded(pal.primary, 999f) else rounded(Color.TRANSPARENT, 999f, pal.borderStrong)
        )
        b.setPadding(dp(18), dp(16), dp(18), dp(16))
        b.isClickable = true
        if (filled) b.addView(PlayIcon(this, pal.onPrimary), LinearLayout.LayoutParams(dp(18), dp(18)))
        val t = text(s, 16f, if (filled) pal.onPrimary else pal.text, true)
        b.addView(t, lpWW(left = if (filled) dp(10) else 0))
        b.setOnClickListener { onClick() }
        pressFx(b, 0.97f)
        return b
    }

    // Efek tekan seragam untuk semua tombol: mengecil sedikit saat ditekan, kembali halus saat dilepas.
    // Tidak menelan sentuhan (mengembalikan false), jadi klik dan ripple tetap jalan
    private fun pressFx(v: View, depth: Float = 0.96f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(depth).scaleY(depth).setDuration(90).setInterpolator(IOS_EASE).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(IOS_EASE).start()
            }
            false
        }
    }

    // Tombol bundar 38 dp berikon gambar (kembali, titik tiga, tutup) yang tepat di tengah
    private fun glyphRound(kind: Int, desc: String, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.card)
        g.setStroke(maxOf(1, dp(0.6f)), pal.borderStrong)
        f.background = pressable(g)
        f.isClickable = true
        f.contentDescription = desc
        f.setOnClickListener { onClick() }
        f.addView(GlyphView(this, kind, pal.text), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        pressFx(f)
        return f
    }

    private fun roundIcon(s: String, onClick: () -> Unit): TextView {
        val t = text(s, 22f, pal.text)
        t.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.card)
        g.setStroke(maxOf(1, dp(0.6f)), pal.borderStrong)
        t.background = pressable(g)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        pressFx(t)
        return t
    }

    private fun setEnabledLook(v: View, en: Boolean) {
        if (v.isEnabled != en) v.isEnabled = en
        v.alpha = if (en) 1f else 0.4f
    }

    private fun dot(sizeDp: Int = 8): View {
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.dotOff)
        v.background = g
        v.tag = null
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun setDotColor(v: View, color: Int) {
        if (v.tag == color) return
        v.tag = color
        (v.background as GradientDrawable).setColor(color)
    }

    private fun setDot(v: View, ok: Boolean) = setDotColor(v, if (ok) pal.dotOn else pal.dotOff)

    private fun input(numeric: Boolean, hintText: String = "", pill: Boolean = false): EditText {
        val e = EditText(this)
        e.setTextColor(pal.text)
        e.setHintTextColor(pal.hint)
        e.hint = hintText
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        e.background = rounded(pal.field, if (pill) 999f else 14f, pal.border)
        e.setPadding(dp(14), dp(10), dp(14), dp(10))
        e.inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        e.setSingleLine(true)
        closeOnDone(e)
        if (Build.VERSION.SDK_INT >= 29) e.textCursorDrawable = rounded(pal.text, 1f).also {
            it.setSize(dp(2), dp(20))
        }
        return e
    }

    private fun switchView(): Switch {
        val s = Switch(this)
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(st, intArrayOf(pal.onPrimary, pal.muted))
        s.trackTintList = ColorStateList(st, intArrayOf(pal.primary, pal.borderStrong))
        return s
    }

    private fun watch(e: EditText, f: () -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                f()
            }
        })
    }

    private fun setIfChanged(t: TextView, s: String) {
        if (t.text.toString() != s) t.text = s
    }

    private fun scrollPage(): Pair<ScrollView, LinearLayout> {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.isVerticalScrollBarEnabled = false
        sv.clipToPadding = false
        val inner = vbox()
        inner.setPadding(dp(16), dp(PAGE_TOP), dp(16), dp(110))
        sv.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        return Pair(sv, inner)
    }

    // Tutup keyboard, lepas fokus dari kotak isian, lalu kembalikan fokus ke root
    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val tok = window.decorView.windowToken
            if (tok != null) imm.hideSoftInputFromWindow(tok, 0)
            currentFocus?.clearFocus()
            if (::root.isInitialized) root.requestFocus()
        } catch (e: Throwable) {
        }
    }

    // 1. Tombol aksi keyboard jadi centang ("Selesai") dan menutup keyboard
    private fun closeOnDone(e: EditText) {
        e.imeOptions = EditorInfo.IME_ACTION_DONE
        e.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            true
        }
    }

    // 5. Sentuhan di luar kotak isian yang sedang fokus menutup keyboard
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f is EditText) {
                val r = Rect()
                f.getGlobalVisibleRect(r)
                if (!r.contains(ev.rawX.toInt(), ev.rawY.toInt())) hideKeyboard()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun dialogTheme(): Int =
        if (pal.dark) android.R.style.Theme_DeviceDefault_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert

    private fun alert(msg: String) {
        if (isFinishing) return
        Dlg(this, pal).message(msg).positive("OK").show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun open(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Susunan layar
    // =====================================================================

    private fun buildRoot(): View {
        root = SafeFrame(this) { e ->
            showCrashScreen("Tampilan mengalami error", android.util.Log.getStackTraceString(e))
        }
        root.setBackgroundColor(pal.bg)
        // Root yang memegang fokus, supaya tidak ada EditText yang otomatis terfokus
        root.isFocusable = true
        root.isFocusableInTouchMode = true

        // Hiasan header (kabut/pinus atau gunung)
        root.addView(HeaderDecor(this, pal), FrameLayout.LayoutParams(MATCH, dp(DECOR_H)))

        val col = vbox()
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildHeader(), LinearLayout.LayoutParams(MATCH, WRAP))

        pager = PagerView(this)
        pager.addView(buildPageCabang())
        pager.addView(buildPageApps())
        pager.addView(buildPageAktivitas())
        pager.addView(buildPageSetelan())
        col.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Menu tab bawah dengan pil meluncur
        tabBar = TabBar(this, pal, arrayOf("Cabang", "Apps", "Aktivitas", "Setelan"), 13f) { showTab(it) }
        tabBar.setPadding(dp(5), dp(5), dp(5), dp(5))
        tabBar.background = rounded(pal.navBg, 999f, pal.border)
        tabBar.elevation = dp(4).toFloat()
        navWrap = FrameLayout(this)
        navWrap.addView(tabBar, FrameLayout.LayoutParams(MATCH, WRAP))
        val nlp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        nlp.setMargins(dp(16), 0, dp(16), dp(16))
        root.addView(navWrap, nlp)

        pager.onScroll = { tabBar.pos = it }
        pager.onSelected = { hideKeyboard() }

        buildSheet()
        stockPage = buildStockPage()
        root.addView(stockPage, FrameLayout.LayoutParams(MATCH, MATCH))

        // Sembunyikan menu bawah saat keyboard muncul
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            root.getWindowVisibleDisplayFrame(r)
            val h = root.rootView.height
            val kb = h - r.bottom > h * 0.2
            val vis = if (kb) View.GONE else View.VISIBLE
            if (navWrap.visibility != vis) navWrap.visibility = vis
        }
        return root
    }

    private fun showTab(i: Int) {
        hideKeyboard()
        pager.animateTo(i)
    }

    private fun buildHeader(): View {
        val h = hbox()
        h.setPadding(dp(18), dp(18), dp(18), dp(14))
        h.addView(LogoView(this, pal, false), LinearLayout.LayoutParams(dp(30), dp(30)))
        h.addView(text("Project ats", 19f, pal.text, true), lpWeight(left = dp(10)))

        val pill = hbox()
        pill.background = pressable(rounded(if (pal.dark) 0xD9151717.toInt() else Color.WHITE, 999f, pal.borderStrong))
        pill.setPadding(dp(12), dp(6), dp(12), dp(6))
        hdDot = dot(8)
        hdTxt = text("Siap", 12f, pal.text, true)
        pill.addView(hdDot)
        pill.addView(hdTxt, lpWW(left = dp(7)))
        pill.isClickable = true
        pill.setOnClickListener { explainStatus() }
        pressFx(pill)
        h.addView(pill)
        return h
    }

    // ---------- Halaman Cabang ----------

    private fun buildPageCabang(): View {
        val (sv, box) = scrollPage()

        vReady = vbox()

        // Kartu target dengan hiasan
        val frame = FrameLayout(this)
        frame.background = rounded(pal.card, 26f, pal.border)
        frame.clipToOutline = true
        frame.addView(CardDecor(this, pal), FrameLayout.LayoutParams(MATCH, MATCH))
        val c1 = vbox()
        c1.gravity = Gravity.CENTER_HORIZONTAL
        c1.setPadding(dp(16), dp(18), dp(16), dp(16))
        c1.addView(text("Target server", 13f, pal.muted, true), lpWW())

        val step = hbox()
        etTarget = EditText(this)
        etTarget.setTextColor(pal.text)
        etTarget.setTextSize(TypedValue.COMPLEX_UNIT_SP, 46f)
        etTarget.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        etTarget.gravity = Gravity.CENTER
        etTarget.background = null
        etTarget.inputType = InputType.TYPE_CLASS_NUMBER
        etTarget.setSingleLine(true)
        closeOnDone(etTarget)
        step.addView(roundIcon("\u2212") { stepTarget(-1) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        step.addView(etTarget, lpWeight())
        step.addView(roundIcon("+") { stepTarget(1) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        c1.addView(step, lpMW(top = dp(6), bottom = dp(6)))

        if (pal.dark) c1.addView(GroundLine(this, pal), LinearLayout.LayoutParams(MATCH, dp(6)))
        tvSel = text("0 = tanpa target \u00B7 0 aplikasi dipilih", 12f, pal.muted)
        c1.addView(tvSel, lpWW(top = dp(10)))
        frame.addView(c1, FrameLayout.LayoutParams(MATCH, WRAP))
        vReady.addView(frame, lpMW(bottom = dp(10)))
        vReady.addView(buildNickCard())
        vReady.addView(buildKaitkanCard())

        // Status izin
        val pr = hbox()
        pSz = dot(7)
        pA11y = dot(7)
        pOv = dot(7)
        pr.addView(statusChip(pSz, "Shizuku"), lpWeight(right = dp(4)))
        pr.addView(statusChip(pA11y, "Akses"), lpWeight(left = dp(4), right = dp(4)))
        pr.addView(statusChip(pOv, "Overlay"), lpWeight(left = dp(4)))
        vReady.addView(pr, lpMW(bottom = dp(12)))

        vReady.addView(bigButton("Mulai", true) { doStart() }, lpMW())
        box.addView(vReady, lpMW())

        // Tampilan saat berjalan
        vRun = vbox()
        vRun.visibility = View.GONE
        val c3 = card()
        c3.gravity = Gravity.CENTER_HORIZONTAL
        ring = RingView(this, pal)
        c3.addView(ring, LinearLayout.LayoutParams(dp(180), dp(180)))
        tvPhase = text("Putaran 1", 12f, pal.text, true)
        tvPhase.background = rounded(Color.TRANSPARENT, 999f, pal.borderStrong)
        tvPhase.setPadding(dp(12), dp(5), dp(12), dp(5))
        c3.addView(tvPhase, lpWW(top = dp(4)))
        if (pal.dark) c3.addView(GroundLine(this, pal), LinearLayout.LayoutParams(MATCH, dp(6)).also {
            it.topMargin = dp(14)
        })
        vRun.addView(c3)

        val row = hbox()
        val cf = card()
        cf.gravity = Gravity.CENTER_HORIZONTAL
        tvFound = text("0", 30f, pal.text, true)
        tvFound.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        cf.addView(tvFound, lpWW())
        cf.addView(text("Server didapat", 12f, pal.muted), lpWW())
        val ct = card()
        ct.gravity = Gravity.CENTER_HORIZONTAL
        tvTgt = text("0", 30f, pal.text, true)
        tvTgt.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        ct.addView(tvTgt, lpWW())
        ct.addView(text("Target", 12f, pal.muted), lpWW())
        row.addView(cf, lpWeight(right = dp(5)))
        row.addView(ct, lpWeight(left = dp(5)))
        vRun.addView(row, lpMW(bottom = dp(4)))
        vRun.addView(bigButton("Hentikan", false) { doStop() }, lpMW())
        box.addView(vRun, lpMW())

        watch(etTarget) { saveSet() }
        watch(etNick) { saveSet() }
        watch(etNickStart) { saveSet() }
        swNick.setOnCheckedChangeListener { _, _ -> saveSet() }
        watch(etKaitkan) {
            if (!loadingUi && !kaitkanSyncing) {
                EmailStock.setField(this, etKaitkan.text.toString())
                updateKaitkan()
            }
        }
        swKaitkan.setOnCheckedChangeListener { _, on ->
            if (!loadingUi) {
                EmailStock.setKaitkanOn(this, on)
                updateKaitkan()
            }
        }
        return sv
    }

    // Kartu nickname otomatis (diisi di putaran 2 saat halaman Create Character muncul)
    private fun buildNickCard(): View {
        val c = card()
        val top = hbox()
        top.addView(text("Nickname otomatis", 14f, pal.text, true), lpWeight())
        swNick = switchView()
        top.addView(swNick)
        c.addView(top, lpMW(bottom = dp(10)))

        val row = hbox()
        row.gravity = Gravity.TOP
        val c1 = vbox()
        c1.addView(text("Nickname", 12f, pal.muted), lpMW(bottom = dp(4)))
        etNick = input(false, "Ats-")
        c1.addView(etNick)
        val c2 = vbox()
        c2.addView(text("Nomor awal", 12f, pal.muted), lpMW(bottom = dp(4)))
        etNickStart = input(true, "1")
        c2.addView(etNickStart)
        row.addView(c1, LinearLayout.LayoutParams(0, WRAP, 2f).also { it.rightMargin = dp(8) })
        row.addView(c2, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(row, lpMW())

        // Peringatan kecil, hanya muncul kalau nickname tidak bisa dipakai
        tvNickWarn = text("", 12f, pal.danger)
        tvNickWarn.visibility = View.GONE
        c.addView(tvNickWarn, lpMW(top = dp(8)))

        val dvN = View(this)
        dvN.setBackgroundColor(pal.border)
        c.addView(dvN, LinearLayout.LayoutParams(MATCH, 1).also { it.topMargin = dp(10) })
        tvNickStockRow = text("", 13f, pal.muted, true)
        c.addView(valueRow("Stok nickname", tvNickStockRow) { openStockPage(NickSrc) }, lpMW())

        return c
    }

    private fun statusChip(d: View, s: String): View {
        val p = hbox()
        p.gravity = Gravity.CENTER
        p.background = rounded(pal.card, 999f, pal.border)
        p.setPadding(dp(8), dp(9), dp(8), dp(9))
        p.addView(d)
        p.addView(text(s, 12f, pal.text, true), lpWW(left = dp(6)))
        return p
    }

    private fun stepTarget(delta: Int) {
        val n = etTarget.text.toString().toIntOrNull() ?: 0
        val v = maxOf(0, n + delta).toString()
        etTarget.setText(v)
        etTarget.setSelection(v.length)
    }

    // ---------- Halaman Apps ----------

    private fun buildPageApps(): View {
        val box = vbox()
        box.setPadding(dp(16), dp(PAGE_TOP), dp(16), dp(96))

        etQ = input(false, "Cari nama atau paket", pill = true)
        box.addView(etQ, lpMW())

        val r = hbox()
        r.addView(chip("Pilih hasil", true) {
            shown.forEach { sel.add(it.pkg) }
            renderApps()
        })
        r.addView(chip("Kosongkan") {
            sel.clear()
            renderApps()
        }, lpWW(left = dp(8)))
        r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        tvCount = text("0 dipilih", 12f, pal.muted, true)
        r.addView(tvCount)
        box.addView(r, lpMW(top = dp(10), bottom = dp(10)))

        val r2 = hbox()
        etQf = input(false, "Filter cepat, contoh: Mobile Legends", pill = true)
        r2.addView(etQf, lpWeight())
        r2.addView(chip("Pilih", true) { quickFilter() }, lpWW(left = dp(8)))
        box.addView(r2, lpMW(bottom = dp(10)))

        val c2 = vbox()
        c2.background = rounded(pal.card, 22f, pal.border)
        c2.setPadding(dp(14), dp(2), dp(14), dp(2))
        val frame = FrameLayout(this)
        listView = ListView(this)
        listView.divider = ColorDrawable(pal.border)
        listView.dividerHeight = 1
        listView.selector = ColorDrawable(Color.TRANSPARENT)
        listView.isVerticalScrollBarEnabled = false
        listView.adapter = adapter
        listView.setOnItemClickListener { _, view, pos, _ ->
            if (pos < 0 || pos >= shown.size) return@setOnItemClickListener
            val a = shown[pos]
            if (sel.contains(a.pkg)) sel.remove(a.pkg) else sel.add(a.pkg)
            ((view as LinearLayout).getChildAt(1) as CheckDot).setChecked(sel.contains(a.pkg), true)
            saveSel()
        }
        tvEmpty = text("Memuat...", 14f, pal.muted)
        tvEmpty.setPadding(0, dp(14), 0, dp(14))
        frame.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(tvEmpty, FrameLayout.LayoutParams(MATCH, WRAP))
        listView.emptyView = tvEmpty
        c2.addView(frame, LinearLayout.LayoutParams(MATCH, MATCH))
        box.addView(c2, LinearLayout.LayoutParams(MATCH, 0, 1f))

        watch(etQ) { renderApps() }
        watch(etQf) { saveSet() }
        return box
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: makeAppRow()
            val a = shown[position]
            val col = row.getChildAt(0) as LinearLayout
            (col.getChildAt(0) as TextView).text = a.name
            (col.getChildAt(1) as TextView).text = a.pkg
            (row.getChildAt(1) as CheckDot).setChecked(sel.contains(a.pkg), false)
            return row
        }
    }

    private fun makeAppRow(): LinearLayout {
        val row = hbox()
        row.setPadding(0, dp(11), 0, dp(11))
        row.background = pressable(rounded(Color.TRANSPARENT, 12f))
        val col = vbox()
        col.addView(text("", 14f, pal.text, true))
        val pkg = text("", 11f, pal.muted)
        pkg.typeface = Typeface.MONOSPACE
        col.addView(pkg)
        row.addView(col, lpWeight())
        row.addView(CheckDot(this, pal), LinearLayout.LayoutParams(dp(24), dp(24)).also { it.leftMargin = dp(10) })
        return row
    }

    private fun loadApps() {
        Thread {
            val list = try {
                val pm = packageManager
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(q, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                    .distinctBy { it.pkg }
                    .sortedBy { it.name.lowercase() }
            } catch (e: Throwable) {
                emptyList()
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                apps = list
                appsLoaded = true
                if (uiReady) {
                    tvEmpty.text = "Tidak ada aplikasi."
                    renderApps()
                }
            }
        }.start()
    }

    private fun renderApps() {
        val q = etQ.text.toString().lowercase()
        shown = apps.filter {
            q.isEmpty() || it.name.lowercase().contains(q) || it.pkg.lowercase().contains(q)
        }
        adapter.notifyDataSetChanged()
        saveSel()
    }

    private fun quickFilter() {
        val f = etQf.text.toString().lowercase().trim()
        if (f.isEmpty()) return
        apps.forEach {
            if (it.name.lowercase().contains(f) || it.pkg.lowercase().contains(f)) sel.add(it.pkg)
        }
        hideKeyboard()
        renderApps()
    }

    // ---------- Halaman Aktivitas ----------

    private fun buildPageAktivitas(): View {
        val (sv, box) = scrollPage()

        subBar = TabBar(this, pal, arrayOf("Log aktivitas", "Arsip"), 13f) { setSub(it) }
        subBar.setPadding(dp(4), dp(4), dp(4), dp(4))
        subBar.background = rounded(pal.card, 999f, pal.border)
        box.addView(subBar, lpMW(bottom = dp(12)))

        // Log
        vLog = vbox()
        val cs = card()
        val rs = hbox()
        tvSrvTitle = text("Catatan umum (0)", 14f, pal.text, true)
        rs.addView(tvSrvTitle, lpWeight())
        rs.addView(iconChip(1, "Hapus") {
            doDel("Hapus catatan umum? Log dan arsip tidak ikut terhapus.") { RunnerService.clearServers() }
        }, lpIcon())
        cs.addView(rs, lpMW(bottom = dp(8)))
        tvNotesTop = mono("")
        tvNotesTop.visibility = View.GONE
        cs.addView(tvNotesTop, lpMW())
        vNotesLine = View(this)
        vNotesLine.setBackgroundColor(pal.border)
        vNotesLine.visibility = View.GONE
        cs.addView(vNotesLine, LinearLayout.LayoutParams(MATCH, 1).also {
            it.topMargin = dp(6)
            it.bottomMargin = dp(6)
        })
        tvSrv = mono("Belum ada catatan.")
        cs.addView(tvSrv, lpMW())
        vLog.addView(cs)

        val cl = card()
        val rl = hbox()
        rl.addView(text("Sesi terakhir", 14f, pal.text, true), lpWeight())
        bDlLast = iconChip(0, "Unduh") {
            val s = lastSes
            if (s != null) downloadSession(lastSesNo, s) else toast("Belum ada sesi untuk diunduh")
        }
        rl.addView(bDlLast, lpIcon())
        rl.addView(iconChip(1, "Hapus") {
            doDel("Hapus sesi terakhir? Arsip dan daftar server tidak ikut terhapus.") {
                RunnerService.clearLastSession()
            }
        }, lpIcon(dp(8)))
        cl.addView(rl, lpMW(bottom = dp(8)))
        tvLogEmpty = text("Belum ada aktivitas.", 13f, pal.muted)
        cl.addView(tvLogEmpty, lpMW())
        sesBox = vbox()
        sesBox.visibility = View.GONE
        tvLogTitle = text("", 12f, pal.muted)
        sesBox.addView(tvLogTitle, lpMW(bottom = dp(6)))
        tvLogBody = mono("")
        sesBox.addView(tvLogBody, lpMW())
        cl.addView(sesBox, lpMW())
        vLog.addView(cl)
        box.addView(vLog, lpMW())

        // Arsip
        vArc = vbox()
        vArc.visibility = View.GONE
        val ra = hbox()
        ra.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        ra.addView(iconTextChip(1, "Hapus semua arsip") {
            doDel("Hapus semua arsip? Sesi terakhir tetap ada.") { RunnerService.clearArchive() }
        })
        vArc.addView(ra, lpMW(bottom = dp(10)))
        arcBox = vbox()
        arcBox.addView(emptyArc())
        vArc.addView(arcBox, lpMW())
        box.addView(vArc, lpMW())

        return sv
    }

    private fun emptyArc(): View {
        val v = vbox()
        v.gravity = Gravity.CENTER_HORIZONTAL
        v.setPadding(0, dp(16), 0, dp(16))
        v.addView(EmptyArt(this, pal), LinearLayout.LayoutParams(dp(160), dp(150)))
        v.addView(text("Belum ada arsip", 13f, pal.muted), lpWW(top = dp(4)))
        return v
    }

    private fun setSub(n: Int) {
        subBar.animateTo(n)
        vLog.visibility = if (n == 0) View.VISIBLE else View.GONE
        vArc.visibility = if (n == 1) View.VISIBLE else View.GONE
    }

    private fun parseSessions(lines: List<String>): List<Ses> {
        val out = ArrayList<Ses>()
        var cur: Ses? = null
        for (l in lines) {
            if (l.contains(RunnerService.MARK)) {
                val s = Ses(l)
                out.add(s)
                cur = s
            } else {
                var c = cur
                if (c == null) {
                    c = Ses("")
                    out.add(c)
                    cur = c
                }
                c.rows.add(l)
            }
        }
        return out
    }

    private fun dateOf(head: String): String? {
        val m = rxDate.find(head) ?: return null
        val g = m.groupValues
        val mi = (g[2].toIntOrNull() ?: 0) - 1
        if (mi < 0 || mi >= mon.size) return null
        return "${g[3].toInt()} ${mon[mi]} ${g[1]}, ${g[4]}:${g[5]}"
    }

    private fun timeOf(head: String): String = rxTime.find(head)?.value ?: ""

    private fun whenOf(s: Ses): String {
        val t = timeOf(s.head)
        return dateOf(s.head) ?: ("tanggal tidak tercatat" + (if (t.isEmpty()) "" else " ($t)"))
    }

    private fun countApk(rows: List<String>): Int = rows.count { rxApk.containsMatchIn(it) }

    private fun countSrv(rows: List<String>): Int = rows.count { rxSrv.containsMatchIn(it) }

    private fun renderLog(lines: List<String>) {
        if (lines.isEmpty()) {
            if (lastLogKey == "kosong") return
            lastLogKey = "kosong"
            lastSes = null
            tvLogEmpty.visibility = View.VISIBLE
            sesBox.visibility = View.GONE
            arcBox.removeAllViews()
            arcBox.addView(emptyArc())
            return
        }
        val key = "${lines.size}|${lines[0]}|${lines[lines.size - 1]}"
        if (key == lastLogKey) return
        lastLogKey = key

        val ses = parseSessions(lines)
        val n = ses.size
        val last = ses[n - 1]
        lastSes = last
        lastSesNo = n
        tvLogTitle.text = "Sesi $n \u00B7 ${whenOf(last)}"
        tvLogBody.text = last.rows.asReversed().joinToString("\n").ifEmpty { "(kosong)" }
        tvLogEmpty.visibility = View.GONE
        sesBox.visibility = View.VISIBLE

        arcBox.removeAllViews()
        for (i in n - 2 downTo 0) arcBox.addView(arcItem(i, ses[i]))
        if (n < 2) arcBox.addView(emptyArc())
    }

    private fun arcItem(i: Int, s: Ses): View {
        val item = card()

        val hd = hbox()
        hd.isClickable = true
        val tc = vbox()
        tc.addView(text("Sesi ${i + 1}", 14f, pal.text, true))
        tc.addView(text(whenOf(s), 12f, pal.muted), lpMW(top = dp(2)))
        tc.addView(
            text("${countApk(s.rows)} apk dibuka \u00B7 ${countSrv(s.rows)} server didapat", 12f, pal.muted),
            lpMW(top = dp(2))
        )
        hd.addView(tc, lpWeight())
        hd.addView(iconChip(0, "Unduh") { downloadSession(i + 1, s) }, lpIcon(dp(6)))
        hd.addView(iconChip(1, "Hapus") {
            doDel("Hapus Sesi ${i + 1} dari arsip?") { RunnerService.deleteSession(i) }
        }, lpIcon(dp(8)))
        item.addView(hd, lpMW())

        val bd = mono(s.rows.asReversed().joinToString("\n").ifEmpty { "(kosong)" })
        bd.visibility = if (openArc.contains(i)) View.VISIBLE else View.GONE
        item.addView(bd, lpMW(top = dp(10)))

        hd.setOnClickListener {
            val o = bd.visibility != View.VISIBLE
            animateBody(bd, o)
            if (o) openArc.add(i) else openArc.remove(i)
        }
        return item
    }

    // Buka atau tutup isi kartu dengan tinggi yang berubah halus sambil memudar
    private fun animateBody(bd: View, open: Boolean) {
        bd.animate().cancel()
        val parent = bd.parent as? View
        if (parent == null || parent.width == 0) {
            bd.visibility = if (open) View.VISIBLE else View.GONE
            return
        }
        val lp = bd.layoutParams
        if (open) {
            bd.visibility = View.VISIBLE
            bd.measure(
                View.MeasureSpec.makeMeasureSpec(parent.width - parent.paddingLeft - parent.paddingRight, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val target = bd.measuredHeight
            bd.alpha = 0f
            lp.height = 0
            bd.layoutParams = lp
            val a = ValueAnimator.ofInt(0, target)
            a.duration = 280
            a.interpolator = IOS_EASE
            a.addUpdateListener {
                lp.height = it.animatedValue as Int
                bd.layoutParams = lp
                bd.alpha = it.animatedFraction
            }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(an: Animator) {
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    bd.layoutParams = lp
                    bd.alpha = 1f
                }
            })
            a.start()
        } else {
            val start = bd.height
            val a = ValueAnimator.ofInt(start, 0)
            a.duration = 240
            a.interpolator = IOS_EASE
            a.addUpdateListener {
                lp.height = it.animatedValue as Int
                bd.layoutParams = lp
                bd.alpha = 1f - it.animatedFraction
            }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(an: Animator) {
                    bd.visibility = View.GONE
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    bd.layoutParams = lp
                    bd.alpha = 1f
                }
            })
            a.start()
        }
    }

    // Simpan satu sesi ke folder Download sebagai "Sesi N.txt"
    private fun downloadSession(n: Int, s: Ses) {
        val name = "Sesi $n.txt"
        val sb = StringBuilder()
        sb.append("Project ats - Sesi ").append(n).append('\n')
        sb.append(whenOf(s)).append('\n')
        sb.append("${countApk(s.rows)} apk dibuka, ${countSrv(s.rows)} server didapat").append("\n\n")
        if (s.head.isNotEmpty()) sb.append(s.head).append('\n')
        s.rows.forEach { sb.append(it).append('\n') }
        val bytes = sb.toString().toByteArray(Charsets.UTF_8)

        Thread {
            val msg = try {
                val cr = contentResolver
                val cv = ContentValues()
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name)
                cv.put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                cv.put(MediaStore.Downloads.IS_PENDING, 1)
                val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("tidak bisa membuat file")
                val out = cr.openOutputStream(uri) ?: throw IllegalStateException("tidak bisa menulis file")
                out.use { it.write(bytes) }
                val done = ContentValues()
                done.put(MediaStore.Downloads.IS_PENDING, 0)
                cr.update(uri, done, null, null)
                // Nama sebenarnya (sistem menambah " (1)" kalau nama sudah ada)
                var real = name
                cr.query(uri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) real = c.getString(0) ?: name
                }
                "Tersimpan di Download/$real"
            } catch (e: Throwable) {
                "Gagal menyimpan: ${e.message ?: e.javaClass.simpleName}"
            }
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun doDel(msg: String, fn: () -> Boolean) {
        if (isFinishing) return
        Dlg(this, pal)
            .message(msg)
            .positive("Ya") {
                val ok = try {
                    fn()
                } catch (e: Throwable) {
                    true
                }
                if (!ok) {
                    alert("Tidak bisa dihapus saat sedang berjalan. Hentikan dulu.")
                } else {
                    lastLogKey = ""
                    openArc.clear()
                    poll()
                }
            }
            .negative("Batal")
            .show()
    }

    // ---------- Halaman Setelan ----------

    private fun sectionLabel(s: String): TextView {
        val t = text(s, 12f, pal.muted, true)
        t.layoutParams = lpMW(top = dp(14), bottom = dp(6)).also { it.leftMargin = dp(6) }
        return t
    }

    // Kartu kelompok; baris dipisah garis tipis
    private fun group(vararg rows: View): LinearLayout {
        val c = vbox()
        c.background = rounded(pal.card, 22f, pal.border)
        c.setPadding(dp(16), dp(4), dp(16), dp(4))
        rows.forEachIndexed { i, r ->
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(pal.border)
                c.addView(line, LinearLayout.LayoutParams(MATCH, 1))
            }
            c.addView(r, lpMW())
        }
        return c
    }

    // Baris angka: label kiri, kolom ms kanan
    private fun numRow(label: String, e: EditText): View {
        val h = hbox()
        h.setPadding(0, dp(10), 0, dp(10))
        h.addView(text(label, 14f, pal.text), lpWeight())
        e.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        e.typeface = Typeface.MONOSPACE
        h.addView(e, LinearLayout.LayoutParams(dp(112), WRAP))
        h.addView(text("ms", 12f, pal.muted), lpWW(left = dp(8)))
        return h
    }

    // Baris dengan tulisan status di kanan; seluruh baris bisa diketuk
    private fun valueRow(label: String, value: TextView, onClick: () -> Unit): View {
        val h = hbox()
        h.setPadding(0, dp(12), 0, dp(12))
        h.addView(text(label, 14f, pal.text), lpWeight())
        h.addView(value)
        h.addView(text("\u203A", 18f, pal.muted), lpWW(left = dp(8)))
        h.background = pressable(rounded(Color.TRANSPARENT, 12f))
        h.isClickable = true
        h.setOnClickListener { onClick() }
        pressFx(h, 0.985f)
        return h
    }

    private fun switchRow(label: String, s: Switch): View {
        val h = hbox()
        h.setPadding(0, dp(10), 0, dp(10))
        h.addView(text(label, 14f, pal.text), lpWeight())
        h.addView(s)
        h.setOnClickListener { s.toggle() }
        return h
    }

    private fun stackRow(label: String, e: EditText): View {
        val v = vbox()
        v.setPadding(0, dp(10), 0, dp(10))
        v.addView(text(label, 14f, pal.text), lpMW(bottom = dp(8)))
        v.addView(e, lpMW())
        return v
    }

    // Baris izin overlay + pesan kecil merah kalau pemberian otomatisnya gagal
    private fun overlayRow(): View {
        val box = vbox()
        box.addView(permRow(dOv, "Tampil di atas aplikasi") {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lpMW())
        tvOvErr = text("", 12f, pal.danger)
        tvOvErr.visibility = View.GONE
        tvOvErr.setPadding(dp(18), 0, 0, dp(10))
        box.addView(tvOvErr, lpMW())
        return box
    }

    private fun permRow(d: View, label: String, onClick: () -> Unit): View {
        val h = hbox()
        h.setPadding(0, dp(10), 0, dp(10))
        h.addView(d)
        h.addView(text(label, 14f, pal.text), lpWeight(left = dp(10)))
        h.addView(chip("Atur") { onClick() })
        return h
    }

    private fun buildPageSetelan(): View {
        val (sv, box) = scrollPage()

        val top = hbox()
        top.addView(text("Setelan", 18f, pal.text, true), lpWeight(left = dp(4)))
        val menu = glyphRound(6, "Menu") { openSheet() }
        top.addView(menu, LinearLayout.LayoutParams(dp(38), dp(38)))
        box.addView(top, lpMW(bottom = dp(2)))

        // Waktu
        etD1 = input(true)
        etD2 = input(true)
        etD3 = input(true)
        box.addView(sectionLabel("Waktu"))
        box.addView(group(
            numRow("Jeda putaran 1", etD1),
            numRow("Jeda putaran 2 (maks)", etD2),
            numRow("Jeda tengah", etD3)
        ))

        // Apk pertama
        swFirst = switchView()
        etFirstMax = input(true)
        etAfterTap = input(true)
        etLoginKeys = input(false, "Login kembali")
        box.addView(sectionLabel("Apk pertama"))
        box.addView(group(
            switchRow("Tunggu popup login", swFirst),
            numRow("Batas waktu", etFirstMax),
            numRow("Tunggu setelah ketuk", etAfterTap)
        ))

        // Ketukan Got it
        swTapOn = switchView()
        etTapMs = input(true)
        etTapX = input(true, "x")
        etTapY = input(true, "y")
        val xy = hbox()
        xy.setPadding(0, dp(10), 0, dp(10))
        xy.addView(text("Koordinat", 14f, pal.text), lpWeight())
        etTapX.gravity = Gravity.CENTER
        etTapY.gravity = Gravity.CENTER
        etTapX.typeface = Typeface.MONOSPACE
        etTapY.typeface = Typeface.MONOSPACE
        xy.addView(etTapX, LinearLayout.LayoutParams(dp(78), WRAP))
        xy.addView(etTapY, LinearLayout.LayoutParams(dp(78), WRAP).also { it.leftMargin = dp(8) })
        box.addView(sectionLabel("Ketukan Got it"))
        box.addView(group(
            switchRow("Ketuk otomatis", swTapOn),
            numRow("Waktu ketukan", etTapMs),
            xy
        ))


        // Pengaturan yang tidak lagi ditampilkan (fiturnya tetap jalan memakai nilai tersimpan): animasi sistem dimatikan saat proses
        swAnim = switchView()

        // Izin
        dOv = dot()
        dSz = dot()
        dA11y = dot()
        dBat = dot()
        box.addView(sectionLabel("Izin"))
        box.addView(group(
            permRow(dSz, "Shizuku") { ShizukuHelper.requestPermission() },
            permRow(dA11y, "Aksesibilitas") { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            overlayRow(),
            permRow(dBat, "Baterai tanpa batasan") { requestBattery() }
        ))

        listOf(etD1, etD2, etD3, etTapMs, etTapX, etTapY, etFirstMax, etAfterTap, etLoginKeys)
            .forEach { e -> watch(e) { saveSet() } }
        listOf(swAnim, swTapOn, swFirst).forEach { s ->
            s.setOnCheckedChangeListener { _, _ -> saveSet() }
        }
        return sv
    }

    // =====================================================================
    // Lembar bawah: menu titik tiga (penjelasan + tema)
    // =====================================================================

    private val helpItems = listOf(
        "Jeda putaran 1" to "Jatah waktu tiap aplikasi di putaran 1 untuk membaca server dari log. 1000 ms = 1 detik.",
        "Jeda putaran 2 (maks)" to "Batas maksimal menunggu layar Create Character. Kalau OCR aktif dan teksnya terbaca lebih cepat, langsung lanjut ke aplikasi berikutnya. Kalau OCR mati, jeda ini dipakai penuh.",
        "Jeda tengah" to "Waktu tetap untuk membersihkan aplikasi (force stop dan hapus dari recent) sebelum lanjut.",
        "Apk pertama" to "Aplikasi pertama di putaran 1 menunggu popup Info Sistem sampai batas waktu, sambil membaca servernya dari log. Kalau popup muncul, tombol diketuk dan ditunggu sesuai pengaturan Tunggu setelah ketuk (bawaan 1800 ms); selama itu servernya masih dibaca dari log. Server baru dicatat dan aplikasinya dibiarkan; server kembar atau tidak terbaca membuat aplikasinya dibersihkan. Kalau popup tidak muncul sampai batas waktu, aplikasi dibersihkan apa pun servernya. Aplikasi berikutnya memakai jeda putaran 1 biasa.",
        "Ketukan Got it" to "Mengetuk koordinat x, y satu kali di tiap aplikasi putaran 1, setelah waktu ketukan berlalu sejak aplikasi dibuka. Waktu ketukan harus lebih kecil dari jeda putaran 1. Layar mendatar 2400x1080; cek koordinat lewat Opsi pengembang > Lokasi penunjuk.",
        "Nickname otomatis" to "Di putaran 2, begitu halaman Create Character terbaca, kolom nama diketuk, nama acak dihapus, lalu nickname diketik sesuai urutan apk (misal Ats-1, Ats-2, dst). Setelah nama masuk ke kolom game, tombol Okay emas diketuk. Aplikasi baru pindah ke apk berikutnya kalau sudah masuk halaman Skip the Tutorial atau Select a hero. Di halaman Skip the Tutorial, tombol Skip diketuk dan aplikasi menunggu halaman Level Up muncul (batasnya sebesar jeda putaran 2) sebelum pindah. Tombol Continue tidak diketuk. Kalau masih macet di Create Character, langkahnya diulang sampai 3 kali. Popup Switch Account yang kadang muncul setelah loading ditutup otomatis dengan mengetuk tanda silang, dan waktu tunggu Create Character diperpanjang 10 detik karena popup itu berarti halamannya sudah dekat. Kalau apk tidak sampai Create Character, apk itu dilewati dan nomor berikutnya tetap sesuai urutan. Butuh Aksesibilitas dan Shizuku. Nickname dengan simbol khusus (misal •) diisi lewat clipboard lalu ditempel. Kalau Stok nickname nyala dan ada isinya, kolom Nickname menampilkan awalan paling atas stok. Saat Mulai ditekan, awalan itu dipakai untuk satu sesi penuh (awalan + nomor untuk tiap server) dan langsung keluar dari stok. Kalau stok kosong atau mati, kolom Nickname manual yang dipakai.",
        "Kaitkan otomatis" to "Di akhir putaran 2, email dikaitkan ke akun Moonton di apk terakhir yang sampai halaman Level Up. Alurnya: Continue, Shop, Purchase, Use Battle Points, tutup dialog, kembali, Profil, Account, ikon hadiah, Connect Now, MOONTON Account, isi email, Kirim, sampai muncul Email verifikasi telah dikirim. Butuh Nickname otomatis yang nyala. Kalau saklarnya mati, alur berhenti di halaman Level Up. Email diambil dari kolom Email; kalau Stok email nyala, kolom terisi email paling atas dari stok. Kalau satu langkah macet, alur berhenti dan alasannya dicatat di log.",
        "Stok nickname" to "Daftar awalan nickname, satu awalan per akun (misal SCRP-). Satu sesi memakai satu awalan: nama tiap server = awalan + nomor (SCRP-1, SCRP-2, dst). Awalan paling atas diambil saat Mulai ditekan dan langsung keluar dari stok, jadi tidak pernah dipakai dua akun. Tombol plus menambah awalan (boleh tempel banyak sekaligus, satu per baris; baris kembar atau di luar 3 sampai 17 karakter diabaikan dan dicoret), ketuk satu baris untuk Edit atau Hapus. Tahan satu baris lalu seret untuk memilih banyak sekaligus (bisa Salin atau Hapus), atau pakai tombol titik tiga di pojok kanan atas: Pilih banyak, Hapus semua. Saklar di pojok kanan atas halaman stok: mati berarti stok tidak dipakai. Kolom Nickname di tab Cabang menampilkan awalan teratas stok.",
        "Stok email" to "Daftar email yang dipakai bergantian, satu per sesi. Tombol plus menambah email (boleh tempel banyak sekaligus), ketuk satu baris untuk Edit atau Hapus. Tahan satu baris lalu seret untuk memilih banyak sekaligus (bisa Salin atau Hapus), atau pakai tombol titik tiga di pojok kanan atas: Pilih banyak, Hapus semua. Email yang berhasil dipakai otomatis dihapus dari stok. Email yang kamu tulis sendiri di kolom Kaitkan otomatis tidak mengubah stok. Saklar di pojok kanan atas halaman stok: mati berarti stok tidak dipakai.",
        "Catatan umum" to "Di tab Aktivitas: baris pertama email yang berhasil dikaitkan, baris kedua ID akun (dibaca dari tulisan Role di layar loading, atau dari halaman Profil), lalu daftar server. Satu sesi menghasilkan satu akun, jadi ID dan email hanya satu.",
        "Animasi sistem" to "Selama sesi berjalan, tiga skala animasi di Opsi pengembang (animasi jendela, transisi, dan durasi animator) dimatikan lewat Shizuku supaya proses lebih cepat dan HP tidak kaku di luar sesi. Setelah sesi selesai atau dihentikan, ketiganya dikembalikan ke 1x. Kalau sesi terputus di tengah jalan, animasi dikembalikan otomatis saat aplikasi dibuka lagi.",
        "Izin" to "Shizuku dipakai untuk membaca log, force stop, dan membersihkan recent, dan hanya berlaku untuk aplikasi yang kamu centang. Aksesibilitas untuk screenshot dan ketukan. Tampil di atas aplikasi untuk kapsul status. Baterai tanpa batasan supaya sesi tidak dihentikan sistem. Setelah memasang pembaruan APK, matikan lalu nyalakan lagi Aksesibilitas. Izin selain Shizuku (notifikasi, tampil di atas aplikasi, baterai, dan izin yang dibutuhkan untuk menyalakan Aksesibilitas) diberikan otomatis lewat Shizuku kalau masih kurang, jadi tidak perlu diatur manual. Tombol Atur tetap ada sebagai cadangan. Shizuku sendiri harus diizinkan manual. Aksesibilitas dinyalakan sendiri tiap aplikasi dibuka dan sebelum Mulai, karena Android mematikannya saat aplikasi ditutup paksa.",
        "Tanda status" to "Titik di pojok kanan atas menyala kalau Shizuku, Aksesibilitas, dan Overlay sudah aktif. Merah artinya ada izin yang belum aktif; ketuk untuk melihat yang mana. Saat sesi berjalan, titiknya berkedip pelan."
    )

    private fun buildSheet() {
        dim = View(this)
        dim.setBackgroundColor(pal.dim)
        dim.alpha = 0f
        dim.visibility = View.GONE
        dim.setOnClickListener { closeSheet() }
        root.addView(dim, FrameLayout.LayoutParams(MATCH, MATCH))

        sheet = DragSheet(this)
        sheet.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(pal.card)
        val r = dp(26).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setStroke(maxOf(1, dp(0.6f)), pal.border)
        sheet.background = bg
        sheet.setPadding(dp(20), dp(10), dp(20), dp(28))
        sheet.isClickable = true
        sheet.elevation = dp(12).toFloat()
        sheet.visibility = View.GONE

        val handle = View(this)
        handle.background = rounded(pal.borderStrong, 999f)
        sheet.addView(handle, LinearLayout.LayoutParams(dp(36), dp(4)).also {
            it.gravity = Gravity.CENTER_HORIZONTAL
            it.bottomMargin = dp(14)
        })

        // Menu utama
        sheetMenu = vbox()
        val rHelp = hbox()
        rHelp.setPadding(0, dp(14), 0, dp(14))
        rHelp.isClickable = true
        rHelp.background = pressable(rounded(Color.TRANSPARENT, 12f))
        rHelp.addView(text("Penjelasan pengaturan", 15f, pal.text), lpWeight())
        rHelp.addView(text("\u203A", 20f, pal.muted))
        rHelp.setOnClickListener { showSheetHelp() }
        pressFx(rHelp, 0.985f)
        sheetMenu.addView(rHelp, lpMW())
        val line = View(this)
        line.setBackgroundColor(pal.border)
        sheetMenu.addView(line, LinearLayout.LayoutParams(MATCH, 1))

        val rTheme = hbox()
        rTheme.setPadding(0, dp(12), 0, dp(12))
        rTheme.addView(text("Tema", 15f, pal.text), lpWeight())
        var segRef: TabBar? = null
        val seg = TabBar(this, pal, arrayOf("Gelap", "Terang"), 13f) { i ->
            segRef?.animateTo(i)
            setTheme(i == 0)
        }
        segRef = seg
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        seg.background = rounded(pal.bg, 999f, pal.border)
        seg.pos = if (pal.dark) 0f else 1f
        rTheme.addView(seg, LinearLayout.LayoutParams(dp(170), WRAP))
        sheetMenu.addView(rTheme, lpMW())
        sheet.addView(sheetMenu, lpMW())

        // Penjelasan (kembali ke menu: tombol Back, atau seret lembar ke bawah untuk menutup)
        sheetHelp = vbox()
        sheetHelp.visibility = View.GONE
        helpScroll = ScrollView(this)
        helpScroll.isVerticalScrollBarEnabled = false
        val hb = vbox()
        helpItems.forEach { (t, b) ->
            hb.addView(text(t, 14f, pal.text, true), lpMW(top = dp(8)))
            val bt = text(b, 13f, pal.muted)
            bt.setLineSpacing(0f, 1.3f)
            hb.addView(bt, lpMW(top = dp(3), bottom = dp(6)))
        }
        helpScroll.addView(hb, FrameLayout.LayoutParams(MATCH, WRAP))
        sheetHelp.addView(helpScroll, LinearLayout.LayoutParams(MATCH, dp(360)))
        sheet.addView(sheetHelp, lpMW())

        root.addView(sheet, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
    }

    private var sheetOnHelp = false
    private var sheetSwapAnim: ValueAnimator? = null

    private fun openSheet() {
        if (sheetOpen) return
        hideKeyboard()
        sheetOpen = true
        setSheetPage(false, false)
        dim.visibility = View.VISIBLE
        sheet.visibility = View.VISIBLE
        dim.animate().alpha(1f).setDuration(300).start()
        sheet.post {
            sheet.translationY = sheet.height.toFloat()
            sheet.animate().translationY(0f).setDuration(450).setInterpolator(IOS_EASE).start()
        }
    }

    private fun closeSheet(after: (() -> Unit)? = null) {
        if (!sheetOpen) {
            after?.invoke()
            return
        }
        sheetOpen = false
        sheet.animate().cancel()
        dim.animate().cancel()
        dim.animate().alpha(0f).setDuration(250).withEndAction { dim.visibility = View.GONE }.start()
        sheet.animate().translationY(sheet.height.toFloat()).setDuration(350).setInterpolator(IOS_EASE)
            .withEndAction {
                sheet.visibility = View.GONE
                sheet.translationY = 0f
                setSheetPage(false, false)
                after?.invoke()
            }.start()
    }

    private fun showSheetMenu() = setSheetPage(false, true)

    private fun showSheetHelp() = setSheetPage(true, true)

    // Ganti halaman lembar (menu dan penjelasan) dengan gerakan: halaman lama memudar sambil bergeser, halaman baru masuk
    // dari sisi seberang, dan tinggi lembar berubah halus mengikuti isinya
    private fun setSheetPage(toHelp: Boolean, animate: Boolean) {
        sheetSwapAnim?.cancel()
        val inV: View = if (toHelp) sheetHelp else sheetMenu
        val outV: View = if (toHelp) sheetMenu else sheetHelp
        if (toHelp) {
            val h = (root.height * 0.6f).toInt()
            val lp = helpScroll.layoutParams
            if (h > 0 && lp.height != h) {
                lp.height = h
                helpScroll.layoutParams = lp
            }
            helpScroll.scrollTo(0, 0)
        }
        val same = sheetOnHelp == toHelp && inV.visibility == View.VISIBLE && outV.visibility == View.GONE
        sheetOnHelp = toHelp
        val slp = sheet.layoutParams
        if (!animate || !sheet.isShown || sheet.width == 0 || same) {
            inV.visibility = View.VISIBLE
            inV.alpha = 1f
            inV.translationX = 0f
            outV.visibility = View.GONE
            outV.alpha = 1f
            outV.translationX = 0f
            slp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            sheet.layoutParams = slp
            return
        }
        val startH = sheet.height
        // ukur tinggi halaman tujuan
        val prevIn = inV.visibility
        val prevOut = outV.visibility
        outV.visibility = View.GONE
        inV.visibility = View.VISIBLE
        sheet.measure(
            View.MeasureSpec.makeMeasureSpec(sheet.width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(root.height, View.MeasureSpec.AT_MOST)
        )
        val targetH = sheet.measuredHeight
        outV.visibility = prevOut
        inV.visibility = prevIn
        if (prevOut != View.VISIBLE) outV.visibility = View.VISIBLE
        if (prevIn == View.VISIBLE) inV.visibility = View.GONE
        outV.alpha = 1f
        outV.translationX = 0f
        val dir = if (toHelp) 1f else -1f
        val shift = dp(24).toFloat()
        var switched = false
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 320
        a.interpolator = IOS_EASE
        a.addUpdateListener {
            val f = it.animatedValue as Float
            slp.height = (startH + (targetH - startH) * f).toInt()
            sheet.layoutParams = slp
            if (f < 0.4f) {
                val k = f / 0.4f
                outV.alpha = 1f - k
                outV.translationX = -dir * shift * k
            } else {
                if (!switched) {
                    switched = true
                    outV.visibility = View.GONE
                    outV.alpha = 1f
                    outV.translationX = 0f
                    inV.visibility = View.VISIBLE
                }
                val k = (f - 0.4f) / 0.6f
                inV.alpha = k
                inV.translationX = dir * shift * (1f - k)
            }
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                outV.visibility = View.GONE
                outV.alpha = 1f
                outV.translationX = 0f
                inV.visibility = View.VISIBLE
                inV.alpha = 1f
                inV.translationX = 0f
                slp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                sheet.layoutParams = slp
            }
        })
        sheetSwapAnim = a
        a.start()
    }

    // Lembar menu: bisa diseret ke bawah untuk menutup, dari pegangan di atas, atau dari isi kalau sedang di paling atas
    private inner class DragSheet(ctx: Context) : LinearLayout(ctx) {
        private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        private var downRaw = 0f
        private var dragStartRaw = 0f
        private var downY = 0f
        private var startInHandle = false
        private var dragging = false
        private var vt: VelocityTracker? = null

        private fun canDragHere(): Boolean = startInHandle || !sheetOnHelp || helpScroll.scrollY == 0

        private fun begin(ev: MotionEvent) {
            downRaw = ev.rawY
            downY = ev.y
            startInHandle = ev.y < dp(52)
            dragging = false
            vt?.recycle()
            vt = VelocityTracker.obtain()
            vt?.addMovement(ev)
        }

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> begin(ev)
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(ev)
                    if (!dragging && ev.y - downY > slop && canDragHere() && sheetOpen) {
                        dragging = true
                        dragStartRaw = ev.rawY
                        sheet.animate().cancel()
                        dim.animate().cancel()
                        parent.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt?.recycle()
                    vt = null
                }
            }
            return dragging
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    begin(ev)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(ev)
                    if (!dragging && ev.rawY - downRaw > slop && canDragHere() && sheetOpen) {
                        dragging = true
                        dragStartRaw = ev.rawY
                        sheet.animate().cancel()
                        dim.animate().cancel()
                    }
                    if (dragging) {
                        val ty = maxOf(0f, ev.rawY - dragStartRaw)
                        sheet.translationY = ty
                        dim.alpha = (1f - ty / maxOf(1, sheet.height)).coerceIn(0f, 1f)
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        vt?.addMovement(ev)
                        vt?.computeCurrentVelocity(1000)
                        val vy = vt?.yVelocity ?: 0f
                        val ty = sheet.translationY
                        dragging = false
                        if (ev.actionMasked == MotionEvent.ACTION_UP && (ty > sheet.height * 0.3f || vy > 1100f)) {
                            closeSheet()
                        } else {
                            sheet.animate().translationY(0f).setDuration(300).setInterpolator(IOS_EASE).start()
                            dim.animate().alpha(1f).setDuration(300).setInterpolator(IOS_EASE).start()
                        }
                    }
                    vt?.recycle()
                    vt = null
                    return true
                }
            }
            return true
        }
    }

    private fun setTheme(dark: Boolean) {
        if (dark == pal.dark) return
        prefs.edit().putString("theme", if (dark) "dark" else "light").apply()
        // Tunggu pil meluncur dulu, tutup lembar, lalu pasang tema baru
        main.postDelayed({
            if (!isFinishing && !isDestroyed) closeSheet { applyTheme(dark) }
        }, 260)
    }

    // =====================================================================
    // Setelan tersimpan
    // =====================================================================

    private fun loadSettings() {
        loadingUi = true
        etD1.setText(prefs.getString("d1", "5700"))
        etD2.setText(prefs.getString("d2", "25000"))
        etD3.setText((prefs.getString("d3", "") ?: "").ifEmpty { "600" })
        etTarget.setText(prefs.getString("target", "0"))
        etQf.setText(prefs.getString("qf", ""))
        swAnim.isChecked = prefs.getBoolean("animOff", true)
        swTapOn.isChecked = prefs.getBoolean("tapOn", false)
        etTapMs.setText((prefs.getString("tapMs", "") ?: "").ifEmpty { "4900" })
        etTapX.setText((prefs.getString("tapX", "") ?: "").ifEmpty { "1200" })
        etTapY.setText((prefs.getString("tapY", "") ?: "").ifEmpty { "960" })
        swFirst.isChecked = prefs.getBoolean("firstOn", true)
        etFirstMax.setText((prefs.getString("firstMax", "") ?: "").ifEmpty { "10000" })
        etAfterTap.setText((prefs.getString("afterTap", "") ?: "").ifEmpty { "1800" })
        etLoginKeys.setText((prefs.getString("loginKeys", "") ?: "").ifEmpty { "Login kembali" })
        swNick.isChecked = prefs.getBoolean("nickOn", true)
        swKaitkan.isChecked = EmailStock.kaitkanOn(this)
        etKaitkan.setText(EmailStock.field(this))
        etNick.setText(prefs.getString("nickBase", "Ats-"))
        etNickStart.setText((prefs.getString("nickStart", "") ?: "").ifEmpty { "1" })
        sel.clear()
        sel.addAll(prefs.getStringSet("sel", null) ?: emptySet())
        loadingUi = false
        updateSelCount()
    }

    private fun saveSet() {
        if (loadingUi) return
        prefs.edit()
            .putString("d1", etD1.text.toString())
            .putString("d2", etD2.text.toString())
            .putString("d3", etD3.text.toString())
            .putString("target", etTarget.text.toString())
            .putString("qf", etQf.text.toString())
            .putBoolean("animOff", swAnim.isChecked)
            .putBoolean("tapOn", swTapOn.isChecked)
            .putString("tapMs", etTapMs.text.toString())
            .putString("tapX", etTapX.text.toString())
            .putString("tapY", etTapY.text.toString())
            .putBoolean("firstOn", swFirst.isChecked)
            .putString("firstMax", etFirstMax.text.toString())
            .putString("afterTap", etAfterTap.text.toString())
            .putString("loginKeys", etLoginKeys.text.toString())
            .putBoolean("nickOn", swNick.isChecked)
            .putString("nickBase", if (nickFieldAuto) manualNick else etNick.text.toString())
            .putString("nickStart", etNickStart.text.toString())
            .apply()
        updateSelCount()
    }

    private fun saveSel() {
        prefs.edit().putStringSet("sel", HashSet(sel)).apply()
        updateSelCount()
    }

    private fun updateSelCount() {
        val n = if (appsLoaded) apps.count { sel.contains(it.pkg) } else sel.size
        if (::tvCount.isInitialized) tvCount.text = "$n dipilih"
        if (::tvSel.isInitialized) tvSel.text = "0 = tanpa target \u00B7 $n aplikasi dipilih"
        updateNickWarn()
    }

    // Alasan kenapa Nickname otomatis tidak bisa jalan (null = aman)
    private fun nickProblem(): String? {
        if (!swNick.isChecked) return null
        val base = etNick.text.toString()
        val start = etNickStart.text.toString().toIntOrNull() ?: 1
        val selected = if (appsLoaded) apps.count { sel.contains(it.pkg) } else sel.size
        val target = etTarget.text.toString().toIntOrNull() ?: 0
        val count = maxOf(1, if (target > 0) target else selected)
        fun len(s: String): Int = s.codePointCount(0, s.length)
        val first = base + start
        val last = base + (start + count - 1)
        if (len(first) < 4) return "Nama '$first' hanya ${len(first)} karakter. Game butuh 4-20 karakter."
        if (len(last) > 20) return "Nama terpanjang '$last' ada ${len(last)} karakter. Game butuh 4-20 karakter."
        if (!ShizukuHelper.hasPermission()) return "Shizuku belum diizinkan."
        if (!OcrA11yService.isRunning()) return "Aksesibilitas belum aktif."
        return null
    }

    private fun updateNickWarn() {
        if (!::tvNickWarn.isInitialized || !::swAnim.isInitialized) return
        val msg = nickProblem()
        setIfChanged(tvNickWarn, msg ?: "")
        val v = if (msg == null) View.GONE else View.VISIBLE
        if (tvNickWarn.visibility != v) tvNickWarn.visibility = v
    }

    // =====================================================================
    // Izin dan status
    // =====================================================================

    private fun batteryUnrestricted(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Throwable) {
        false
    }

    // Selalu tampilkan dialog permintaan ("Izinkan aplikasi selalu berjalan di latar belakang?").
    // Halaman pengaturan hanya dipakai kalau dialog tidak bisa dibuka.
    private fun requestBattery() {
        val was = batteryUnrestricted()
        try {
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            if (was) toast("Sudah diizinkan")
        } catch (e: Exception) {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun missingPerms(): List<String> {
        val m = ArrayList<String>()
        if (!ShizukuHelper.hasPermission()) m.add("Shizuku")
        if (!OcrA11yService.isRunning()) m.add("Aksesibilitas")
        if (!Settings.canDrawOverlays(this)) m.add("Tampil di atas aplikasi")
        return m
    }

    private fun explainStatus() {
        if (RunnerService.running) {
            alert("Sesi sedang berjalan.")
            return
        }
        val m = missingPerms()
        val bat = if (batteryUnrestricted()) "" else
            "\n\nDisarankan juga: atur baterai ke Tanpa batasan."
        if (m.isEmpty()) {
            alert("Semua izin utama sudah aktif. Siap dijalankan.$bat")
        } else {
            Dlg(this, pal)
                .message("Izin yang belum aktif:\n\u2022 " + m.joinToString("\n\u2022 ") + bat)
                .positive("Buka Setelan") { showTab(3) }
                .negative("Tutup")
                .show()
        }
    }

    // 0 = belum siap, 1 = siap, 2 = berjalan
    private fun setStatus(state: Int) {
        if (state == statusState) return
        statusState = state
        pulse?.cancel()
        hdDot.alpha = 1f
        when (state) {
            2 -> {
                setDotColor(hdDot, pal.dotOn)
                hdTxt.text = "Berjalan"
                pulse = ObjectAnimator.ofFloat(hdDot, View.ALPHA, 1f, 0.25f).apply {
                    duration = 900
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    start()
                }
            }
            1 -> {
                setDotColor(hdDot, pal.dotOn)
                hdTxt.text = "Siap"
            }
            else -> {
                setDotColor(hdDot, pal.danger)
                hdTxt.text = "Belum siap"
            }
        }
    }

    // =====================================================================
    // Aksi
    // =====================================================================

    private fun doStart() {
        hideKeyboard()
        if (!appsLoaded) {
            alert("Daftar aplikasi masih dimuat, tunggu sebentar.")
            return
        }
        val p = apps.filter { sel.contains(it.pkg) }.map { it.pkg }
        if (p.isEmpty()) {
            alert("Centang aplikasi dulu di tab Apps.")
            return
        }
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.putExtra("pkgs", p.toTypedArray())
        i.putExtra("d1", etD1.text.toString().toLongOrNull() ?: 5700L)
        i.putExtra("d2", etD2.text.toString().toLongOrNull() ?: 25000L)
        i.putExtra("d3", etD3.text.toString().toLongOrNull() ?: 600L)
        i.putExtra("target", etTarget.text.toString().toIntOrNull() ?: 0)
        i.putExtra("animOff", swAnim.isChecked)
        i.putExtra("tapOn", swTapOn.isChecked)
        i.putExtra("tapMs", etTapMs.text.toString().toLongOrNull() ?: 4900L)
        i.putExtra("tapX", etTapX.text.toString().toIntOrNull() ?: 1200)
        i.putExtra("tapY", etTapY.text.toString().toIntOrNull() ?: 960)
        i.putExtra("firstOn", swFirst.isChecked)
        i.putExtra("firstMax", etFirstMax.text.toString().toLongOrNull() ?: 10000L)
        i.putExtra("afterTap", etAfterTap.text.toString().toLongOrNull() ?: 1800L)
        i.putExtra("loginKeys", etLoginKeys.text.toString())
        i.putExtra("nickOn", swNick.isChecked)
        i.putExtra("nickBase", etNick.text.toString())
        i.putExtra("nickStart", etNickStart.text.toString().toIntOrNull() ?: 1)
        i.putExtra("kaitkanOn", EmailStock.kaitkanOn(this))
        i.putExtra("kaitkanEmail", EmailStock.effective(this))

        // Aksesibilitas mati? Nyalakan otomatis dulu (Jalur A), tunggu tersambung maksimal 5 detik.
        // Kalau belum tersambung, proses tetap dimulai (tidak diblokir).
        // Izin yang masih kurang juga diberikan otomatis lewat Shizuku sebelum mulai.
        val needPerms = AutoPerms.hasMissing(this) && ShizukuHelper.hasPermission()
        if (needPerms || (!OcrA11yService.isRunning() && SecureA11y.granted(this))) {
            toast(if (needPerms) "Menyiapkan izin..." else "Menyalakan Aksesibilitas...")
            Thread {
                try {
                    if (needPerms) AutoPerms.run(this)
                    if (!OcrA11yService.isRunning() && SecureA11y.granted(this)) {
                        SecureA11y.ensureAndWait(this, 5000L) { }
                    }
                } catch (e: Throwable) {
                }
                runOnUiThread { if (!isFinishing && !isDestroyed) launchService(i) }
            }.start()
            return
        }
        launchService(i)
    }

    private fun launchService(i: Intent) {
        try {
            startForegroundService(i)
        } catch (e: Exception) {
            alert("Gagal memulai: " + e.javaClass.simpleName)
        }
        main.postDelayed({ poll() }, 150)
    }

    // Tugas otomatis ringan, dicek tiap penyegaran status:
    // (1) nyalakan Aksesibilitas kalau mati, (2) kembalikan animasi sistem kalau sesi sebelumnya terputus
    private var lastAnimTry = 0L
    private var animBusy = false

    private var lastPermTry = 0L
    private var permTries = 0
    private var permBusy = false

    private fun autoTasks() {
        val now = SystemClock.uptimeMillis()

        // Izin yang kurang diberikan otomatis lewat Shizuku (maksimal 4 kali, jarak 8 detik)
        if (!AutoPerms.hasMissing(this)) {
            permTries = 0
        } else if (!permBusy && !RunnerService.running && permTries < 4 &&
            now - lastPermTry > 8000L && ShizukuHelper.hasPermission()
        ) {
            permBusy = true
            permTries++
            lastPermTry = now
            Thread {
                try {
                    AutoPerms.run(this)
                } catch (e: Throwable) {
                } finally {
                    permBusy = false
                }
            }.start()
        }

        if (!RunnerService.running && !animBusy && AnimScale.isPending(this) &&
            now - lastAnimTry > 8000L && ShizukuHelper.hasPermission()
        ) {
            animBusy = true
            lastAnimTry = now
            Thread {
                try {
                    AnimScale.restore(this) { }
                } catch (e: Throwable) {
                } finally {
                    animBusy = false
                }
            }.start()
        }
    }

    private fun doStop() {
        val i = Intent(this, RunnerService::class.java)
        i.action = "STOP"
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Kaitkan otomatis dan Stok email
    // =====================================================================

    private fun buildKaitkanCard(): View {
        val c = card()
        val top = hbox()
        top.addView(text("Kaitkan otomatis", 14f, pal.text, true), lpWeight())
        swKaitkan = switchView()
        top.addView(swKaitkan)
        c.addView(top, lpMW(bottom = dp(10)))

        c.addView(text("Email", 12f, pal.muted), lpMW(bottom = dp(4)))
        etKaitkan = input(false, "nama@email.com")
        etKaitkan.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        c.addView(etKaitkan)

        tvKaitkanWarn = text("", 12f, pal.danger)
        tvKaitkanWarn.visibility = View.GONE
        c.addView(tvKaitkanWarn, lpMW(top = dp(6)))

        val dvK = View(this)
        dvK.setBackgroundColor(pal.border)
        c.addView(dvK, LinearLayout.LayoutParams(MATCH, 1).also { it.topMargin = dp(10) })
        tvStockRow = text("", 13f, pal.muted, true)
        c.addView(valueRow("Stok email", tvStockRow) { openStockPage(EmailSrc) }, lpMW())
        return c
    }

    // Segarkan kolom email (ikut stok), keterangan, dan peringatan
    private fun updateKaitkan() {
        if (!::etKaitkan.isInitialized || !::swNick.isInitialized) return
        val f = EmailStock.field(this)
        if (!etKaitkan.hasFocus() && etKaitkan.text.toString() != f) {
            kaitkanSyncing = true
            etKaitkan.setText(f)
            kaitkanSyncing = false
        }
        val on = EmailStock.stockOn(this)
        val eff = EmailStock.effective(this)
        var w = ""
        if (swKaitkan.isChecked) {
            w = if (!swNick.isChecked) {
                "Butuh Nickname otomatis yang nyala."
            } else if (eff.isEmpty()) {
                if (on) "Stok email habis dan kolom kosong: fitur akan dilewati." else "Kolom email kosong: fitur akan dilewati."
            } else if (eff.indexOf('@') < 1) {
                "Email tidak valid."
            } else {
                ""
            }
        }
        setIfChanged(tvKaitkanWarn, w)
        val v = if (w.isEmpty()) View.GONE else View.VISIBLE
        if (tvKaitkanWarn.visibility != v) tvKaitkanWarn.visibility = v
    }

    // Teks nilai di baris stok (kartu Cabang): berganti dengan memudar, hanya kalau isinya berubah
    private fun setStockValue(tv: TextView, v: String) {
        if (tv.text.toString() == v) return
        if (tv.text.isEmpty() || !tv.isShown) {
            tv.text = v
            return
        }
        tv.animate().cancel()
        tv.animate().alpha(0f).setDuration(90).withEndAction {
            tv.text = v
            tv.animate().alpha(1f).setDuration(140).start()
        }.start()
    }

    private fun updateStockRowValue() {
        if (::tvStockRow.isInitialized) {
            val n = EmailStock.stock(this).size
            setStockValue(tvStockRow, (if (EmailStock.stockOn(this)) "Nyala" else "Mati") + " \u00B7 $n email")
        }
        if (::tvNickStockRow.isInitialized) {
            val n = NickStock.stock(this).size
            setStockValue(tvNickStockRow, (if (NickStock.stockOn(this)) "Nyala" else "Mati") + " \u00B7 $n awalan")
        }
    }

    // Kolom Nickname menampilkan awalan teratas stok selama stok nyala dan ada isinya (terang penuh, tidak bisa diketik;
    // ketuk membuka stok). Isi manual disimpan dan kembali ke kolom saat stok mati atau kosong
    private fun syncNickField() {
        if (!::etNick.isInitialized) return
        val top = if (NickStock.stockOn(this)) NickStock.top(this) else ""
        if (top.isNotEmpty()) {
            if (!nickFieldAuto) {
                manualNick = etNick.text.toString()
                nickFieldAuto = true
                etNick.isFocusable = false
                etNick.isFocusableInTouchMode = false
                etNick.isCursorVisible = false
                etNick.setOnClickListener { openStockPage(NickSrc) }
            }
            if (etNick.text.toString() != top) {
                loadingUi = true
                etNick.setText(top)
                loadingUi = false
                updateNickWarn()
            }
        } else if (nickFieldAuto) {
            nickFieldAuto = false
            etNick.isFocusable = true
            etNick.isFocusableInTouchMode = true
            etNick.isCursorVisible = true
            etNick.setOnClickListener(null)
            loadingUi = true
            etNick.setText(manualNick)
            loadingUi = false
            updateNickWarn()
        }
    }

    private fun buildStockPage(): FrameLayout {
        stockOpen = false
        val pg = FrameLayout(this)
        pg.setBackgroundColor(pal.bg)
        pg.isClickable = true
        pg.visibility = View.GONE
        pg.addView(HeaderDecor(this, pal), FrameLayout.LayoutParams(MATCH, dp(DECOR_H)))

        val col = vbox()
        pg.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val h = hbox()
        h.setPadding(dp(16), dp(18), dp(16), dp(6))
        val back = glyphRound(4, "Kembali") { closeStockPage() }
        h.addView(back, LinearLayout.LayoutParams(dp(38), dp(38)))
        tvStockTitle = text("Stok email", 17f, pal.text, true)
        h.addView(tvStockTitle, lpWeight(left = dp(12)))
        swStock = switchView()
        swStock.setOnCheckedChangeListener { _, on ->
            if (!stockSyncing) {
                stockSrc.setOn(this, on)
                stockRefresh()
            }
        }
        val more = glyphRound(6, "Menu") { openStockMenu() }
        h.addView(more, LinearLayout.LayoutParams(dp(38), dp(38)).also { it.rightMargin = dp(10) })
        h.addView(swStock)
        stockHeadNormal = h
        // header mode pilih banyak: X, jumlah terpilih, Pilih semua. Bertumpuk dengan header biasa, berganti dengan memudar
        val hs = hbox()
        hs.setPadding(dp(16), dp(18), dp(16), dp(6))
        val xb = glyphRound(5, "Tutup mode pilih") { exitStockSel() }
        hs.addView(xb, LinearLayout.LayoutParams(dp(38), dp(38)))
        tvStockSelCount = text("0 dipilih", 17f, pal.text, true)
        hs.addView(tvStockSelCount, lpWeight(left = dp(12)))
        hs.addView(chip("Pilih semua", true) { stockSelectAll() })
        hs.alpha = 0f
        hs.visibility = View.GONE
        stockHeadSel = hs
        val hdr = FrameLayout(this)
        hdr.addView(h, FrameLayout.LayoutParams(MATCH, WRAP))
        hdr.addView(hs, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(hdr, LinearLayout.LayoutParams(MATCH, WRAP))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val inner = vbox()
        inner.setPadding(dp(16), dp(PAGE_TOP - 20), dp(16), dp(110))
        tvStockHint = text("Email paling atas dipakai lebih dulu.", 12f, pal.muted)
        inner.addView(tvStockHint, lpMW(bottom = dp(10)).also { it.leftMargin = dp(4) })
        val lc = vbox()
        lc.background = rounded(pal.card, 22f, pal.border)
        lc.setPadding(0, dp(6), 0, dp(6))
        stockRows = vbox()
        lc.addView(stockRows, lpMW())
        stockEmptyTv = text("", 13f, pal.muted)
        stockEmptyTv.setPadding(dp(16), dp(10), dp(16), dp(10))
        stockEmptyTv.visibility = View.GONE
        lc.addView(stockEmptyTv, lpMW())
        stockCard = lc
        inner.addView(lc, lpMW())
        tvStockCount = text("", 12f, pal.muted)
        inner.addView(tvStockCount, lpMW(top = dp(10)).also { it.leftMargin = dp(6) })
        sv.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        stockScroll = sv

        val fab = TextView(this)
        fab.text = "+"
        fab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        fab.setTextColor(pal.onPrimary)
        fab.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.primary)
        fab.background = pressable(g)
        fab.elevation = dp(4).toFloat()
        fab.isClickable = true
        fab.setOnClickListener { showAddDialog() }
        // Tombol + mengecil sedikit saat ditekan
        fab.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(100).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
        val flp = FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END)
        flp.setMargins(0, 0, dp(20), dp(24))
        pg.addView(fab, flp)
        stockFab = fab

        // bar bawah mode pilih banyak: Salin dan Hapus, naik dari bawah
        val bar = hbox()
        bar.background = rounded(pal.card, 28f, pal.border)
        bar.setPadding(dp(10), dp(10), dp(10), dp(10))
        bar.addView(stockBarButton(2, "Salin", false) { stockCopySelected() }, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.rightMargin = dp(4) })
        bar.addView(stockBarButton(1, "Hapus", true) { stockDeleteSelected() }, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = dp(4) })
        bar.visibility = View.GONE
        bar.alpha = 0f
        bar.translationY = dp(90).toFloat()
        val blp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        blp.setMargins(dp(16), 0, dp(16), dp(24))
        pg.addView(bar, blp)
        stockBar = bar

        // menu titik tiga: Pilih banyak, Hapus semua (muncul dari pojok kanan atas)
        val layer = FrameLayout(this)
        layer.isClickable = true
        layer.visibility = View.GONE
        layer.setOnClickListener { closeStockMenu() }
        val mc = vbox()
        mc.background = rounded(pal.card, 16f, pal.borderStrong)
        mc.elevation = dp(8).toFloat()
        mc.setPadding(dp(6), dp(6), dp(6), dp(6))
        mc.addView(stockMenuItem(3, "Pilih banyak", false) {
            closeStockMenu()
            if (stockSrc.list(this).isEmpty()) toast("Stok kosong") else enterStockSel()
        })
        val ml = View(this)
        ml.setBackgroundColor(pal.border)
        mc.addView(ml, LinearLayout.LayoutParams(MATCH, 1))
        mc.addView(stockMenuItem(1, "Hapus semua", true) {
            closeStockMenu()
            val l = stockSrc.list(this)
            if (l.isEmpty()) toast("Stok kosong") else confirmStockDelete(l, true)
        })
        val mlp = FrameLayout.LayoutParams(dp(190), WRAP, Gravity.TOP or Gravity.END)
        mlp.topMargin = dp(70)
        mlp.rightMargin = dp(72)
        layer.addView(mc, mlp)
        pg.addView(layer, FrameLayout.LayoutParams(MATCH, MATCH))
        stockMenuLayer = layer
        stockMenuCard = mc
        return pg
    }

    private fun stockMenuItem(kind: Int, label: String, danger: Boolean, onClick: () -> Unit): LinearLayout {
        val r = hbox()
        r.setPadding(dp(12), dp(12), dp(12), dp(12))
        r.background = pressable(rounded(Color.TRANSPARENT, 10f))
        r.isClickable = true
        r.setOnClickListener { onClick() }
        val col = if (danger) pal.danger else pal.text
        r.addView(GlyphView(this, kind, col), LinearLayout.LayoutParams(dp(18), dp(18)))
        r.addView(text(label, 14f, col), lpWW(left = dp(12)))
        pressFx(r, 0.97f)
        return r
    }

    private fun stockBarButton(kind: Int, label: String, danger: Boolean, onClick: () -> Unit): LinearLayout {
        val b = hbox()
        b.gravity = Gravity.CENTER
        val col = if (danger) pal.danger else pal.text
        b.background = pressable(rounded(Color.TRANSPARENT, 999f, pal.borderStrong))
        b.setPadding(dp(12), dp(12), dp(12), dp(12))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        b.addView(GlyphView(this, kind, col), LinearLayout.LayoutParams(dp(18), dp(18)))
        b.addView(text(label, 14f, col, true), lpWW(left = dp(8)))
        pressFx(b)
        return b
    }

    private fun openStockMenu() {
        if (stockMenuOpen || stockSelMode) return
        stockMenuOpen = true
        stockMenuLayer.visibility = View.VISIBLE
        stockMenuCard.alpha = 0f
        stockMenuCard.scaleX = 0.9f
        stockMenuCard.scaleY = 0.9f
        stockMenuCard.post {
            stockMenuCard.pivotX = stockMenuCard.width.toFloat()
            stockMenuCard.pivotY = 0f
            stockMenuCard.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(IOS_EASE).start()
        }
    }

    private fun closeStockMenu() {
        if (!stockMenuOpen) return
        stockMenuOpen = false
        stockMenuCard.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150).setInterpolator(IOS_EASE)
            .withEndAction { if (!stockMenuOpen) stockMenuLayer.visibility = View.GONE }
            .start()
    }

    private fun stockBack() {
        when {
            stockMenuOpen -> closeStockMenu()
            stockSelMode -> exitStockSel()
            else -> closeStockPage()
        }
    }

    // ---------- halaman stok (satu halaman untuk Stok email dan Stok nickname) ----------

    private fun stockRefresh(animate: Boolean = true, entrance: Boolean = false) {
        if (!::stockRows.isInitialized) return
        val src = stockSrc
        val list = src.list(this)
        stockVer = src.version()
        stockSyncing = true
        swStock.isChecked = src.on(this)
        stockSyncing = false
        // saklar mati: daftar meredup halus
        val al = if (src.on(this)) 1f else 0.42f
        stockCard.animate().cancel()
        if (animate) stockCard.animate().alpha(al).setDuration(220).setInterpolator(IOS_EASE).start() else stockCard.alpha = al
        syncStockRows(list, animate, entrance)
        showStockCount(list.size, animate)
        updateStockRowValue()
        updateKaitkan()
        syncNickField()
    }

    // Menyamakan baris di layar dengan daftar: baris yang hilang keluar ke kiri lalu menutup, baris baru masuk bergantian
    private fun syncStockRows(list: List<String>, animate: Boolean, entrance: Boolean) {
        stockSel.retainAll(list.toHashSet())
        val live = ArrayList<View>()
        for (k in 0 until stockRows.childCount) {
            val v = stockRows.getChildAt(k)
            if (v.tag is String) live.add(v)
        }
        val liveItems = live.map { it.tag as String }
        if (entrance) {
            stockRows.removeAllViews()
            list.forEachIndexed { i, item -> addStockRow(item, minOf(i, 10), false, true) }
        } else if (liveItems != list) {
            val removed = liveItems.filter { it !in list }
            val kept = liveItems.filter { it in list }
            val addedAll = list.filter { it !in liveItems }
            val orderSame = list.filter { it in liveItems } == kept
            val addedAtEnd = list.size >= kept.size && list.subList(0, kept.size) == kept
            if (orderSame && addedAtEnd) {
                var k = 0
                for (v in live) if ((v.tag as String) in removed) removeStockRow(v, animate, minOf(k++, 8))
                addedAll.forEachIndexed { i, item -> addStockRow(item, minOf(i, 10), animate, false) }
            } else {
                // susunan berubah (edit atau pindah urutan): bangun ulang tanpa gerakan
                stockRows.removeAllViews()
                list.forEach { addStockRow(it, 0, false, false) }
            }
        }
        renumberStockRows()
        if (stockSelMode) {
            stockSelShown = HashSet(stockSel)
            tvStockSelCount.text = "${stockSel.size} dipilih"
        }
        if (list.isEmpty()) {
            stockEmptyTv.text = stockSrc.emptyText
            if (stockEmptyTv.visibility != View.VISIBLE) {
                stockEmptyTv.alpha = 0f
                stockEmptyTv.visibility = View.VISIBLE
                stockEmptyTv.animate().alpha(1f).setStartDelay(if (animate) 200L else 0L).setDuration(240).start()
            }
        } else if (stockEmptyTv.visibility == View.VISIBLE) {
            stockEmptyTv.animate().cancel()
            stockEmptyTv.visibility = View.GONE
        }
    }

    private fun makeStockRow(item: String): LinearLayout {
        val r = hbox()
        r.isClickable = true
        r.tag = item
        // kolom nomor: nomor dan lingkaran pilih bertumpuk, berganti dengan memudar saat mode pilih banyak
        val nb = FrameLayout(this)
        val n = text("", 12f, pal.muted)
        n.typeface = Typeface.MONOSPACE
        n.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        n.setPadding(0, 0, dp(8), 0)
        nb.addView(n, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER_VERTICAL))
        val dot = SelDot(this, pal.borderStrong, pal.primary, pal.primary)
        nb.addView(dot, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        n.alpha = if (stockSelMode) 0f else 1f
        dot.alpha = if (stockSelMode) 1f else 0f
        dot.setSelectedState(stockSel.contains(item), false)
        r.addView(nb, LinearLayout.LayoutParams(dp(38), MATCH))
        val line = View(this)
        line.setBackgroundColor(pal.border)
        r.addView(line, LinearLayout.LayoutParams(1, MATCH))
        val e = text(item, 13f, pal.text)
        e.typeface = Typeface.MONOSPACE
        e.setSingleLine(true)
        e.ellipsize = TextUtils.TruncateAt.END
        e.setPadding(dp(10), 0, dp(10), 0)
        r.addView(e, lpWeight())
        r.setOnClickListener { if (stockSelMode) toggleStockSel(item) else showRowMenu(item) }
        // tahan baris: masuk mode pilih banyak dan mulai menyeret untuk memilih beberapa baris sekaligus
        r.setOnLongClickListener {
            startDragSelect(item, r)
            true
        }
        r.setOnTouchListener { _, ev ->
            if (!stockDragging) {
                false
            } else {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_MOVE -> {
                        stockLastRawY = ev.rawY
                        dragSelectAt(ev.rawY)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        stockDragging = false
                        stockHandler.removeCallbacks(dragScroller)
                        false
                    }
                    else -> false
                }
            }
        }
        return r
    }

    private fun addStockRow(item: String, order: Int, animate: Boolean, entrance: Boolean) {
        val v = makeStockRow(item)
        stockRows.addView(v, LinearLayout.LayoutParams(MATCH, dp(36)))
        if (animate || entrance) {
            v.alpha = 0f
            v.translationY = dp(10).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(order * (if (entrance) 30L else 70L))
                .setDuration(340).setInterpolator(IOS_EASE).start()
        }
    }

    private fun removeStockRow(v: View, animate: Boolean, order: Int = 0) {
        v.tag = null   // tidak dihitung lagi, sedang keluar
        if (!animate) {
            stockRows.removeView(v)
            return
        }
        v.isClickable = false
        v.animate().translationX(-dp(26).toFloat()).alpha(0f).setStartDelay(order * 60L).setDuration(200).setInterpolator(IOS_EASE).withEndAction {
            val a = ValueAnimator.ofInt(v.height, 0)
            a.duration = 220
            a.interpolator = IOS_EASE
            a.addUpdateListener { va ->
                val lp = v.layoutParams
                lp.height = va.animatedValue as Int
                v.layoutParams = lp
            }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(an: Animator) {
                    stockRows.removeView(v)
                }
            })
            a.start()
        }.start()
    }

    // Latar baris: sorotan tipis di baris paling atas (yang dipakai lebih dulu), atau warna tipis kalau terpilih
    private fun rowBg(first: Boolean, selected: Boolean): Drawable = when {
        selected -> rounded((pal.primary and 0x00FFFFFF) or 0x1F000000, 0f)
        first -> GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf((pal.primary and 0x00FFFFFF) or 0x18000000, Color.TRANSPARENT)
        )
        else -> rounded(Color.TRANSPARENT, 0f)
    }

    private fun liveStockRows(): List<View> {
        val out = ArrayList<View>()
        for (k in 0 until stockRows.childCount) {
            val v = stockRows.getChildAt(k)
            if (v.tag is String) out.add(v)
        }
        return out
    }

    // Nomor urut dan latar baris
    private fun renumberStockRows() {
        var i = 0
        for (k in 0 until stockRows.childCount) {
            val v = stockRows.getChildAt(k)
            if (v.tag !is String) continue
            i++
            val box = (v as LinearLayout).getChildAt(0) as FrameLayout
            (box.getChildAt(0) as TextView).text = i.toString()
            val picked = stockSelMode && stockSel.contains(v.tag as String)
            v.background = pressable(rowBg(i == 1 && !stockSelMode, picked))
        }
    }

    // Angka "Sisa" berhitung halus
    private fun showStockCount(n: Int, animate: Boolean) {
        val unit = stockSrc.unit
        val from = stockCountShown
        stockCountShown = n
        stockCountAnim?.cancel()
        if (!animate || from < 0 || from == n) {
            tvStockCount.text = "Sisa: $n $unit"
            return
        }
        val a = ValueAnimator.ofInt(from, n)
        a.duration = 300
        a.interpolator = IOS_EASE
        a.addUpdateListener { tvStockCount.text = "Sisa: ${it.animatedValue as Int} $unit" }
        stockCountAnim = a
        a.start()
    }

    // ---------- mode pilih banyak ----------

    private fun enterStockSel() {
        if (stockSelMode) return
        stockSelMode = true
        stockSel.clear()
        updateStockSelUi(true)
        refreshRowDots(true)
        tvStockSelCount.text = "0 dipilih"
    }

    private fun exitStockSel() {
        if (!stockSelMode) return
        stockSelMode = false
        stockDragging = false
        stockHandler.removeCallbacks(dragScroller)
        stockSel.clear()
        updateStockSelUi(true)
        refreshRowDots(true)
    }

    // Header berganti halus, bar bawah naik, tombol + mengecil lalu hilang (dan sebaliknya saat keluar)
    private fun updateStockSelUi(animate: Boolean) {
        val on = stockSelMode
        val dur = if (animate) 220L else 0L
        if (on) stockHeadSel.visibility = View.VISIBLE else stockHeadNormal.visibility = View.VISIBLE
        stockHeadSel.animate().cancel()
        stockHeadSel.animate().alpha(if (on) 1f else 0f).translationY(if (on) 0f else -dp(6).toFloat())
            .setDuration(dur).setInterpolator(IOS_EASE)
            .withEndAction { if (!stockSelMode) stockHeadSel.visibility = View.GONE }
            .start()
        stockHeadNormal.animate().cancel()
        stockHeadNormal.animate().alpha(if (on) 0f else 1f).translationY(if (on) dp(6).toFloat() else 0f)
            .setDuration(dur).setInterpolator(IOS_EASE)
            .withEndAction { if (stockSelMode) stockHeadNormal.visibility = View.INVISIBLE }
            .start()
        if (on) stockBar.visibility = View.VISIBLE
        stockBar.animate().cancel()
        stockBar.animate().translationY(if (on) 0f else dp(90).toFloat()).alpha(if (on) 1f else 0f)
            .setDuration(if (animate) 300L else 0L).setInterpolator(IOS_EASE)
            .withEndAction { if (!stockSelMode) stockBar.visibility = View.GONE }
            .start()
        stockFab.isClickable = !on
        stockFab.animate().cancel()
        stockFab.animate().scaleX(if (on) 0.4f else 1f).scaleY(if (on) 0.4f else 1f).alpha(if (on) 0f else 1f)
            .setDuration(dur + 20).setInterpolator(IOS_EASE).start()
    }

    // Nomor dan lingkaran pilih berganti memudar di semua baris
    private fun refreshRowDots(animate: Boolean) {
        stockSelShown = HashSet(stockSel)
        val on = stockSelMode
        for (v in liveStockRows()) {
            val box = (v as LinearLayout).getChildAt(0) as FrameLayout
            val n = box.getChildAt(0)
            val dot = box.getChildAt(1) as SelDot
            if (animate) {
                n.animate().alpha(if (on) 0f else 1f).setDuration(180).start()
                dot.animate().alpha(if (on) 1f else 0f).setDuration(180).start()
            } else {
                n.alpha = if (on) 0f else 1f
                dot.alpha = if (on) 1f else 0f
            }
            dot.setSelectedState(stockSel.contains(v.tag as String), false)
        }
        renumberStockRows()
    }

    // Hanya baris yang berubah status pilihnya yang diperbarui (penting saat menyeret di daftar panjang)
    private fun updateStockSelVisuals(animate: Boolean) {
        val now = HashSet(stockSel)
        for (v in liveStockRows()) {
            val name = v.tag as String
            val a = now.contains(name)
            if (a != stockSelShown.contains(name)) {
                val box = (v as LinearLayout).getChildAt(0) as FrameLayout
                (box.getChildAt(1) as SelDot).setSelectedState(a, animate)
                v.background = pressable(rowBg(false, a))
            }
        }
        stockSelShown = now
        tvStockSelCount.text = "${now.size} dipilih"
    }

    private fun toggleStockSel(item: String) {
        if (!stockSel.remove(item)) stockSel.add(item)
        updateStockSelVisuals(true)
    }

    private fun stockSelectAll() {
        val all = stockSrc.list(this)
        if (stockSel.size >= all.size) stockSel.clear() else stockSel.addAll(all)
        updateStockSelVisuals(true)
    }

    private fun startDragSelect(item: String, view: View) {
        if (!stockSelMode) enterStockSel()
        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        stockSel.add(item)
        stockDragAnchor = liveStockRows().indexOfFirst { (it.tag as String) == item }
        stockDragBase = HashSet(stockSel)
        stockDragging = true
        view.parent?.requestDisallowInterceptTouchEvent(true)
        updateStockSelVisuals(true)
        stockHandler.removeCallbacks(dragScroller)
        stockHandler.post(dragScroller)
    }

    // Baris dari baris awal tahanan sampai baris di bawah jari ikut terpilih (naik atau turun)
    private fun dragSelectAt(rawY: Float) {
        val live = liveStockRows()
        if (live.isEmpty() || stockDragAnchor < 0) return
        val loc = IntArray(2)
        var idx = -1
        for ((i, v) in live.withIndex()) {
            v.getLocationOnScreen(loc)
            if (rawY >= loc[1] && rawY < loc[1] + v.height) {
                idx = i
                break
            }
        }
        if (idx < 0) {
            live[0].getLocationOnScreen(loc)
            idx = if (rawY < loc[1]) 0 else live.size - 1
        }
        val lo = minOf(stockDragAnchor, idx)
        val hi = maxOf(stockDragAnchor, idx)
        val want = LinkedHashSet<String>(stockDragBase)
        for (i in lo..hi) {
            if (i in live.indices) want.add(live[i].tag as String)
        }
        if (want == stockSel) return
        stockSel.clear()
        stockSel.addAll(want)
        updateStockSelVisuals(true)
    }

    private fun stockSelectedInOrder(): List<String> {
        val all = stockSrc.list(this)
        return all.filter { stockSel.contains(it) }
    }

    private fun stockCopySelected() {
        val l = stockSelectedInOrder()
        if (l.isEmpty()) {
            toast("Belum ada yang dipilih")
            return
        }
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("stok", l.joinToString("\n")))
            toast("${l.size} ${stockSrc.unit} disalin")
        } catch (e: Exception) {
            toast("Gagal menyalin")
        }
    }

    private fun stockDeleteSelected() {
        val l = stockSelectedInOrder()
        if (l.isEmpty()) {
            toast("Belum ada yang dipilih")
            return
        }
        confirmStockDelete(l, false)
    }

    private fun confirmStockDelete(items: List<String>, all: Boolean) {
        if (isFinishing) return
        val w = stockSrc.unit
        Dlg(this, pal)
            .title(if (all) "Hapus semua?" else "Hapus ${items.size} ${stockSrc.unit}?")
            .message(if (all) "Semua ${items.size} $w akan dihapus dari stok." else "${items.size} $w akan dihapus dari stok.")
            .positive(if (all) "Hapus semua" else "Hapus") { doStockDelete(items) }
            .negative("Batal")
            .show()
    }

    private fun doStockDelete(items: List<String>) {
        val set = items.toHashSet()
        val rest = stockSrc.list(this).filter { it !in set }
        stockSrc.setList(this, rest)
        if (stockSelMode) exitStockSel()
        stockRefresh()
        toast("Dihapus")
    }

    private fun showRowMenu(item: String) {
        if (isFinishing) return
        Dlg(this, pal)
            .title(item, mono = true)
            .items(listOf("Edit", "Hapus"), danger = 1) { which ->
                if (which == 0) showEditDialog(item) else deleteStockItem(item)
            }
            .show()
    }

    private fun deleteStockItem(item: String) {
        val list = ArrayList(stockSrc.list(this))
        val i = list.indexOf(item)
        if (i < 0) return
        list.removeAt(i)
        stockSrc.setList(this, list)
        stockRefresh()
        toast("Dihapus")
    }

    private fun showEditDialog(item: String) {
        if (isFinishing) return
        val src = stockSrc
        val et = input(false, src.addPlaceholder)
        if (src.isEmail) et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        et.setText(item)
        et.setSelection(et.text.length)
        val box = vbox()
        box.addView(et, lpMW())
        Dlg(this, pal)
            .title(src.editTitle)
            .view(box)
            .keyboard()
            .positive("Simpan") {
                val v = et.text.toString().trim()
                val list = ArrayList(src.list(this))
                val i = list.indexOf(item)
                if (i >= 0) {
                    if (!src.valid(v)) {
                        toast(src.invalidMsg)
                    } else if (list.indices.any { it != i && list[it].equals(v, ignoreCase = true) }) {
                        toast(src.dupMsg)
                    } else {
                        list[i] = v
                        src.setList(this, list)
                        stockRefresh()
                        toast("Disimpan")
                    }
                }
            }
            .negative("Batal")
            .show()
    }

    private fun showAddDialog() {
        if (isFinishing) return
        val src = stockSrc
        val et = EditText(this)
        et.setTextColor(pal.text)
        et.setHintTextColor(pal.hint)
        et.hint = src.addPlaceholder
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        et.typeface = Typeface.MONOSPACE
        et.background = rounded(pal.field, 14f, pal.border)
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.minLines = 4
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val st = text("", 12f, pal.muted)
        val box = vbox()
        box.addView(text(src.addHint, 12f, pal.muted), lpMW(bottom = dp(8)))
        box.addView(et, lpMW())
        box.addView(st, lpMW(top = dp(8)))
        var shownA = 0
        var shownB = 0
        var cAnim: ValueAnimator? = null
        fun setCounts(a: Int, b: Int) {
            st.text = "$a siap ditambahkan \u00B7 $b baris diabaikan"
        }
        setCounts(0, 0)
        watch(et) {
            val r = StockParse.parse(src, et.text.toString(), src.list(this))
            // baris yang diabaikan dicoret abu-abu
            val ed = et.text
            for (sp in ed.getSpans(0, ed.length, StrikethroughSpan::class.java)) ed.removeSpan(sp)
            for (sp in ed.getSpans(0, ed.length, ForegroundColorSpan::class.java)) ed.removeSpan(sp)
            for (rg in r.ignoredRanges) {
                val s0 = rg.first.coerceIn(0, ed.length)
                val e0 = (rg.last + 1).coerceIn(0, ed.length)
                if (e0 > s0) {
                    ed.setSpan(StrikethroughSpan(), s0, e0, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    ed.setSpan(ForegroundColorSpan(pal.muted), s0, e0, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            // angka hitungan berganti halus
            val a0 = shownA
            val b0 = shownB
            shownA = r.ok.size
            shownB = r.ignored
            cAnim?.cancel()
            val an = ValueAnimator.ofFloat(0f, 1f)
            an.duration = 240
            an.interpolator = IOS_EASE
            an.addUpdateListener { v ->
                val f = v.animatedValue as Float
                setCounts(a0 + ((shownA - a0) * f).toInt(), b0 + ((shownB - b0) * f).toInt())
            }
            an.start()
            cAnim = an
        }
        Dlg(this, pal)
            .title(src.addTitle)
            .view(box)
            .keyboard()
            .positive("Tambah") {
                val cur = src.list(this)
                val r = StockParse.parse(src, et.text.toString(), cur)
                if (r.ok.isEmpty()) {
                    toast("Tidak ada " + src.unit + " valid untuk ditambahkan")
                } else {
                    src.setList(this, cur + r.ok)
                    stockRefresh()
                    toast("${r.ok.size} ditambahkan, ${r.ignored} diabaikan")
                }
            }
            .negative("Batal")
            .show()
    }

    private fun openStockPage(src: StockSrc) {
        if (stockOpen) return
        hideKeyboard()
        stockSrc = src
        tvStockTitle.text = src.title
        tvStockHint.text = src.hint
        stockCountShown = -1
        stockSelMode = false
        stockSel.clear()
        stockHeadNormal.alpha = 1f
        stockHeadNormal.translationY = 0f
        stockHeadNormal.visibility = View.VISIBLE
        stockHeadSel.visibility = View.GONE
        stockBar.visibility = View.GONE
        stockFab.alpha = 1f
        stockFab.scaleX = 1f
        stockFab.scaleY = 1f
        stockFab.isClickable = true
        stockRefresh(false, true)
        stockOpen = true
        stockPage.visibility = View.VISIBLE
        stockPage.translationX = root.width.toFloat()
        stockPage.animate().translationX(0f).setDuration(380).setInterpolator(IOS_EASE).start()
    }

    private fun closeStockPage() {
        if (!stockOpen) return
        hideKeyboard()
        if (stockMenuOpen) closeStockMenu()
        if (stockSelMode) exitStockSel()
        stockOpen = false
        updateKaitkan()
        stockPage.animate().translationX(root.width.toFloat()).setDuration(320).setInterpolator(IOS_EASE)
            .withEndAction { if (!stockOpen) stockPage.visibility = View.GONE }
            .start()
    }

    // =====================================================================
    // Penyegaran status (tiap 700 ms)
    // =====================================================================

    private fun poll() {
        if (!uiReady) return
        try {
            pollInner()
        } catch (e: Throwable) {
            showCrashScreen("Pembaruan status gagal", android.util.Log.getStackTraceString(e))
        }
    }

    private fun pollInner() {
        updateKaitkan()
        updateStockRowValue()
        if (stockOpen && stockVer != stockSrc.version()) stockRefresh()
        syncNickField()
        updateNickWarn()
        autoTasks()
        val run = RunnerService.running
        val rv = if (run) View.GONE else View.VISIBLE
        if (vReady.visibility != rv) vReady.visibility = rv
        val rr = if (run) View.VISIBLE else View.GONE
        if (vRun.visibility != rr) vRun.visibility = rr

        ring.setProgress(RunnerService.done, RunnerService.total)
        setIfChanged(tvPhase, RunnerService.phase)
        setIfChanged(tvFound, RunnerService.found.toString())
        val t = etTarget.text.toString().toIntOrNull() ?: 0
        setIfChanged(tvTgt, if (t > 0) t.toString() else "Bebas")

        val ov = Settings.canDrawOverlays(this)
        val sz = ShizukuHelper.hasPermission()
        val a11y = OcrA11yService.isRunning()
        setDot(dOv, ov)
        val oe = if (!ov && AutoPerms.overlayTried >= 2) "Otomatis gagal: ${AutoPerms.overlayError}" else ""
        setIfChanged(tvOvErr, oe)
        val ovv = if (oe.isEmpty()) View.GONE else View.VISIBLE
        if (tvOvErr.visibility != ovv) tvOvErr.visibility = ovv
        setDot(pOv, ov)
        setDot(dSz, sz)
        setDot(pSz, sz)
        setDot(dA11y, a11y)
        setDot(pA11y, a11y)
        setDot(dBat, batteryUnrestricted())
        setStatus(if (run) 2 else if (ov && sz && a11y) 1 else 0)

        renderLog(RunnerService.logsSnapshot())

        val sv = RunnerService.serversSnapshot()
        val notes = RunnerService.notesSnapshot()
        val topText = listOf(notes.first, notes.second).filter { it.isNotEmpty() }.joinToString("\n")
        setIfChanged(tvNotesTop, topText)
        val tv = if (topText.isEmpty()) View.GONE else View.VISIBLE
        if (tvNotesTop.visibility != tv) tvNotesTop.visibility = tv
        val lv = if (topText.isNotEmpty() && sv.isNotEmpty()) View.VISIBLE else View.GONE
        if (vNotesLine.visibility != lv) vNotesLine.visibility = lv
        setIfChanged(tvSrv, if (sv.isEmpty()) (if (topText.isEmpty()) "Belum ada catatan." else "") else sv.joinToString("\n"))
        val sg = if (sv.isEmpty() && topText.isNotEmpty()) View.GONE else View.VISIBLE
        if (tvSrv.visibility != sg) tvSrv.visibility = sg
        setIfChanged(tvSrvTitle, "Catatan umum (${sv.size})")
    }
}
