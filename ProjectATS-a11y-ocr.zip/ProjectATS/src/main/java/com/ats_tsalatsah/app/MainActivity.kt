package com.ats_tsalatsah.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import java.math.BigDecimal

class MainActivity : Activity() {

    // ---------- Warna ----------
    private val cCard = Color.parseColor("#111111")
    private val cBorder = Color.parseColor("#2A2A2A")
    private val cDark = Color.parseColor("#0A0A0A")
    private val cNav = Color.parseColor("#161616")
    private val c333 = Color.parseColor("#333333")
    private val c444 = Color.parseColor("#444444")
    private val c555 = Color.parseColor("#555555")
    private val c666 = Color.parseColor("#666666")
    private val c888 = Color.parseColor("#888888")
    private val c999 = Color.parseColor("#999999")
    private val cAAA = Color.parseColor("#AAAAAA")
    private val cBBB = Color.parseColor("#BBBBBB")
    private val cCCC = Color.parseColor("#CCCCCC")
    private val cDDD = Color.parseColor("#DDDDDD")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val DIALOG = android.R.style.Theme_DeviceDefault_Dialog_Alert

    // ---------- Data ----------
    private data class AppItem(val name: String, val pkg: String)

    private class Ses(val head: String) {
        val rows = ArrayList<String>()
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    private var apps: List<AppItem> = emptyList()
    private var appsLoaded = false
    private var shown: List<AppItem> = emptyList()
    private val sel = HashSet<String>()
    private val openArc = HashSet<Int>()
    private var lastLogKey = ""
    private var curTab = 0
    private var loadingUi = false

    private val rxDate = Regex("(\\d{4})-(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)")
    private val rxTime = Regex("\\d\\d:\\d\\d:\\d\\d(\\.\\d+)?")
    private val rxApk = Regex("^\\S+\\s+Buka [A-Za-z0-9_.]+\\s*$")
    private val rxSrv = Regex("Server \\d+ dicatat")
    private val mon = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    // ---------- View ----------
    private lateinit var root: FrameLayout
    private lateinit var nav: LinearLayout
    private lateinit var tabs: Array<View>
    private lateinit var navBtns: Array<TextView>
    private lateinit var hdDot: View
    private lateinit var hdTxt: TextView

    // Tab Cabang
    private lateinit var vReady: LinearLayout
    private lateinit var vRun: LinearLayout
    private lateinit var etTarget: EditText
    private lateinit var tvSel: TextView
    private lateinit var pSz: View
    private lateinit var pOv: View
    private lateinit var pA11y: View
    private lateinit var ring: RingView
    private lateinit var tvPhase: TextView
    private lateinit var tvFound: TextView
    private lateinit var tvTgt: TextView

    // Tab Apps
    private lateinit var etQ: EditText
    private lateinit var etQf: EditText
    private lateinit var listView: ListView
    private lateinit var tvEmpty: TextView
    private val adapter = AppAdapter()

    // Tab Aktivitas
    private lateinit var sub0: TextView
    private lateinit var sub1: TextView
    private lateinit var vLog: LinearLayout
    private lateinit var vArc: LinearLayout
    private lateinit var tvSrvTitle: TextView
    private lateinit var tvSrv: TextView
    private lateinit var tvLogEmpty: TextView
    private lateinit var sesBox: LinearLayout
    private lateinit var tvLogTitle: TextView
    private lateinit var tvLogBody: TextView
    private lateinit var arcBox: LinearLayout

    // Tab Setelan
    private lateinit var etD1: EditText
    private lateinit var etD2: EditText
    private lateinit var etD3: EditText
    private lateinit var h1: TextView
    private lateinit var h2v: TextView
    private lateinit var h3: TextView
    private lateinit var cbBack: CheckBox
    private lateinit var cbTapOn: CheckBox
    private lateinit var etTapMs: EditText
    private lateinit var etTapX: EditText
    private lateinit var etTapY: EditText
    private lateinit var hTap: TextView
    private lateinit var bTap: TextView
    private lateinit var tvTapRes: TextView
    private lateinit var dOv: View
    private lateinit var cbOcr: CheckBox
    private lateinit var etOcrKeys: EditText
    private lateinit var bOcr: TextView
    private lateinit var tvOcrRes: TextView
    private lateinit var dSz: View
    private lateinit var dA11y: View
    private lateinit var dBat: View

    private val ticker = object : Runnable {
        override fun run() {
            poll()
            main.postDelayed(this, 700)
        }
    }

    // =====================================================================
    // Siklus hidup
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RunnerService.initStore(this)
        prefs = getSharedPreferences("ats_ui", Context.MODE_PRIVATE)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))

        setContentView(buildRoot())
        loadSettings()
        loadApps()
        poll()
    }

    override fun onResume() {
        super.onResume()
        main.removeCallbacks(ticker)
        main.post(ticker)
    }

    override fun onPause() {
        main.removeCallbacks(ticker)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (curTab != 0) showTab(0) else super.onBackPressed()
    }

    // =====================================================================
    // Pembantu tampilan
    // =====================================================================

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun dp(v: Int): Int = dp(v.toFloat())

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) g.setStroke(dp(1), stroke)
        return g
    }

    private fun pressable(bg: Drawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(0x40888888), bg, null)

    private fun lpMW(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = top
        lp.bottomMargin = bottom
        return lp
    }

    private fun lpWW(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = top
        lp.bottomMargin = bottom
        return lp
    }

    private fun lpWeight(left: Int = 0, right: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = left
        lp.rightMargin = right
        return lp
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    private fun text(s: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun h2(s: String): TextView {
        val t = text(s, 15f, cBBB, true)
        t.layoutParams = lpMW(bottom = dp(10))
        return t
    }

    private fun label(s: String): TextView {
        val t = text(s, 13f, cAAA)
        t.layoutParams = lpMW(top = dp(10), bottom = dp(4))
        return t
    }

    private fun hint(): TextView {
        val t = text("", 12f, c888)
        t.layoutParams = lpMW(top = dp(6))
        return t
    }

    private fun mono(s: String): TextView {
        val t = text(s, 12f, cCCC)
        t.typeface = Typeface.MONOSPACE
        t.setLineSpacing(0f, 1.35f)
        t.setTextIsSelectable(true)
        return t
    }

    private fun card(): LinearLayout {
        val c = vbox()
        c.background = rounded(cCard, 24f, cBorder)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        c.layoutParams = lpMW(bottom = dp(12))
        return c
    }

    private fun emptyCard(s: String): LinearLayout {
        val c = card()
        c.addView(text(s, 15f, Color.WHITE))
        return c
    }

    private fun button(
        s: String,
        outline: Boolean = false,
        small: Boolean = false,
        onClick: () -> Unit
    ): TextView {
        val t = text(s, if (small) 13f else 15f, Color.BLACK, true)
        t.gravity = Gravity.CENTER
        if (small) t.setPadding(dp(14), dp(8), dp(14), dp(8))
        else t.setPadding(dp(20), dp(12), dp(20), dp(12))
        styleButton(t, outline)
        t.isClickable = true
        t.isFocusable = true
        t.setOnClickListener { onClick() }
        return t
    }

    private fun styleButton(t: TextView, outline: Boolean) {
        if (outline) {
            t.setTextColor(Color.WHITE)
            t.background = pressable(rounded(Color.TRANSPARENT, 999f, c555))
        } else {
            t.setTextColor(Color.BLACK)
            t.background = pressable(rounded(Color.WHITE, 999f))
        }
    }

    private fun roundButton(s: String, onClick: () -> Unit): TextView {
        val t = text(s, 26f, Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding(0, 0, 0, 0)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(Color.TRANSPARENT)
        g.setStroke(dp(1), c555)
        t.background = pressable(g)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    private fun setEnabledLook(v: View, en: Boolean) {
        if (v.isEnabled != en) v.isEnabled = en
        v.alpha = if (en) 1f else 0.35f
    }

    private fun dot(): View {
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(c555)
        v.background = g
        v.tag = false
        v.layoutParams = LinearLayout.LayoutParams(dp(10), dp(10))
        return v
    }

    private fun setDot(v: View, ok: Boolean) {
        if (v.tag == ok) return
        v.tag = ok
        (v.background as GradientDrawable).setColor(if (ok) Color.WHITE else c555)
    }

    private fun pill(d: View?, t: TextView): LinearLayout {
        val p = hbox()
        p.background = rounded(cDark, 999f, c444)
        p.setPadding(dp(12), dp(6), dp(12), dp(6))
        if (d != null) p.addView(d)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        if (d != null) lp.leftMargin = dp(6)
        p.addView(t, lp)
        return p
    }

    private fun pillText(s: String): TextView = text(s, 12f, cDDD, true)

    private fun input(numeric: Boolean, hintText: String = ""): EditText {
        val e = EditText(this)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(c666)
        e.hint = hintText
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        e.background = rounded(Color.BLACK, 14f, c444)
        e.setPadding(dp(14), dp(11), dp(14), dp(11))
        e.inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        e.setSingleLine(true)
        e.imeOptions = EditorInfo.IME_ACTION_DONE
        e.layoutParams = lpMW()
        return e
    }

    private fun check(s: String): CheckBox {
        val c = CheckBox(this)
        c.text = s
        c.setTextColor(Color.WHITE)
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        c.buttonTintList = ColorStateList.valueOf(Color.WHITE)
        return c
    }

    private fun watch(e: EditText, f: () -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                f()
            }
        })
    }

    private fun setIfChanged(t: TextView, s: String) {
        if (t.text.toString() != s) t.text = s
    }

    private fun scrollTab(): Pair<ScrollView, LinearLayout> {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        val inner = vbox()
        inner.setPadding(dp(14), dp(4), dp(14), dp(110))
        sv.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        return Pair(sv, inner)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val f = currentFocus
        imm.hideSoftInputFromWindow((f ?: root).windowToken, 0)
        f?.clearFocus()
    }

    private fun alert(msg: String) {
        if (isFinishing) return
        AlertDialog.Builder(this, DIALOG)
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun open(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Susunan layar
    // =====================================================================

    private fun buildRoot(): View {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val col = vbox()
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildHeader(), LinearLayout.LayoutParams(MATCH, WRAP))

        val content = FrameLayout(this)
        col.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        tabs = arrayOf(buildTabCabang(), buildTabApps(), buildTabAktivitas(), buildTabSetelan())
        tabs.forEachIndexed { i, v ->
            content.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
            v.visibility = if (i == 0) View.VISIBLE else View.GONE
        }

        nav = buildNav()
        val nlp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        nlp.setMargins(dp(16), 0, dp(16), dp(16))
        root.addView(nav, nlp)

        // Sembunyikan menu bawah saat keyboard muncul
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            root.getWindowVisibleDisplayFrame(r)
            val h = root.rootView.height
            val kb = h - r.bottom > h * 0.2
            val vis = if (kb) View.GONE else View.VISIBLE
            if (nav.visibility != vis) nav.visibility = vis
        }
        return root
    }

    private fun buildHeader(): View {
        val h = hbox()
        h.setPadding(dp(14), dp(14), dp(14), dp(10))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_notif)
        h.addView(logo, LinearLayout.LayoutParams(dp(34), dp(34)))
        val title = text("Project ats", 20f, Color.WHITE, true)
        h.addView(title, lpWeight(left = dp(10)))
        hdDot = dot()
        hdTxt = pillText("Siap")
        h.addView(pill(hdDot, hdTxt))
        return h
    }

    private fun buildNav(): LinearLayout {
        val n = hbox()
        n.background = rounded(cNav, 999f, c333)
        n.setPadding(dp(6), dp(6), dp(6), dp(6))
        n.elevation = dp(6).toFloat()
        val names = arrayOf("Cabang", "Apps", "Aktivitas", "Setelan")
        navBtns = Array(names.size) { i ->
            val b = text(names[i], 13f, c888, true)
            b.gravity = Gravity.CENTER
            b.setPadding(0, dp(11), 0, dp(11))
            b.isClickable = true
            b.setOnClickListener { showTab(i) }
            n.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
            b
        }
        styleNav()
        return n
    }

    private fun styleNav() {
        navBtns.forEachIndexed { i, b ->
            if (i == curTab) {
                b.background = rounded(Color.WHITE, 999f)
                b.setTextColor(Color.BLACK)
            } else {
                b.background = null
                b.setTextColor(c888)
            }
        }
    }

    private fun showTab(i: Int) {
        hideKeyboard()
        curTab = i
        tabs.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        styleNav()
    }

    // ---------- Tab Cabang ----------

    private fun buildTabCabang(): View {
        val (sv, box) = scrollTab()

        // Tampilan siap
        vReady = vbox()

        val c1 = card()
        c1.gravity = Gravity.CENTER_HORIZONTAL
        val t1 = h2("Target server")
        t1.gravity = Gravity.CENTER
        c1.addView(t1)

        val step = hbox()
        etTarget = EditText(this)
        etTarget.setTextColor(Color.WHITE)
        etTarget.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44f)
        etTarget.typeface = Typeface.DEFAULT_BOLD
        etTarget.gravity = Gravity.CENTER
        etTarget.background = null
        etTarget.inputType = InputType.TYPE_CLASS_NUMBER
        etTarget.setSingleLine(true)
        etTarget.imeOptions = EditorInfo.IME_ACTION_DONE
        step.addView(roundButton("\u2212") { stepTarget(-1) }, LinearLayout.LayoutParams(dp(52), dp(52)))
        step.addView(etTarget, lpWeight())
        step.addView(roundButton("+") { stepTarget(1) }, LinearLayout.LayoutParams(dp(52), dp(52)))
        c1.addView(step, lpMW(top = dp(6), bottom = dp(4)))

        c1.addView(text("0 = tanpa target", 12f, c888), lpWW())
        tvSel = text("0 aplikasi dipilih", 13f, cAAA)
        c1.addView(tvSel, lpWW(top = dp(10)))
        vReady.addView(c1)

        val c2 = card()
        val pr = hbox()
        pSz = dot()
        pOv = dot()
        pA11y = dot()
        pr.addView(pill(pSz, pillText("Shizuku")))
        pr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        pr.addView(pill(pA11y, pillText("Aksesibilitas")))
        pr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        pr.addView(pill(pOv, pillText("Overlay")))
        c2.addView(pr)
        vReady.addView(c2)

        val start = hbox()
        start.gravity = Gravity.CENTER
        start.background = pressable(rounded(Color.WHITE, 999f))
        start.setPadding(dp(18), dp(18), dp(18), dp(18))
        start.isClickable = true
        start.addView(PlayIcon(this, Color.BLACK), LinearLayout.LayoutParams(dp(20), dp(20)))
        val st = text("Mulai", 18f, Color.BLACK, true)
        val stLp = LinearLayout.LayoutParams(WRAP, WRAP)
        stLp.leftMargin = dp(10)
        start.addView(st, stLp)
        start.setOnClickListener { doStart() }
        vReady.addView(start, lpMW())

        box.addView(vReady, lpMW())

        // Tampilan berjalan
        vRun = vbox()
        vRun.visibility = View.GONE

        val c3 = card()
        c3.gravity = Gravity.CENTER_HORIZONTAL
        ring = RingView(this)
        c3.addView(ring, LinearLayout.LayoutParams(dp(190), dp(190)))
        tvPhase = pillText("Putaran 1")
        c3.addView(pill(null, tvPhase), lpWW(top = dp(4)))
        vRun.addView(c3)

        val row = hbox()
        val cf = card()
        cf.gravity = Gravity.CENTER_HORIZONTAL
        tvFound = text("0", 34f, Color.WHITE, true)
        cf.addView(tvFound, lpWW())
        cf.addView(text("Server didapat", 12f, c999), lpWW())
        val ct = card()
        ct.gravity = Gravity.CENTER_HORIZONTAL
        tvTgt = text("0", 34f, Color.WHITE, true)
        ct.addView(tvTgt, lpWW())
        ct.addView(text("Target server", 12f, c999), lpWW())
        row.addView(cf, lpWeight(right = dp(4)))
        row.addView(ct, lpWeight(left = dp(4)))
        vRun.addView(row, lpMW(bottom = dp(12)))

        val stop = button("Hentikan", outline = true) { doStop() }
        stop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        stop.setPadding(dp(18), dp(18), dp(18), dp(18))
        vRun.addView(stop, lpMW())

        box.addView(vRun, lpMW())

        watch(etTarget) { saveSet() }
        return sv
    }

    private fun stepTarget(delta: Int) {
        val n = etTarget.text.toString().toIntOrNull() ?: 0
        val v = maxOf(0, n + delta).toString()
        etTarget.setText(v)
        etTarget.setSelection(v.length)
    }

    // ---------- Tab Apps ----------

    private fun buildTabApps(): View {
        val box = vbox()
        box.setPadding(dp(14), dp(4), dp(14), dp(96))

        val c = card()
        etQ = input(false, "Cari nama atau paket...")
        c.addView(etQ)

        val r = hbox()
        val bPick = button("Pilih hasil", small = true) {
            shown.forEach { sel.add(it.pkg) }
            renderApps()
        }
        val bClear = button("Kosongkan", outline = true, small = true) {
            sel.clear()
            renderApps()
        }
        r.addView(bPick, lpWW())
        val clp = lpWW()
        clp.leftMargin = dp(8)
        r.addView(bClear, clp)
        c.addView(r, lpMW(top = dp(10)))

        c.addView(label("Filter cepat (nama bisa diubah)"))
        val r2 = hbox()
        etQf = input(false, "contoh: Mobile Legends")
        r2.addView(etQf, lpWeight())
        val bq = button("Pilih", small = true) { quickFilter() }
        val qlp = lpWW()
        qlp.leftMargin = dp(8)
        r2.addView(bq, qlp)
        c.addView(r2, lpMW())
        box.addView(c)

        val c2 = card()
        c2.setPadding(dp(16), dp(4), dp(16), dp(4))
        val frame = FrameLayout(this)
        listView = ListView(this)
        listView.divider = ColorDrawable(Color.parseColor("#222222"))
        listView.dividerHeight = 1
        listView.adapter = adapter
        listView.setOnItemClickListener { _, view, pos, _ ->
            if (pos < 0 || pos >= shown.size) return@setOnItemClickListener
            val a = shown[pos]
            if (sel.contains(a.pkg)) sel.remove(a.pkg) else sel.add(a.pkg)
            ((view as LinearLayout).getChildAt(0) as CheckBox).isChecked = sel.contains(a.pkg)
            saveSel()
        }
        tvEmpty = text("Memuat...", 15f, Color.WHITE)
        tvEmpty.setPadding(0, dp(12), 0, dp(12))
        frame.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(tvEmpty, FrameLayout.LayoutParams(MATCH, WRAP))
        listView.emptyView = tvEmpty
        c2.addView(frame, LinearLayout.LayoutParams(MATCH, MATCH))
        box.addView(c2, LinearLayout.LayoutParams(MATCH, 0, 1f))

        watch(etQ) { renderApps() }
        watch(etQf) { saveSet() }
        return box
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: makeAppRow()
            val a = shown[position]
            val cb = row.getChildAt(0) as CheckBox
            val col = row.getChildAt(1) as LinearLayout
            (col.getChildAt(0) as TextView).text = a.name
            (col.getChildAt(1) as TextView).text = a.pkg
            cb.isChecked = sel.contains(a.pkg)
            return row
        }
    }

    private fun makeAppRow(): LinearLayout {
        val row = hbox()
        row.setPadding(0, dp(10), 0, dp(10))
        val cb = CheckBox(this)
        cb.isFocusable = false
        cb.isClickable = false
        cb.buttonTintList = ColorStateList.valueOf(Color.WHITE)
        row.addView(cb, LinearLayout.LayoutParams(WRAP, WRAP))
        val col = vbox()
        col.addView(text("", 14f, Color.WHITE, true))
        col.addView(text("", 11f, c888))
        row.addView(col, lpWeight(left = dp(8)))
        return row
    }

    private fun loadApps() {
        Thread {
            val list = try {
                val pm = packageManager
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(q, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                    .distinctBy { it.pkg }
                    .sortedBy { it.name.lowercase() }
            } catch (e: Throwable) {
                emptyList()
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                apps = list
                appsLoaded = true
                tvEmpty.text = "Tidak ada aplikasi."
                renderApps()
            }
        }.start()
    }

    private fun renderApps() {
        val q = etQ.text.toString().lowercase()
        shown = apps.filter {
            q.isEmpty() || it.name.lowercase().contains(q) || it.pkg.lowercase().contains(q)
        }
        adapter.notifyDataSetChanged()
        saveSel()
    }

    private fun quickFilter() {
        val f = etQf.text.toString().lowercase().trim()
        if (f.isEmpty()) return
        apps.forEach {
            if (it.name.lowercase().contains(f) || it.pkg.lowercase().contains(f)) sel.add(it.pkg)
        }
        hideKeyboard()
        renderApps()
    }

    // ---------- Tab Aktivitas ----------

    private fun buildTabAktivitas(): View {
        val (sv, box) = scrollTab()

        val subRow = hbox()
        sub0 = button("Log aktivitas", small = true) { setSub(0) }
        sub1 = button("Arsip", outline = true, small = true) { setSub(1) }
        subRow.addView(sub0, lpWeight(right = dp(4)))
        subRow.addView(sub1, lpWeight(left = dp(4)))
        box.addView(subRow, lpMW(bottom = dp(12)))

        // Log
        vLog = vbox()

        val cs = card()
        val rs = hbox()
        tvSrvTitle = text("Server didapat (0)", 15f, cBBB, true)
        rs.addView(tvSrvTitle, lpWeight())
        rs.addView(button("Hapus", outline = true, small = true) {
            doDel("Hapus daftar server? Log dan arsip tidak ikut terhapus.") { RunnerService.clearServers() }
        })
        cs.addView(rs, lpMW(bottom = dp(10)))
        tvSrv = mono("Belum ada server.")
        cs.addView(tvSrv, lpMW())
        vLog.addView(cs)

        val cl = card()
        val rl = hbox()
        rl.addView(text("Sesi terakhir", 15f, cBBB, true), lpWeight())
        rl.addView(button("Hapus", outline = true, small = true) {
            doDel("Hapus sesi terakhir? Arsip dan daftar server tidak ikut terhapus.") {
                RunnerService.clearLastSession()
            }
        })
        cl.addView(rl, lpMW(bottom = dp(10)))
        tvLogEmpty = mono("Belum ada aktivitas.")
        cl.addView(tvLogEmpty, lpMW())
        sesBox = vbox()
        sesBox.background = rounded(cDark, 16f, cBorder)
        sesBox.setPadding(dp(12), dp(12), dp(12), dp(12))
        sesBox.visibility = View.GONE
        tvLogTitle = text("", 13f, Color.WHITE, true)
        sesBox.addView(tvLogTitle, lpMW(bottom = dp(8)))
        tvLogBody = mono("")
        sesBox.addView(tvLogBody, lpMW())
        cl.addView(sesBox, lpMW())
        vLog.addView(cl)
        box.addView(vLog, lpMW())

        // Arsip
        vArc = vbox()
        vArc.visibility = View.GONE
        val ra = hbox()
        ra.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        ra.addView(button("Hapus semua arsip", outline = true, small = true) {
            doDel("Hapus semua arsip? Sesi terakhir tetap ada.") { RunnerService.clearArchive() }
        })
        vArc.addView(ra, lpMW(bottom = dp(10)))
        arcBox = vbox()
        arcBox.addView(emptyCard("Belum ada arsip."))
        vArc.addView(arcBox, lpMW())
        box.addView(vArc, lpMW())

        return sv
    }

    private fun setSub(n: Int) {
        vLog.visibility = if (n == 0) View.VISIBLE else View.GONE
        vArc.visibility = if (n == 1) View.VISIBLE else View.GONE
        styleButton(sub0, n != 0)
        styleButton(sub1, n != 1)
    }

    private fun parseSessions(lines: List<String>): List<Ses> {
        val out = ArrayList<Ses>()
        var cur: Ses? = null
        for (l in lines) {
            if (l.contains(RunnerService.MARK)) {
                val s = Ses(l)
                out.add(s)
                cur = s
            } else {
                var c = cur
                if (c == null) {
                    c = Ses("")
                    out.add(c)
                    cur = c
                }
                c.rows.add(l)
            }
        }
        return out
    }

    private fun dateOf(head: String): String? {
        val m = rxDate.find(head) ?: return null
        val g = m.groupValues
        val mi = (g[2].toIntOrNull() ?: 0) - 1
        if (mi < 0 || mi >= mon.size) return null
        return "${g[3].toInt()} ${mon[mi]} ${g[1]}, ${g[4]}:${g[5]}"
    }

    private fun timeOf(head: String): String = rxTime.find(head)?.value ?: ""

    private fun countApk(rows: List<String>): Int = rows.count { rxApk.containsMatchIn(it) }

    private fun countSrv(rows: List<String>): Int = rows.count { rxSrv.containsMatchIn(it) }

    private fun renderLog(lines: List<String>) {
        if (lines.isEmpty()) {
            if (lastLogKey == "kosong") return
            lastLogKey = "kosong"
            tvLogEmpty.visibility = View.VISIBLE
            sesBox.visibility = View.GONE
            arcBox.removeAllViews()
            arcBox.addView(emptyCard("Belum ada arsip."))
            return
        }
        val key = "${lines.size}|${lines[0]}|${lines[lines.size - 1]}"
        if (key == lastLogKey) return
        lastLogKey = key

        val ses = parseSessions(lines)
        val n = ses.size
        val last = ses[n - 1]
        val d = dateOf(last.head) ?: timeOf(last.head).ifEmpty { "tanggal tidak tercatat" }
        tvLogTitle.text = Html.fromHtml(
            "Sesi $n <font color=\"#888888\">(${TextUtils.htmlEncode(d)})</font>",
            Html.FROM_HTML_MODE_LEGACY
        )
        tvLogBody.text = last.rows.asReversed().joinToString("\n").ifEmpty { "(kosong)" }
        tvLogEmpty.visibility = View.GONE
        sesBox.visibility = View.VISIBLE

        arcBox.removeAllViews()
        for (i in n - 2 downTo 0) arcBox.addView(arcItem(i, ses[i]))
        if (n < 2) arcBox.addView(emptyCard("Belum ada arsip."))
    }

    private fun arcItem(i: Int, s: Ses): View {
        val item = vbox()
        item.background = rounded(cDark, 18f, cBorder)
        item.layoutParams = lpMW(bottom = dp(10))

        val hd = vbox()
        hd.setPadding(dp(14), dp(14), dp(14), dp(14))
        hd.isClickable = true
        hd.addView(text("Sesi ${i + 1}", 15f, Color.WHITE, true))
        val t = timeOf(s.head)
        val whenTxt = dateOf(s.head)
            ?: ("tanggal tidak tercatat" + (if (t.isEmpty()) "" else " ($t)"))
        hd.addView(text(whenTxt, 12f, c888), lpMW(top = dp(3)))
        hd.addView(
            text("${countApk(s.rows)} apk dibuka \u00B7 ${countSrv(s.rows)} server didapat", 12f, c888),
            lpMW(top = dp(3))
        )
        item.addView(hd, lpMW())

        val bd = vbox()
        bd.setPadding(dp(14), 0, dp(14), dp(14))
        bd.visibility = if (openArc.contains(i)) View.VISIBLE else View.GONE
        bd.addView(button("Hapus sesi ini", outline = true, small = true) {
            doDel("Hapus Sesi ${i + 1} dari arsip?") { RunnerService.deleteSession(i) }
        }, lpWW())
        bd.addView(mono(s.rows.asReversed().joinToString("\n").ifEmpty { "(kosong)" }), lpMW(top = dp(10)))
        item.addView(bd, lpMW())

        hd.setOnClickListener {
            val o = bd.visibility != View.VISIBLE
            bd.visibility = if (o) View.VISIBLE else View.GONE
            if (o) openArc.add(i) else openArc.remove(i)
        }
        return item
    }

    private fun doDel(msg: String, fn: () -> Boolean) {
        if (isFinishing) return
        AlertDialog.Builder(this, DIALOG)
            .setMessage(msg)
            .setPositiveButton("Ya") { _, _ ->
                val ok = try {
                    fn()
                } catch (e: Throwable) {
                    true
                }
                if (!ok) {
                    alert("Tidak bisa dihapus saat sedang berjalan. Hentikan dulu.")
                } else {
                    lastLogKey = ""
                    openArc.clear()
                    poll()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Tab Setelan ----------

    private fun buildTabSetelan(): View {
        val (sv, box) = scrollTab()

        // Jeda
        val c1 = card()
        c1.addView(h2("Jeda (milidetik, 1000 = 1 detik)"))
        c1.addView(label("Jeda putaran 1 (jatah waktu tiap aplikasi)"))
        etD1 = input(true)
        c1.addView(etD1)
        h1 = hint()
        c1.addView(h1)
        c1.addView(label("Jeda putaran 2 (batas maksimal kalau OCR aktif)"))
        etD2 = input(true)
        c1.addView(etD2)
        h2v = hint()
        c1.addView(h2v)
        c1.addView(label("Jeda tengah (waktu tetap untuk membersihkan aplikasi)"))
        etD3 = input(true)
        c1.addView(etD3)
        h3 = hint()
        c1.addView(h3)
        cbBack = check("Kembali ke aplikasi ini setelah selesai")
        c1.addView(cbBack, lpMW(top = dp(12)))
        box.addView(c1)

        // Ketukan
        val c2 = card()
        c2.addView(h2("Ketukan di jeda 1"))
        cbTapOn = check("Ketuk 'Got it' otomatis")
        c2.addView(cbTapOn, lpMW())
        c2.addView(label("Waktu ketukan (ms setelah aplikasi dibuka)"))
        etTapMs = input(true)
        c2.addView(etTapMs)
        hTap = hint()
        c2.addView(hTap)

        val xy = hbox()
        xy.gravity = Gravity.TOP
        val cx = vbox()
        cx.addView(label("x"))
        etTapX = input(true)
        cx.addView(etTapX)
        val cy = vbox()
        cy.addView(label("y"))
        etTapY = input(true)
        cy.addView(etTapY)
        xy.addView(cx, lpWeight(right = dp(4)))
        xy.addView(cy, lpWeight(left = dp(4)))
        c2.addView(xy, lpMW())

        val hs = hint()
        hs.text = "Layar mendatar 2400x1080. Cek lewat Opsi pengembang > Lokasi penunjuk."
        c2.addView(hs)
        bTap = button("Tes ketuk", small = true) { doTapTest() }
        c2.addView(bTap, lpWW(top = dp(10)))
        tvTapRes = hint()
        c2.addView(tvTapRes)
        box.addView(c2)

        // OCR putaran 2
        val co = card()
        co.addView(h2("OCR putaran 2"))
        cbOcr = check("Lanjut otomatis saat layar terdeteksi")
        co.addView(cbOcr, lpMW())
        co.addView(label("Teks yang dicari (pisahkan dengan koma)"))
        etOcrKeys = input(false, "Create Character")
        co.addView(etOcrKeys)
        val ho = hint()
        ho.text = "Begitu teks ini terbaca di layar, langsung lanjut ke aplikasi berikutnya. " +
            "Kalau tidak muncul, lanjut setelah jeda putaran 2 habis. Butuh izin Aksesibilitas."
        co.addView(ho)
        bOcr = button("Tes OCR", small = true) { doOcrTest() }
        co.addView(bOcr, lpWW(top = dp(10)))
        tvOcrRes = hint()
        co.addView(tvOcrRes)
        box.addView(co)

        // Izin
        val c3 = card()
        c3.addView(h2("Izin"))
        dOv = dot()
        dSz = dot()
        c3.addView(permRow(dOv, "Tampil di atas aplikasi lain", false) {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        c3.addView(permRow(dSz, "Shizuku (baca log + force stop)", false) {
            ShizukuHelper.requestPermission()
        })
        dA11y = dot()
        dBat = dot()
        c3.addView(permRow(dA11y, "Aksesibilitas (baca layar + ketuk)", false) {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        c3.addView(permRow(dBat, "Baterai \"Tanpa batasan\"", false) { requestBattery() })
        c3.addView(
            text("Pembacaan log dan force stop hanya berlaku untuk aplikasi yang kamu centang.", 12f, c888),
            lpMW(top = dp(8))
        )
        c3.addView(
            text(
                "Setelah memasang pembaruan APK, matikan lalu nyalakan lagi Aksesibilitas " +
                    "\"Project ats (baca layar)\" supaya versi baru yang dipakai.",
                12f, c888
            ),
            lpMW(top = dp(6))
        )
        box.addView(c3)

        listOf(etD1, etD2, etD3, etTapMs, etTapX, etTapY, etOcrKeys).forEach { e -> watch(e) { saveSet() } }
        cbOcr.setOnCheckedChangeListener { _, _ -> saveSet() }
        cbBack.setOnCheckedChangeListener { _, _ -> saveSet() }
        cbTapOn.setOnCheckedChangeListener { _, _ -> saveSet() }
        return sv
    }

    private fun permRow(d: View?, s: String, outline: Boolean, onClick: () -> Unit): View {
        val r = hbox()
        r.setPadding(0, dp(8), 0, dp(8))
        if (d != null) r.addView(d)
        val lp = lpWeight()
        if (d != null) lp.leftMargin = dp(10)
        r.addView(text(s, 15f, Color.WHITE), lp)
        val blp = lpWW()
        blp.leftMargin = dp(8)
        r.addView(button("Atur", outline = outline, small = true) { onClick() }, blp)
        return r
    }

    // =====================================================================
    // Setelan tersimpan
    // =====================================================================

    private fun loadSettings() {
        loadingUi = true
        etD1.setText(prefs.getString("d1", "7450"))
        etD2.setText(prefs.getString("d2", "6500"))
        etD3.setText((prefs.getString("d3", "") ?: "").ifEmpty { "600" })
        etTarget.setText(prefs.getString("target", "0"))
        etQf.setText(prefs.getString("qf", ""))
        cbBack.isChecked = prefs.getBoolean("back", false)
        cbTapOn.isChecked = prefs.getBoolean("tapOn", false)
        etTapMs.setText((prefs.getString("tapMs", "") ?: "").ifEmpty { "3000" })
        etTapX.setText((prefs.getString("tapX", "") ?: "").ifEmpty { "1200" })
        etTapY.setText((prefs.getString("tapY", "") ?: "").ifEmpty { "960" })
        cbOcr.isChecked = prefs.getBoolean("ocrOn", true)
        etOcrKeys.setText((prefs.getString("ocrKeys", "") ?: "").ifEmpty { "Create Character" })
        sel.clear()
        sel.addAll(prefs.getStringSet("sel", null) ?: emptySet())
        loadingUi = false
        hints()
        updateSelCount()
    }

    private fun saveSet() {
        if (loadingUi) return
        prefs.edit()
            .putString("d1", etD1.text.toString())
            .putString("d2", etD2.text.toString())
            .putString("d3", etD3.text.toString())
            .putString("target", etTarget.text.toString())
            .putString("qf", etQf.text.toString())
            .putBoolean("back", cbBack.isChecked)
            .putBoolean("tapOn", cbTapOn.isChecked)
            .putString("tapMs", etTapMs.text.toString())
            .putString("tapX", etTapX.text.toString())
            .putString("tapY", etTapY.text.toString())
            .putBoolean("ocrOn", cbOcr.isChecked)
            .putString("ocrKeys", etOcrKeys.text.toString())
            .apply()
        hints()
    }

    private fun saveSel() {
        prefs.edit().putStringSet("sel", HashSet(sel)).apply()
        updateSelCount()
    }

    private fun updateSelCount() {
        val n = if (appsLoaded) apps.count { sel.contains(it.pkg) } else sel.size
        tvSel.text = "$n aplikasi dipilih"
    }

    private fun hintText(v: String): String {
        val n = v.toDoubleOrNull() ?: return "Isi angka dalam milidetik."
        val sec = BigDecimal.valueOf(Math.round(n)).movePointLeft(3)
            .stripTrailingZeros().toPlainString().replace('.', ',')
        var t = "= $sec detik"
        if (n < 1000) {
            t += "<br><b><u>Peringatan:</u></b> nilai di bawah 1000 (kurang dari 1 detik). Ingat, 1000 = 1 detik."
        }
        return t
    }

    private fun tapHintText(): String {
        val v = etTapMs.text.toString()
        var t = hintText(v)
        val a = v.toDoubleOrNull()
        val b = etD1.text.toString().toDoubleOrNull()
        if (a != null && b != null && a >= b) {
            t += "<br><b><u>Peringatan:</u></b> waktu ketukan lebih besar atau sama dengan jeda 1, jadi ketukan tidak dijalankan."
        }
        return t
    }

    private fun hints() {
        h1.text = Html.fromHtml(hintText(etD1.text.toString()), Html.FROM_HTML_MODE_LEGACY)
        h2v.text = Html.fromHtml(hintText(etD2.text.toString()), Html.FROM_HTML_MODE_LEGACY)
        h3.text = Html.fromHtml(hintText(etD3.text.toString()), Html.FROM_HTML_MODE_LEGACY)
        hTap.text = Html.fromHtml(tapHintText(), Html.FROM_HTML_MODE_LEGACY)
    }

    // =====================================================================
    // Aksi
    // =====================================================================

    private fun doStart() {
        hideKeyboard()
        if (!appsLoaded) {
            alert("Daftar aplikasi masih dimuat, tunggu sebentar.")
            return
        }
        val p = apps.filter { sel.contains(it.pkg) }.map { it.pkg }
        if (p.isEmpty()) {
            alert("Centang aplikasi dulu di tab Apps.")
            return
        }
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.putExtra("pkgs", p.toTypedArray())
        i.putExtra("d1", etD1.text.toString().toLongOrNull() ?: 7450L)
        i.putExtra("d2", etD2.text.toString().toLongOrNull() ?: 6500L)
        i.putExtra("d3", etD3.text.toString().toLongOrNull() ?: 600L)
        i.putExtra("target", etTarget.text.toString().toIntOrNull() ?: 0)
        i.putExtra("back", cbBack.isChecked)
        i.putExtra("tapOn", cbTapOn.isChecked)
        i.putExtra("tapMs", etTapMs.text.toString().toLongOrNull() ?: 3000L)
        i.putExtra("tapX", etTapX.text.toString().toIntOrNull() ?: 1200)
        i.putExtra("tapY", etTapY.text.toString().toIntOrNull() ?: 960)
        i.putExtra("ocrOn", cbOcr.isChecked)
        i.putExtra("ocrKeys", etOcrKeys.text.toString())
        try {
            startForegroundService(i)
        } catch (e: Exception) {
            alert("Gagal memulai: " + e.javaClass.simpleName)
        }
        main.postDelayed({ poll() }, 150)
    }

    private fun doStop() {
        val i = Intent(this, RunnerService::class.java)
        i.action = "STOP"
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    // Tes ketuk: hitung mundur 5 detik lalu satu ketukan ke (x, y)
    private fun doTapTest() {
        hideKeyboard()
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.action = "TAP_TEST"
        i.putExtra("tapX", etTapX.text.toString().toIntOrNull() ?: 1200)
        i.putExtra("tapY", etTapY.text.toString().toIntOrNull() ?: 960)
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    private fun batteryUnrestricted(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Throwable) {
        false
    }

    // Minta pengecualian baterai langsung; kalau ditolak sistem, buka daftar setelan
    private fun requestBattery() {
        if (batteryUnrestricted()) {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            return
        }
        try {
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    // Tes OCR: hitung mundur 5 detik lalu baca layar satu kali
    private fun doOcrTest() {
        hideKeyboard()
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.action = "OCR_TEST"
        i.putExtra("ocrKeys", etOcrKeys.text.toString())
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Penyegaran status (tiap 700 ms)
    // =====================================================================

    private fun poll() {
        val run = RunnerService.running
        val rv = if (run) View.GONE else View.VISIBLE
        if (vReady.visibility != rv) vReady.visibility = rv
        val rr = if (run) View.VISIBLE else View.GONE
        if (vRun.visibility != rr) vRun.visibility = rr

        setDot(hdDot, run)
        setIfChanged(hdTxt, if (run) "Berjalan" else "Siap")
        ring.setProgress(RunnerService.done, RunnerService.total)
        setIfChanged(tvPhase, RunnerService.phase)
        setIfChanged(tvFound, RunnerService.found.toString())
        val t = etTarget.text.toString().toIntOrNull() ?: 0
        setIfChanged(tvTgt, if (t > 0) t.toString() else "Bebas")

        val ov = Settings.canDrawOverlays(this)
        val sz = ShizukuHelper.hasPermission()
        setDot(dOv, ov)
        setDot(pOv, ov)
        setDot(dSz, sz)
        setDot(pSz, sz)
        val a11y = OcrA11yService.isRunning()
        setDot(dA11y, a11y)
        setDot(pA11y, a11y)
        setDot(dBat, batteryUnrestricted())

        setEnabledLook(bTap, !RunnerService.tapTestBusy)
        setIfChanged(tvTapRes, RunnerService.tapTestResult)
        setEnabledLook(bOcr, !RunnerService.ocrTestBusy)
        setIfChanged(tvOcrRes, RunnerService.ocrTestResult)

        renderLog(RunnerService.logsSnapshot())

        val sv = RunnerService.serversSnapshot()
        setIfChanged(tvSrv, if (sv.isEmpty()) "Belum ada server." else sv.joinToString("\n"))
        setIfChanged(tvSrvTitle, "Server didapat (${sv.size})")
    }
}
