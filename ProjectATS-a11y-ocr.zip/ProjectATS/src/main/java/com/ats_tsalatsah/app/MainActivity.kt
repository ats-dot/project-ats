package com.ats_tsalatsah.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.math.BigDecimal

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    // Tinggi hiasan header (kabut+pinus / gunung) dan jarak isi halaman
    // dari bawah judul, supaya hiasan terlihat utuh di atas kartu pertama
    private val DECOR_H = 130
    private val PAGE_TOP = 68
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    // ---------- Data ----------
    private data class AppItem(val name: String, val pkg: String)

    private class Ses(val head: String) {
        val rows = ArrayList<String>()
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var pal: Palette

    private var apps: List<AppItem> = emptyList()
    private var appsLoaded = false
    private var shown: List<AppItem> = emptyList()
    private val sel = HashSet<String>()
    private val openArc = HashSet<Int>()
    private var lastLogKey = ""
    private var loadingUi = false
    private var startTab = 0
    private var lastSes: Ses? = null
    private var lastSesNo = 0
    private var statusState = -1
    private var pulse: ObjectAnimator? = null
    private var sheetOpen = false

    private val rxDate = Regex("(\\d{4})-(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)")
    private val rxTime = Regex("\\d\\d:\\d\\d:\\d\\d(\\.\\d+)?")
    private val rxApk = Regex("^\\S+\\s+Buka [A-Za-z0-9_.]+\\s*$")
    private val rxSrv = Regex("Server \\d+ dicatat")
    private val mon = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    // ---------- View ----------
    private lateinit var root: FrameLayout
    private lateinit var pager: PagerView
    private lateinit var tabBar: TabBar
    private lateinit var navWrap: FrameLayout
    private lateinit var hdDot: View
    private lateinit var hdTxt: TextView

    // Cabang
    private lateinit var vReady: LinearLayout
    private lateinit var vRun: LinearLayout
    private lateinit var etTarget: EditText
    private lateinit var tvSel: TextView
    private lateinit var pSz: View
    private lateinit var pA11y: View
    private lateinit var pOv: View
    private lateinit var ring: RingView
    private lateinit var tvPhase: TextView
    private lateinit var tvFound: TextView
    private lateinit var tvTgt: TextView
    private lateinit var swNick: Switch
    private lateinit var etNick: EditText
    private lateinit var etNickStart: EditText
    private lateinit var tvNickWarn: TextView
    private lateinit var bNameTest: TextView
    private lateinit var tvNameRes: TextView

    // Apps
    private lateinit var etQ: EditText
    private lateinit var etQf: EditText
    private lateinit var tvCount: TextView
    private lateinit var listView: ListView
    private lateinit var tvEmpty: TextView
    private val adapter = AppAdapter()

    // Aktivitas
    private lateinit var subBar: TabBar
    private lateinit var vLog: LinearLayout
    private lateinit var vArc: LinearLayout
    private lateinit var tvSrvTitle: TextView
    private lateinit var tvSrv: TextView
    private lateinit var tvNotesTop: TextView
    private lateinit var vNotesLine: View

    private lateinit var swKaitkan: Switch
    private lateinit var etKaitkan: EditText
    private lateinit var tvKaitkanWarn: TextView
    private var kaitkanSyncing = false
    private lateinit var stockPage: FrameLayout
    private lateinit var stockRows: LinearLayout
    private lateinit var tvStockCount: TextView
    private lateinit var swStock: Switch
    private lateinit var tvStockRow: TextView
    private var stockOpen = false
    private var stockSyncing = false
    private var stockVer = -1
    private lateinit var tvLogEmpty: TextView
    private lateinit var sesBox: LinearLayout
    private lateinit var tvLogTitle: TextView
    private lateinit var tvLogBody: TextView
    private lateinit var bDlLast: TextView
    private lateinit var arcBox: LinearLayout

    // Setelan
    private lateinit var etD1: EditText
    private lateinit var etD2: EditText
    private lateinit var etD3: EditText
    private lateinit var swAnim: Switch
    private lateinit var tvSecure: TextView
    private var secureShown = -1
    private lateinit var swTapOn: Switch
    private lateinit var etTapMs: EditText
    private lateinit var etTapX: EditText
    private lateinit var etTapY: EditText
    private lateinit var bTap: TextView
    private lateinit var tvTapRes: TextView
    private lateinit var swFirst: Switch
    private lateinit var etFirstMax: EditText
    private lateinit var etAfterTap: EditText
    private lateinit var etLoginKeys: EditText
    private lateinit var bLogin: TextView
    private lateinit var tvLoginRes: TextView
    private lateinit var dOv: View
    private lateinit var dSz: View
    private lateinit var dA11y: View
    private lateinit var dBat: View

    // Lembar bawah (menu titik tiga)
    private lateinit var dim: View
    private lateinit var sheet: LinearLayout
    private lateinit var sheetMenu: LinearLayout
    private lateinit var sheetHelp: LinearLayout
    private lateinit var helpScroll: ScrollView

    private val ticker = object : Runnable {
        override fun run() {
            if (!uiReady) return
            poll()
            if (uiReady) main.postDelayed(this, 700)
        }
    }

    // =====================================================================
    // Siklus hidup
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keyboard tidak muncul sendiri saat jendela dibuka lagi; baru muncul kalau kotak diketuk
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        CrashLog.install(this)
        RunnerService.initStore(this)
        prefs = getSharedPreferences("ats_ui", Context.MODE_PRIVATE)
        pal = Themes.of(prefs.getString("theme", "dark") != "light")
        startTab = savedInstanceState?.getInt("tab", 0) ?: 0

        autoEnableA11y()

        // Ada crash dari pembukaan sebelumnya? Tampilkan dulu pesannya.
        val crash = CrashLog.takeReport(this)
        if (crash != null) {
            showCrashScreen("Aplikasi sempat berhenti mendadak", crash)
            return
        }
        startNormal()
    }

    private var uiReady = false

    // Susun tampilan utama. Error di sini ditangkap dan ditampilkan.
    private fun startNormal() {
        uiReady = false
        try {
            window.statusBarColor = pal.bg
            window.navigationBarColor = pal.bg
            window.setBackgroundDrawable(ColorDrawable(pal.bg))
            setContentView(buildRoot())
            root.requestFocus()
            setupWindow()
            loadSettings()
            if (appsLoaded) {
                tvEmpty.text = "Tidak ada aplikasi."
                renderApps()
            } else {
                loadApps()
            }
            val tab = startTab
            pager.post {
                if (!uiReady) return@post
                pager.animateTo(tab, false)
                tabBar.pos = tab.toFloat()
            }
            uiReady = true
            poll()
            main.removeCallbacks(ticker)
            main.post(ticker)
        } catch (e: Throwable) {
            showCrashScreen("Tampilan gagal disusun", android.util.Log.getStackTraceString(e))
            return
        }
        // Izin notifikasi diminta setelah tampilan siap
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            // Ditunda: kalau Shizuku siap, izin ini diberikan otomatis dan dialognya tidak perlu muncul
            main.postDelayed({
                if (!isFinishing && !isDestroyed && !AutoPerms.notifOk(this)) {
                    requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                }
            }, 2500)
        }
    }

    // Layar darurat: pesan error lengkap + tombol salin / coba lagi / reset tema.
    // Sengaja dibuat sederhana supaya tidak ikut error.
    private fun showCrashScreen(title: String, report: String) {
        uiReady = false
        main.removeCallbacks(ticker)
        try {
            RunnerService.addLog("ERROR: $title")
            report.lines().filter { it.isNotBlank() }.take(14).forEach { RunnerService.addLog("  " + it.trim()) }
        } catch (e: Throwable) {
        }
        val bg = Color.parseColor("#111313")
        val fg = Color.parseColor("#E9ECEB")
        val mu = Color.parseColor("#8C9392")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(px(20), px(32), px(20), px(32))
        sv.addView(box)

        val t = TextView(this)
        t.text = title
        t.setTextColor(fg)
        t.textSize = 20f
        t.typeface = Typeface.DEFAULT_BOLD
        box.addView(t)

        val info = TextView(this)
        info.text = "Salin atau screenshot pesan di bawah ini lalu kirim ke pengembang. " +
            "Aplikasi tidak tertutup, jadi kamu bisa coba lagi."
        info.setTextColor(mu)
        info.textSize = 14f
        info.setPadding(0, px(8), 0, px(16))
        box.addView(info)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(label: String, onClick: () -> Unit) {
            val b = TextView(this)
            b.text = label
            b.setTextColor(Color.parseColor("#121414"))
            b.textSize = 14f
            b.typeface = Typeface.DEFAULT_BOLD
            b.setPadding(px(14), px(9), px(14), px(9))
            val g = GradientDrawable()
            g.setColor(Color.parseColor("#D9DEDD"))
            g.cornerRadius = px(99).toFloat()
            b.background = g
            b.setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = px(8)
            row.addView(b, lp)
        }
        btn("Salin") {
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("error", "$title\n$report"))
                Toast.makeText(this, "Pesan error disalin", Toast.LENGTH_SHORT).show()
            } catch (e: Throwable) {
            }
        }
        btn("Coba lagi") { startNormal() }
        btn("Reset tema") {
            prefs.edit().putString("theme", "dark").apply()
            pal = Themes.of(true)
            startNormal()
        }
        box.addView(row)

        val r = TextView(this)
        r.text = report
        r.setTextColor(fg)
        r.textSize = 11f
        r.typeface = Typeface.MONOSPACE
        r.setTextIsSelectable(true)
        r.setPadding(0, px(18), 0, 0)
        box.addView(r)

        setContentView(sv)
    }

    private fun setupWindow() {
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        val lightBars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (pal.dark) 0 else lightBars, lightBars)
    }

    // Ganti tema langsung di tempat (tanpa membuat ulang Activity)
    private fun applyTheme(dark: Boolean) {
        startTab = if (::pager.isInitialized) pager.current else 0
        pal = Themes.of(dark)
        pulse?.cancel()
        pulse = null
        statusState = -1
        lastLogKey = ""
        sheetOpen = false
        hideKeyboard()
        startNormal()
        if (uiReady) {
            root.alpha = 0f
            root.animate().alpha(1f).setDuration(280).start()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::pager.isInitialized) outState.putInt("tab", pager.current)
    }

    override fun onResume() {
        super.onResume()
        autoEnableA11y()
        main.removeCallbacks(ticker)
        if (uiReady) main.post(ticker)
    }

    // Jalur A: nyalakan layanan Aksesibilitas sendiri (kalau izin WRITE_SECURE_SETTINGS sudah ada)
    private fun autoEnableA11y() {
        try {
            SecureA11y.ensure(this)
        } catch (e: Throwable) {
        }
    }

    override fun onPause() {
        hideKeyboard()
        main.removeCallbacks(ticker)
        super.onPause()
    }

    // Tombol utama (Home) ditekan: tutup keyboard dulu
    override fun onUserLeaveHint() {
        hideKeyboard()
        super.onUserLeaveHint()
    }

    override fun onDestroy() {
        pulse?.cancel()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!uiReady) {
            super.onBackPressed()
            return
        }
        when {
            stockOpen -> closeStockPage()
            sheetOpen -> {
                if (sheetHelp.visibility == View.VISIBLE) showSheetMenu() else closeSheet()
            }
            pager.current != 0 -> showTab(0)
            else -> super.onBackPressed()
        }
    }

    // =====================================================================
    // Pembantu tampilan
    // =====================================================================

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun dp(v: Int): Int = dp(v.toFloat())

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) g.setStroke(maxOf(1, dp(0.6f)), stroke)
        return g
    }

    private fun pressable(bg: Drawable): RippleDrawable {
        val rip = if (pal.dark) 0x33FFFFFF else 0x22000000
        return RippleDrawable(ColorStateList.valueOf(rip), bg, null)
    }

    private fun lpMW(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = top
        lp.bottomMargin = bottom
        return lp
    }

    private fun lpWW(top: Int = 0, bottom: Int = 0, left: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = top
        lp.bottomMargin = bottom
        lp.leftMargin = left
        return lp
    }

    private fun lpWeight(left: Int = 0, right: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = left
        lp.rightMargin = right
        return lp
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    private fun text(s: String, sizeSp: Float, color: Int = pal.text, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun mono(s: String): TextView {
        val t = text(s, 12f, pal.text)
        t.typeface = Typeface.MONOSPACE
        t.setLineSpacing(0f, 1.4f)
        t.setTextIsSelectable(true)
        return t
    }

    private fun card(): LinearLayout {
        val c = vbox()
        c.background = rounded(pal.card, 22f, pal.border)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.layoutParams = lpMW(bottom = dp(10))
        return c
    }

    // Tombol kecil berbentuk pil
    private fun chip(s: String, filled: Boolean = false, onClick: () -> Unit): TextView {
        val t = text(s, 13f, if (filled) pal.onPrimary else pal.text, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(7), dp(14), dp(7))
        t.background = pressable(
            if (filled) rounded(pal.primary, 999f) else rounded(pal.card, 999f, pal.borderStrong)
        )
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    // Tombol besar penuh lebar
    private fun bigButton(s: String, filled: Boolean, onClick: () -> Unit): LinearLayout {
        val b = hbox()
        b.gravity = Gravity.CENTER
        b.background = pressable(
            if (filled) rounded(pal.primary, 999f) else rounded(Color.TRANSPARENT, 999f, pal.borderStrong)
        )
        b.setPadding(dp(18), dp(16), dp(18), dp(16))
        b.isClickable = true
        if (filled) b.addView(PlayIcon(this, pal.onPrimary), LinearLayout.LayoutParams(dp(18), dp(18)))
        val t = text(s, 16f, if (filled) pal.onPrimary else pal.text, true)
        b.addView(t, lpWW(left = if (filled) dp(10) else 0))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun roundIcon(s: String, onClick: () -> Unit): TextView {
        val t = text(s, 22f, pal.text)
        t.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.card)
        g.setStroke(maxOf(1, dp(0.6f)), pal.borderStrong)
        t.background = pressable(g)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    private fun setEnabledLook(v: View, en: Boolean) {
        if (v.isEnabled != en) v.isEnabled = en
        v.alpha = if (en) 1f else 0.4f
    }

    private fun dot(sizeDp: Int = 8): View {
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.dotOff)
        v.background = g
        v.tag = null
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun setDotColor(v: View, color: Int) {
        if (v.tag == color) return
        v.tag = color
        (v.background as GradientDrawable).setColor(color)
    }

    private fun setDot(v: View, ok: Boolean) = setDotColor(v, if (ok) pal.dotOn else pal.dotOff)

    private fun input(numeric: Boolean, hintText: String = "", pill: Boolean = false): EditText {
        val e = EditText(this)
        e.setTextColor(pal.text)
        e.setHintTextColor(pal.hint)
        e.hint = hintText
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        e.background = rounded(pal.field, if (pill) 999f else 14f, pal.border)
        e.setPadding(dp(14), dp(10), dp(14), dp(10))
        e.inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        e.setSingleLine(true)
        closeOnDone(e)
        if (Build.VERSION.SDK_INT >= 29) e.textCursorDrawable = rounded(pal.text, 1f).also {
            it.setSize(dp(2), dp(20))
        }
        return e
    }

    private fun switchView(): Switch {
        val s = Switch(this)
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(st, intArrayOf(pal.onPrimary, pal.muted))
        s.trackTintList = ColorStateList(st, intArrayOf(pal.primary, pal.borderStrong))
        return s
    }

    private fun watch(e: EditText, f: () -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                f()
            }
        })
    }

    private fun setIfChanged(t: TextView, s: String) {
        if (t.text.toString() != s) t.text = s
    }

    private fun scrollPage(): Pair<ScrollView, LinearLayout> {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.isVerticalScrollBarEnabled = false
        sv.clipToPadding = false
        val inner = vbox()
        inner.setPadding(dp(16), dp(PAGE_TOP), dp(16), dp(110))
        sv.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        return Pair(sv, inner)
    }

    // Tutup keyboard, lepas fokus dari kotak isian, lalu kembalikan fokus ke root
    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val tok = window.decorView.windowToken
            if (tok != null) imm.hideSoftInputFromWindow(tok, 0)
            currentFocus?.clearFocus()
            if (::root.isInitialized) root.requestFocus()
        } catch (e: Throwable) {
        }
    }

    // 1. Tombol aksi keyboard jadi centang ("Selesai") dan menutup keyboard
    private fun closeOnDone(e: EditText) {
        e.imeOptions = EditorInfo.IME_ACTION_DONE
        e.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            true
        }
    }

    // 5. Sentuhan di luar kotak isian yang sedang fokus menutup keyboard
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f is EditText) {
                val r = Rect()
                f.getGlobalVisibleRect(r)
                if (!r.contains(ev.rawX.toInt(), ev.rawY.toInt())) hideKeyboard()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun dialogTheme(): Int =
        if (pal.dark) android.R.style.Theme_DeviceDefault_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert

    private fun alert(msg: String) {
        if (isFinishing) return
        AlertDialog.Builder(this, dialogTheme())
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun open(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Susunan layar
    // =====================================================================

    private fun buildRoot(): View {
        root = SafeFrame(this) { e ->
            showCrashScreen("Tampilan mengalami error", android.util.Log.getStackTraceString(e))
        }
        root.setBackgroundColor(pal.bg)
        // Root yang memegang fokus, supaya tidak ada EditText yang otomatis terfokus
        root.isFocusable = true
        root.isFocusableInTouchMode = true

        // Hiasan header (kabut/pinus atau gunung)
        root.addView(HeaderDecor(this, pal), FrameLayout.LayoutParams(MATCH, dp(DECOR_H)))

        val col = vbox()
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildHeader(), LinearLayout.LayoutParams(MATCH, WRAP))

        pager = PagerView(this)
        pager.addView(buildPageCabang())
        pager.addView(buildPageApps())
        pager.addView(buildPageAktivitas())
        pager.addView(buildPageSetelan())
        col.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Menu tab bawah dengan pil meluncur
        tabBar = TabBar(this, pal, arrayOf("Cabang", "Apps", "Aktivitas", "Setelan"), 13f) { showTab(it) }
        tabBar.setPadding(dp(5), dp(5), dp(5), dp(5))
        tabBar.background = rounded(pal.navBg, 999f, pal.border)
        tabBar.elevation = dp(4).toFloat()
        navWrap = FrameLayout(this)
        navWrap.addView(tabBar, FrameLayout.LayoutParams(MATCH, WRAP))
        val nlp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        nlp.setMargins(dp(16), 0, dp(16), dp(16))
        root.addView(navWrap, nlp)

        pager.onScroll = { tabBar.pos = it }
        pager.onSelected = { hideKeyboard() }

        buildSheet()
        stockPage = buildStockPage()
        root.addView(stockPage, FrameLayout.LayoutParams(MATCH, MATCH))

        // Sembunyikan menu bawah saat keyboard muncul
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            root.getWindowVisibleDisplayFrame(r)
            val h = root.rootView.height
            val kb = h - r.bottom > h * 0.2
            val vis = if (kb) View.GONE else View.VISIBLE
            if (navWrap.visibility != vis) navWrap.visibility = vis
        }
        return root
    }

    private fun showTab(i: Int) {
        hideKeyboard()
        pager.animateTo(i)
    }

    private fun buildHeader(): View {
        val h = hbox()
        h.setPadding(dp(18), dp(18), dp(18), dp(14))
        h.addView(LogoView(this, pal, false), LinearLayout.LayoutParams(dp(30), dp(30)))
        h.addView(text("Project ats", 19f, pal.text, true), lpWeight(left = dp(10)))

        val pill = hbox()
        pill.background = pressable(rounded(if (pal.dark) 0xD9151717.toInt() else Color.WHITE, 999f, pal.borderStrong))
        pill.setPadding(dp(12), dp(6), dp(12), dp(6))
        hdDot = dot(8)
        hdTxt = text("Siap", 12f, pal.text, true)
        pill.addView(hdDot)
        pill.addView(hdTxt, lpWW(left = dp(7)))
        pill.isClickable = true
        pill.setOnClickListener { explainStatus() }
        h.addView(pill)
        return h
    }

    // ---------- Halaman Cabang ----------

    private fun buildPageCabang(): View {
        val (sv, box) = scrollPage()

        vReady = vbox()

        // Kartu target dengan hiasan
        val frame = FrameLayout(this)
        frame.background = rounded(pal.card, 26f, pal.border)
        frame.clipToOutline = true
        frame.addView(CardDecor(this, pal), FrameLayout.LayoutParams(MATCH, MATCH))
        val c1 = vbox()
        c1.gravity = Gravity.CENTER_HORIZONTAL
        c1.setPadding(dp(16), dp(18), dp(16), dp(16))
        c1.addView(text("Target server", 13f, pal.muted, true), lpWW())

        val step = hbox()
        etTarget = EditText(this)
        etTarget.setTextColor(pal.text)
        etTarget.setTextSize(TypedValue.COMPLEX_UNIT_SP, 46f)
        etTarget.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        etTarget.gravity = Gravity.CENTER
        etTarget.background = null
        etTarget.inputType = InputType.TYPE_CLASS_NUMBER
        etTarget.setSingleLine(true)
        closeOnDone(etTarget)
        step.addView(roundIcon("\u2212") { stepTarget(-1) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        step.addView(etTarget, lpWeight())
        step.addView(roundIcon("+") { stepTarget(1) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        c1.addView(step, lpMW(top = dp(6), bottom = dp(6)))

        if (pal.dark) c1.addView(GroundLine(this, pal), LinearLayout.LayoutParams(MATCH, dp(6)))
        tvSel = text("0 = tanpa target \u00B7 0 aplikasi dipilih", 12f, pal.muted)
        c1.addView(tvSel, lpWW(top = dp(10)))
        frame.addView(c1, FrameLayout.LayoutParams(MATCH, WRAP))
        vReady.addView(frame, lpMW(bottom = dp(10)))
        vReady.addView(buildNickCard())
        vReady.addView(buildKaitkanCard())

        // Status izin
        val pr = hbox()
        pSz = dot(7)
        pA11y = dot(7)
        pOv = dot(7)
        pr.addView(statusChip(pSz, "Shizuku"), lpWeight(right = dp(4)))
        pr.addView(statusChip(pA11y, "Akses"), lpWeight(left = dp(4), right = dp(4)))
        pr.addView(statusChip(pOv, "Overlay"), lpWeight(left = dp(4)))
        vReady.addView(pr, lpMW(bottom = dp(12)))

        vReady.addView(bigButton("Mulai", true) { doStart() }, lpMW())
        box.addView(vReady, lpMW())

        // Tampilan saat berjalan
        vRun = vbox()
        vRun.visibility = View.GONE
        val c3 = card()
        c3.gravity = Gravity.CENTER_HORIZONTAL
        ring = RingView(this, pal)
        c3.addView(ring, LinearLayout.LayoutParams(dp(180), dp(180)))
        tvPhase = text("Putaran 1", 12f, pal.text, true)
        tvPhase.background = rounded(Color.TRANSPARENT, 999f, pal.borderStrong)
        tvPhase.setPadding(dp(12), dp(5), dp(12), dp(5))
        c3.addView(tvPhase, lpWW(top = dp(4)))
        if (pal.dark) c3.addView(GroundLine(this, pal), LinearLayout.LayoutParams(MATCH, dp(6)).also {
            it.topMargin = dp(14)
        })
        vRun.addView(c3)

        val row = hbox()
        val cf = card()
        cf.gravity = Gravity.CENTER_HORIZONTAL
        tvFound = text("0", 30f, pal.text, true)
        tvFound.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        cf.addView(tvFound, lpWW())
        cf.addView(text("Server didapat", 12f, pal.muted), lpWW())
        val ct = card()
        ct.gravity = Gravity.CENTER_HORIZONTAL
        tvTgt = text("0", 30f, pal.text, true)
        tvTgt.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        ct.addView(tvTgt, lpWW())
        ct.addView(text("Target", 12f, pal.muted), lpWW())
        row.addView(cf, lpWeight(right = dp(5)))
        row.addView(ct, lpWeight(left = dp(5)))
        vRun.addView(row, lpMW(bottom = dp(4)))
        vRun.addView(bigButton("Hentikan", false) { doStop() }, lpMW())
        box.addView(vRun, lpMW())

        watch(etTarget) { saveSet() }
        watch(etNick) { saveSet() }
        watch(etNickStart) { saveSet() }
        swNick.setOnCheckedChangeListener { _, _ -> saveSet() }
        watch(etKaitkan) {
            if (!loadingUi && !kaitkanSyncing) {
                EmailStock.setField(this, etKaitkan.text.toString())
                updateKaitkan()
            }
        }
        swKaitkan.setOnCheckedChangeListener { _, on ->
            if (!loadingUi) {
                EmailStock.setKaitkanOn(this, on)
                updateKaitkan()
            }
        }
        return sv
    }

    // Kartu nickname otomatis (diisi di putaran 2 saat halaman Create Character muncul)
    private fun buildNickCard(): View {
        val c = card()
        val top = hbox()
        top.addView(text("Nickname otomatis", 14f, pal.text, true), lpWeight())
        swNick = switchView()
        top.addView(swNick)
        c.addView(top, lpMW(bottom = dp(10)))

        val row = hbox()
        row.gravity = Gravity.TOP
        val c1 = vbox()
        c1.addView(text("Nickname", 12f, pal.muted), lpMW(bottom = dp(4)))
        etNick = input(false, "Ats-")
        c1.addView(etNick)
        val c2 = vbox()
        c2.addView(text("Nomor awal", 12f, pal.muted), lpMW(bottom = dp(4)))
        etNickStart = input(true, "1")
        c2.addView(etNickStart)
        row.addView(c1, LinearLayout.LayoutParams(0, WRAP, 2f).also { it.rightMargin = dp(8) })
        row.addView(c2, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(row, lpMW())

        // Peringatan kecil, hanya muncul kalau nickname tidak bisa dipakai
        tvNickWarn = text("", 12f, pal.danger)
        tvNickWarn.visibility = View.GONE
        c.addView(tvNickWarn, lpMW(top = dp(8)))

        bNameTest = chip("Tes isi nama", true) { doNameTest() }
        c.addView(bNameTest, lpWW(top = dp(10)))
        tvNameRes = text("", 12f, pal.muted)
        c.addView(tvNameRes, lpMW(top = dp(6)))
        return c
    }

    private fun statusChip(d: View, s: String): View {
        val p = hbox()
        p.gravity = Gravity.CENTER
        p.background = rounded(pal.card, 999f, pal.border)
        p.setPadding(dp(8), dp(9), dp(8), dp(9))
        p.addView(d)
        p.addView(text(s, 12f, pal.text, true), lpWW(left = dp(6)))
        return p
    }

    private fun stepTarget(delta: Int) {
        val n = etTarget.text.toString().toIntOrNull() ?: 0
        val v = maxOf(0, n + delta).toString()
        etTarget.setText(v)
        etTarget.setSelection(v.length)
    }

    // ---------- Halaman Apps ----------

    private fun buildPageApps(): View {
        val box = vbox()
        box.setPadding(dp(16), dp(PAGE_TOP), dp(16), dp(96))

        etQ = input(false, "Cari nama atau paket", pill = true)
        box.addView(etQ, lpMW())

        val r = hbox()
        r.addView(chip("Pilih hasil", true) {
            shown.forEach { sel.add(it.pkg) }
            renderApps()
        })
        r.addView(chip("Kosongkan") {
            sel.clear()
            renderApps()
        }, lpWW(left = dp(8)))
        r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        tvCount = text("0 dipilih", 12f, pal.muted, true)
        r.addView(tvCount)
        box.addView(r, lpMW(top = dp(10), bottom = dp(10)))

        val r2 = hbox()
        etQf = input(false, "Filter cepat, contoh: Mobile Legends", pill = true)
        r2.addView(etQf, lpWeight())
        r2.addView(chip("Pilih", true) { quickFilter() }, lpWW(left = dp(8)))
        box.addView(r2, lpMW(bottom = dp(10)))

        val c2 = vbox()
        c2.background = rounded(pal.card, 22f, pal.border)
        c2.setPadding(dp(14), dp(2), dp(14), dp(2))
        val frame = FrameLayout(this)
        listView = ListView(this)
        listView.divider = ColorDrawable(pal.border)
        listView.dividerHeight = 1
        listView.selector = ColorDrawable(Color.TRANSPARENT)
        listView.isVerticalScrollBarEnabled = false
        listView.adapter = adapter
        listView.setOnItemClickListener { _, view, pos, _ ->
            if (pos < 0 || pos >= shown.size) return@setOnItemClickListener
            val a = shown[pos]
            if (sel.contains(a.pkg)) sel.remove(a.pkg) else sel.add(a.pkg)
            ((view as LinearLayout).getChildAt(1) as CheckDot).checked = sel.contains(a.pkg)
            saveSel()
        }
        tvEmpty = text("Memuat...", 14f, pal.muted)
        tvEmpty.setPadding(0, dp(14), 0, dp(14))
        frame.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(tvEmpty, FrameLayout.LayoutParams(MATCH, WRAP))
        listView.emptyView = tvEmpty
        c2.addView(frame, LinearLayout.LayoutParams(MATCH, MATCH))
        box.addView(c2, LinearLayout.LayoutParams(MATCH, 0, 1f))

        watch(etQ) { renderApps() }
        watch(etQf) { saveSet() }
        return box
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: makeAppRow()
            val a = shown[position]
            val col = row.getChildAt(0) as LinearLayout
            (col.getChildAt(0) as TextView).text = a.name
            (col.getChildAt(1) as TextView).text = a.pkg
            (row.getChildAt(1) as CheckDot).checked = sel.contains(a.pkg)
            return row
        }
    }

    private fun makeAppRow(): LinearLayout {
        val row = hbox()
        row.setPadding(0, dp(11), 0, dp(11))
        val col = vbox()
        col.addView(text("", 14f, pal.text, true))
        val pkg = text("", 11f, pal.muted)
        pkg.typeface = Typeface.MONOSPACE
        col.addView(pkg)
        row.addView(col, lpWeight())
        row.addView(CheckDot(this, pal), LinearLayout.LayoutParams(dp(24), dp(24)).also { it.leftMargin = dp(10) })
        return row
    }

    private fun loadApps() {
        Thread {
            val list = try {
                val pm = packageManager
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(q, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                    .distinctBy { it.pkg }
                    .sortedBy { it.name.lowercase() }
            } catch (e: Throwable) {
                emptyList()
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                apps = list
                appsLoaded = true
                if (uiReady) {
                    tvEmpty.text = "Tidak ada aplikasi."
                    renderApps()
                }
            }
        }.start()
    }

    private fun renderApps() {
        val q = etQ.text.toString().lowercase()
        shown = apps.filter {
            q.isEmpty() || it.name.lowercase().contains(q) || it.pkg.lowercase().contains(q)
        }
        adapter.notifyDataSetChanged()
        saveSel()
    }

    private fun quickFilter() {
        val f = etQf.text.toString().lowercase().trim()
        if (f.isEmpty()) return
        apps.forEach {
            if (it.name.lowercase().contains(f) || it.pkg.lowercase().contains(f)) sel.add(it.pkg)
        }
        hideKeyboard()
        renderApps()
    }

    // ---------- Halaman Aktivitas ----------

    private fun buildPageAktivitas(): View {
        val (sv, box) = scrollPage()

        subBar = TabBar(this, pal, arrayOf("Log aktivitas", "Arsip"), 13f) { setSub(it) }
        subBar.setPadding(dp(4), dp(4), dp(4), dp(4))
        subBar.background = rounded(pal.card, 999f, pal.border)
        box.addView(subBar, lpMW(bottom = dp(12)))

        // Log
        vLog = vbox()
        val cs = card()
        val rs = hbox()
        tvSrvTitle = text("Catatan umum (0)", 14f, pal.text, true)
        rs.addView(tvSrvTitle, lpWeight())
        rs.addView(chip("Hapus") {
            doDel("Hapus catatan umum? Log dan arsip tidak ikut terhapus.") { RunnerService.clearServers() }
        })
        cs.addView(rs, lpMW(bottom = dp(8)))
        tvNotesTop = mono("")
        tvNotesTop.visibility = View.GONE
        cs.addView(tvNotesTop, lpMW())
        vNotesLine = View(this)
        vNotesLine.setBackgroundColor(pal.border)
        vNotesLine.visibility = View.GONE
        cs.addView(vNotesLine, LinearLayout.LayoutParams(MATCH, 1).also {
            it.topMargin = dp(6)
            it.bottomMargin = dp(6)
        })
        tvSrv = mono("Belum ada catatan.")
        cs.addView(tvSrv, lpMW())
        vLog.addView(cs)

        val cl = card()
        val rl = hbox()
        rl.addView(text("Sesi terakhir", 14f, pal.text, true), lpWeight())
        bDlLast = chip("Unduh") {
            val s = lastSes
            if (s != null) downloadSession(lastSesNo, s) else toast("Belum ada sesi untuk diunduh")
        }
        rl.addView(bDlLast)
        rl.addView(chip("Hapus") {
            doDel("Hapus sesi terakhir? Arsip dan daftar server tidak ikut terhapus.") {
                RunnerService.clearLastSession()
            }
        }, lpWW(left = dp(6)))
        cl.addView(rl, lpMW(bottom = dp(8)))
        tvLogEmpty = text("Belum ada aktivitas.", 13f, pal.muted)
        cl.addView(tvLogEmpty, lpMW())
        sesBox = vbox()
        sesBox.visibility = View.GONE
        tvLogTitle = text("", 12f, pal.muted)
        sesBox.addView(tvLogTitle, lpMW(bottom = dp(6)))
        tvLogBody = mono("")
        sesBox.addView(tvLogBody, lpMW())
        cl.addView(sesBox, lpMW())
        vLog.addView(cl)
        box.addView(vLog, lpMW())

        // Arsip
        vArc = vbox()
        vArc.visibility = View.GONE
        val ra = hbox()
        ra.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        ra.addView(chip("Hapus semua arsip") {
            doDel("Hapus semua arsip? Sesi terakhir tetap ada.") { RunnerService.clearArchive() }
        })
        vArc.addView(ra, lpMW(bottom = dp(10)))
        arcBox = vbox()
        arcBox.addView(emptyArc())
        vArc.addView(arcBox, lpMW())
        box.addView(vArc, lpMW())

        return sv
    }

    private fun emptyArc(): View {
        val v = vbox()
        v.gravity = Gravity.CENTER_HORIZONTAL
        v.setPadding(0, dp(16), 0, dp(16))
        v.addView(EmptyArt(this, pal), LinearLayout.LayoutParams(dp(160), dp(150)))
        v.addView(text("Belum ada arsip", 13f, pal.muted), lpWW(top = dp(4)))
        return v
    }

    private fun setSub(n: Int) {
        subBar.animateTo(n)
        vLog.visibility = if (n == 0) View.VISIBLE else View.GONE
        vArc.visibility = if (n == 1) View.VISIBLE else View.GONE
    }

    private fun parseSessions(lines: List<String>): List<Ses> {
        val out = ArrayList<Ses>()
        var cur: Ses? = null
        for (l in lines) {
            if (l.contains(RunnerService.MARK)) {
                val s = Ses(l)
                out.add(s)
                cur = s
            } else {
                var c = cur
                if (c == null) {
                    c = Ses("")
                    out.add(c)
                    cur = c
                }
                c.rows.add(l)
            }
        }
        return out
    }

    private fun dateOf(head: String): String? {
        val m = rxDate.find(head) ?: return null
        val g = m.groupValues
        val mi = (g[2].toIntOrNull() ?: 0) - 1
        if (mi < 0 || mi >= mon.size) return null
        return "${g[3].toInt()} ${mon[mi]} ${g[1]}, ${g[4]}:${g[5]}"
    }

    private fun timeOf(head: String): String = rxTime.find(head)?.value ?: ""

    private fun whenOf(s: Ses): String {
        val t = timeOf(s.head)
        return dateOf(s.head) ?: ("tanggal tidak tercatat" + (if (t.isEmpty()) "" else " ($t)"))
    }

    private fun countApk(rows: List<String>): Int = rows.count { rxApk.containsMatchIn(it) }

    private fun countSrv(rows: List<String>): Int = rows.count { rxSrv.containsMatchIn(it) }

    private fun renderLog(lines: List<String>) {
        if (lines.isEmpty()) {
            if (lastLogKey == "kosong") return
            lastLogKey = "kosong"
            lastSes = null
            tvLogEmpty.visibility = View.VISIBLE
            sesBox.visibility = View.GONE
            arcBox.removeAllViews()
            arcBox.addView(emptyArc())
            return
        }
        val key = "${lines.size}|${lines[0]}|${lines[lines.size - 1]}"
        if (key == lastLogKey) return
        lastLogKey = key

        val ses = parseSessions(lines)
        val n = ses.size
        val last = ses[n - 1]
        lastSes = last
        lastSesNo = n
        tvLogTitle.text = "Sesi $n \u00B7 ${whenOf(last)}"
        tvLogBody.text = last.rows.asReversed().joinToString("\n").ifEmpty { "(kosong)" }
        tvLogEmpty.visibility = View.GONE
        sesBox.visibility = View.VISIBLE

        arcBox.removeAllViews()
        for (i in n - 2 downTo 0) arcBox.addView(arcItem(i, ses[i]))
        if (n < 2) arcBox.addView(emptyArc())
    }

    private fun arcItem(i: Int, s: Ses): View {
        val item = card()

        val hd = hbox()
        hd.isClickable = true
        val tc = vbox()
        tc.addView(text("Sesi ${i + 1}", 14f, pal.text, true))
        tc.addView(text(whenOf(s), 12f, pal.muted), lpMW(top = dp(2)))
        tc.addView(
            text("${countApk(s.rows)} apk dibuka \u00B7 ${countSrv(s.rows)} server didapat", 12f, pal.muted),
            lpMW(top = dp(2))
        )
        hd.addView(tc, lpWeight())
        hd.addView(chip("Unduh") { downloadSession(i + 1, s) }, lpWW(left = dp(6)))
        hd.addView(chip("Hapus") {
            doDel("Hapus Sesi ${i + 1} dari arsip?") { RunnerService.deleteSession(i) }
        }, lpWW(left = dp(6)))
        item.addView(hd, lpMW())

        val bd = mono(s.rows.asReversed().joinToString("\n").ifEmpty { "(kosong)" })
        bd.visibility = if (openArc.contains(i)) View.VISIBLE else View.GONE
        item.addView(bd, lpMW(top = dp(10)))

        hd.setOnClickListener {
            val o = bd.visibility != View.VISIBLE
            bd.visibility = if (o) View.VISIBLE else View.GONE
            if (o) openArc.add(i) else openArc.remove(i)
        }
        return item
    }

    // Simpan satu sesi ke folder Download sebagai "Sesi N.txt"
    private fun downloadSession(n: Int, s: Ses) {
        val name = "Sesi $n.txt"
        val sb = StringBuilder()
        sb.append("Project ats - Sesi ").append(n).append('\n')
        sb.append(whenOf(s)).append('\n')
        sb.append("${countApk(s.rows)} apk dibuka, ${countSrv(s.rows)} server didapat").append("\n\n")
        if (s.head.isNotEmpty()) sb.append(s.head).append('\n')
        s.rows.forEach { sb.append(it).append('\n') }
        val bytes = sb.toString().toByteArray(Charsets.UTF_8)

        Thread {
            val msg = try {
                val cr = contentResolver
                val cv = ContentValues()
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name)
                cv.put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                cv.put(MediaStore.Downloads.IS_PENDING, 1)
                val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("tidak bisa membuat file")
                val out = cr.openOutputStream(uri) ?: throw IllegalStateException("tidak bisa menulis file")
                out.use { it.write(bytes) }
                val done = ContentValues()
                done.put(MediaStore.Downloads.IS_PENDING, 0)
                cr.update(uri, done, null, null)
                // Nama sebenarnya (sistem menambah " (1)" kalau nama sudah ada)
                var real = name
                cr.query(uri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) real = c.getString(0) ?: name
                }
                "Tersimpan di Download/$real"
            } catch (e: Throwable) {
                "Gagal menyimpan: ${e.message ?: e.javaClass.simpleName}"
            }
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun doDel(msg: String, fn: () -> Boolean) {
        if (isFinishing) return
        AlertDialog.Builder(this, dialogTheme())
            .setMessage(msg)
            .setPositiveButton("Ya") { _, _ ->
                val ok = try {
                    fn()
                } catch (e: Throwable) {
                    true
                }
                if (!ok) {
                    alert("Tidak bisa dihapus saat sedang berjalan. Hentikan dulu.")
                } else {
                    lastLogKey = ""
                    openArc.clear()
                    poll()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Halaman Setelan ----------

    private fun sectionLabel(s: String): TextView {
        val t = text(s, 12f, pal.muted, true)
        t.layoutParams = lpMW(top = dp(14), bottom = dp(6)).also { it.leftMargin = dp(6) }
        return t
    }

    // Kartu kelompok; baris dipisah garis tipis
    private fun group(vararg rows: View): LinearLayout {
        val c = vbox()
        c.background = rounded(pal.card, 22f, pal.border)
        c.setPadding(dp(16), dp(4), dp(16), dp(4))
        rows.forEachIndexed { i, r ->
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(pal.border)
                c.addView(line, LinearLayout.LayoutParams(MATCH, 1))
            }
            c.addView(r, lpMW())
        }
        return c
    }

    // Baris angka: label kiri, kolom ms kanan
    private fun numRow(label: String, e: EditText): View {
        val h = hbox()
        h.setPadding(0, dp(10), 0, dp(10))
        h.addView(text(label, 14f, pal.text), lpWeight())
        e.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        e.typeface = Typeface.MONOSPACE
        h.addView(e, LinearLayout.LayoutParams(dp(112), WRAP))
        h.addView(text("ms", 12f, pal.muted), lpWW(left = dp(8)))
        return h
    }

    // Baris dengan tulisan status di kanan; seluruh baris bisa diketuk
    private fun valueRow(label: String, value: TextView, onClick: () -> Unit): View {
        val h = hbox()
        h.setPadding(0, dp(12), 0, dp(12))
        h.addView(text(label, 14f, pal.text), lpWeight())
        h.addView(value)
        h.addView(text("\u203A", 18f, pal.muted), lpWW(left = dp(8)))
        h.isClickable = true
        h.setOnClickListener { onClick() }
        return h
    }

    private fun updateSecureRow() {
        if (!::tvSecure.isInitialized) return
        val ok = SecureA11y.granted(this)
        val st = if (ok) 1 else 0
        if (st == secureShown) return
        secureShown = st
        tvSecure.text = if (ok) "Siap" else "Perlu izin"
        tvSecure.setTextColor(if (ok) pal.text else pal.danger)
    }

    private fun copyText(label: String, value: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText(label, value))
            toast("Disalin")
        } catch (e: Throwable) {
            toast("Gagal menyalin")
        }
    }

    // Dialog "Nyala otomatis": status izin, perintah yang bisa disalin, dan tombol beri izin lewat Shizuku
    private fun showSecureDialog() {
        if (isFinishing) return
        val cmd = SecureA11y.grantCommand(this)
        val ok = SecureA11y.granted(this)
        val msg = if (ok) {
            "Izin sudah ada. Aksesibilitas dinyalakan sendiri tiap aplikasi dibuka dan sebelum Mulai.\n\n" +
                "Perintah (kalau perlu diulang, misalnya setelah uninstall):\n$cmd"
        } else {
            "Izin ini diberikan SATU KALI. Pilih salah satu cara:\n\n" +
                "1. Tombol \"Beri izin lewat Shizuku\" di bawah (Shizuku harus sedang jalan).\n\n" +
                "2. Salin perintah ini lalu jalankan di aShell You atau LADB:\n$cmd\n\n" +
                "Kalau muncul SecurityException, nyalakan \"USB debugging (pengaturan keamanan)\" " +
                "atau \"Nonaktifkan pemantauan izin\" di Opsi pengembang, lalu ulangi."
        }
        val b = AlertDialog.Builder(this, dialogTheme())
            .setTitle("Nyala otomatis")
            .setMessage(msg)
            .setPositiveButton("Salin perintah") { _, _ -> copyText("perintah", cmd) }
            .setNegativeButton("Tutup", null)
        if (!ok) b.setNeutralButton("Beri izin lewat Shizuku") { _, _ -> grantViaShizuku() }
        b.show()
    }

    // Satu-satunya pemakaian Shizuku di fitur ini: menjalankan pm grant sekali
    private fun grantViaShizuku() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Shizuku belum jalan atau belum diizinkan")
            return
        }
        toast("Memberi izin...")
        Thread {
            val r = try {
                ShizukuHelper.exec(arrayOf("pm", "grant", packageName, SecureA11y.PERM), 8000L)
            } catch (e: Throwable) {
                Pair(false, e.javaClass.simpleName)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (r.first && SecureA11y.granted(this)) {
                    toast("Izin diberikan. Aksesibilitas dinyalakan.")
                    autoEnableA11y()
                    secureShown = -1
                    updateSecureRow()
                } else {
                    alert("Gagal memberi izin: ${r.second.take(160)}\n\nCoba nyalakan \"USB debugging (pengaturan keamanan)\" atau \"Nonaktifkan pemantauan izin\" di Opsi pengembang, lalu ulangi.")
                }
            }
        }.start()
    }

    private fun switchRow(label: String, s: Switch): View {
        val h = hbox()
        h.setPadding(0, dp(10), 0, dp(10))
        h.addView(text(label, 14f, pal.text), lpWeight())
        h.addView(s)
        h.setOnClickListener { s.toggle() }
        return h
    }

    private fun stackRow(label: String, e: EditText): View {
        val v = vbox()
        v.setPadding(0, dp(10), 0, dp(10))
        v.addView(text(label, 14f, pal.text), lpMW(bottom = dp(8)))
        v.addView(e, lpMW())
        return v
    }

    private fun actionRow(b: TextView, res: TextView): View {
        val v = vbox()
        v.setPadding(0, dp(10), 0, dp(10))
        v.addView(b, lpWW())
        res.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        res.setTextColor(pal.muted)
        v.addView(res, lpMW(top = dp(6)))
        return v
    }

    private fun permRow(d: View, label: String, onClick: () -> Unit): View {
        val h = hbox()
        h.setPadding(0, dp(10), 0, dp(10))
        h.addView(d)
        h.addView(text(label, 14f, pal.text), lpWeight(left = dp(10)))
        h.addView(chip("Atur") { onClick() })
        return h
    }

    private fun buildPageSetelan(): View {
        val (sv, box) = scrollPage()

        val top = hbox()
        top.addView(text("Setelan", 18f, pal.text, true), lpWeight(left = dp(4)))
        val menu = roundIcon("\u22EE") { openSheet() }
        menu.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        top.addView(menu, LinearLayout.LayoutParams(dp(38), dp(38)))
        box.addView(top, lpMW(bottom = dp(2)))

        // Waktu
        etD1 = input(true)
        etD2 = input(true)
        etD3 = input(true)
        box.addView(sectionLabel("Waktu"))
        box.addView(group(
            numRow("Jeda putaran 1", etD1),
            numRow("Jeda putaran 2 (maks)", etD2),
            numRow("Jeda tengah", etD3)
        ))

        // Apk pertama
        swFirst = switchView()
        etFirstMax = input(true)
        etAfterTap = input(true)
        etLoginKeys = input(false, "Login kembali")
        bLogin = chip("Tes popup login", true) { doOcrTest("login") }
        tvLoginRes = TextView(this)
        box.addView(sectionLabel("Apk pertama"))
        box.addView(group(
            switchRow("Tunggu popup login", swFirst),
            numRow("Batas waktu", etFirstMax),
            numRow("Tunggu setelah ketuk", etAfterTap),
            stackRow("Teks tombol yang diketuk", etLoginKeys),
            actionRow(bLogin, tvLoginRes)
        ))

        // Ketukan Got it
        swTapOn = switchView()
        etTapMs = input(true)
        etTapX = input(true, "x")
        etTapY = input(true, "y")
        bTap = chip("Tes ketuk", true) { doTapTest() }
        tvTapRes = TextView(this)
        val xy = hbox()
        xy.setPadding(0, dp(10), 0, dp(10))
        xy.addView(text("Koordinat", 14f, pal.text), lpWeight())
        etTapX.gravity = Gravity.CENTER
        etTapY.gravity = Gravity.CENTER
        etTapX.typeface = Typeface.MONOSPACE
        etTapY.typeface = Typeface.MONOSPACE
        xy.addView(etTapX, LinearLayout.LayoutParams(dp(78), WRAP))
        xy.addView(etTapY, LinearLayout.LayoutParams(dp(78), WRAP).also { it.leftMargin = dp(8) })
        box.addView(sectionLabel("Ketukan Got it"))
        box.addView(group(
            switchRow("Ketuk otomatis", swTapOn),
            numRow("Waktu ketukan", etTapMs),
            xy,
            actionRow(bTap, tvTapRes)
        ))

        // Kaitkan otomatis
        tvStockRow = text("", 13f, pal.muted, true)
        box.addView(sectionLabel("Kaitkan otomatis"))
        box.addView(group(valueRow("Stok email", tvStockRow) { openStockPage() }))

        // Lainnya
        swAnim = switchView()
        box.addView(sectionLabel("Lainnya"))
        box.addView(group(
            switchRow("Matikan animasi sistem saat proses", swAnim)
        ))

        // Izin
        tvSecure = text("", 13f, pal.muted, true)
        secureShown = -1
        dOv = dot()
        dSz = dot()
        dA11y = dot()
        dBat = dot()
        box.addView(sectionLabel("Izin"))
        box.addView(group(
            permRow(dSz, "Shizuku") { ShizukuHelper.requestPermission() },
            permRow(dA11y, "Aksesibilitas") { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            permRow(dOv, "Tampil di atas aplikasi") {
                open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            },
            permRow(dBat, "Baterai tanpa batasan") { requestBattery() },
            valueRow("Nyala otomatis", tvSecure) { showSecureDialog() }
        ))

        listOf(etD1, etD2, etD3, etTapMs, etTapX, etTapY, etFirstMax, etAfterTap, etLoginKeys)
            .forEach { e -> watch(e) { saveSet() } }
        listOf(swAnim, swTapOn, swFirst).forEach { s ->
            s.setOnCheckedChangeListener { _, _ -> saveSet() }
        }
        return sv
    }

    // =====================================================================
    // Lembar bawah: menu titik tiga (penjelasan + tema)
    // =====================================================================

    private val helpItems = listOf(
        "Jeda putaran 1" to "Jatah waktu tiap aplikasi di putaran 1 untuk membaca server dari log. 1000 ms = 1 detik.",
        "Jeda putaran 2 (maks)" to "Batas maksimal menunggu layar Create Character. Kalau OCR aktif dan teksnya terbaca lebih cepat, langsung lanjut ke aplikasi berikutnya. Kalau OCR mati, jeda ini dipakai penuh.",
        "Jeda tengah" to "Waktu tetap untuk membersihkan aplikasi (force stop dan hapus dari recent) sebelum lanjut.",
        "Apk pertama" to "Aplikasi pertama di putaran 1 menunggu popup Info Sistem sampai batas waktu, sambil membaca servernya dari log. Kalau popup muncul, tombol diketuk dan ditunggu sesuai pengaturan Tunggu setelah ketuk (bawaan 1800 ms); selama itu servernya masih dibaca dari log. Server baru dicatat dan aplikasinya dibiarkan; server kembar atau tidak terbaca membuat aplikasinya dibersihkan. Kalau popup tidak muncul sampai batas waktu, aplikasi dibersihkan apa pun servernya. Aplikasi berikutnya memakai jeda putaran 1 biasa. Teks tombol bisa lebih dari satu, pisahkan dengan koma.",
        "Ketukan Got it" to "Mengetuk koordinat x, y satu kali di tiap aplikasi putaran 1, setelah waktu ketukan berlalu sejak aplikasi dibuka. Waktu ketukan harus lebih kecil dari jeda putaran 1. Layar mendatar 2400x1080; cek koordinat lewat Opsi pengembang > Lokasi penunjuk.",
        "Nickname otomatis" to "Di putaran 2, begitu halaman Create Character terbaca, kolom nama diketuk, nama acak dihapus, lalu nickname diketik sesuai urutan apk (misal Ats-1, Ats-2, dst). Setelah nama masuk ke kolom game, tombol Okay emas diketuk. Aplikasi baru pindah ke apk berikutnya kalau sudah masuk halaman Skip the Tutorial atau Select a hero. Di halaman Skip the Tutorial, tombol Skip diketuk dan aplikasi menunggu halaman Level Up muncul (batasnya sebesar jeda putaran 2) sebelum pindah. Tombol Continue tidak diketuk. Kalau masih macet di Create Character, langkahnya diulang sampai 3 kali. Popup Switch Account yang kadang muncul setelah loading ditutup otomatis dengan mengetuk tanda silang, dan waktu tunggu Create Character diperpanjang 10 detik karena popup itu berarti halamannya sudah dekat. Kalau apk tidak sampai Create Character, apk itu dilewati dan nomor berikutnya tetap sesuai urutan. Butuh Aksesibilitas dan Shizuku. Nickname dengan simbol khusus (misal •) diisi lewat clipboard lalu ditempel; pakai Tes isi nama dulu untuk memastikan game menerimanya. Tombol Tes isi nama mengisi kolom saja tanpa mengetuk Okay; jalankan di halaman Create Character.",
        "Tombol tes" to "Tes popup login, Tes ketuk, dan Tes isi nama menghitung mundur 5 detik. Buka game dalam waktu itu; hasilnya muncul di bawah tombol. Tes popup login tidak mengetuk, hanya menunjukkan posisi tombol.",
        "Kaitkan otomatis" to "Di akhir putaran 2, email dikaitkan ke akun Moonton di apk terakhir yang sampai halaman Level Up. Alurnya: Continue, Shop, Purchase, Use Battle Points, tutup dialog, kembali, Profil, Account, ikon hadiah, Connect Now, MOONTON Account, isi email, Kirim, sampai muncul Email verifikasi telah dikirim. Butuh Nickname otomatis yang nyala. Kalau saklarnya mati, alur berhenti di halaman Level Up. Email diambil dari kolom Email; kalau Stok email nyala, kolom terisi email paling atas dari stok. Kalau satu langkah macet, alur berhenti dan alasannya dicatat di log.",
        "Stok email" to "Daftar email yang dipakai bergantian, satu per sesi. Tombol plus menambah email (boleh tempel banyak sekaligus), ketuk satu baris untuk Edit atau Hapus. Email yang berhasil dipakai otomatis dihapus dari stok. Email yang kamu tulis sendiri di kolom Kaitkan otomatis tidak mengubah stok. Saklar di pojok kanan atas halaman stok: mati berarti stok tidak dipakai.",
        "Catatan umum" to "Di tab Aktivitas: baris pertama email yang berhasil dikaitkan, baris kedua ID akun (dibaca dari tulisan Role di layar loading, atau dari halaman Profil), lalu daftar server. Satu sesi menghasilkan satu akun, jadi ID dan email hanya satu.",
        "Animasi sistem" to "Selama sesi berjalan, tiga skala animasi di Opsi pengembang (animasi jendela, transisi, dan durasi animator) dimatikan lewat Shizuku supaya proses lebih cepat dan HP tidak kaku di luar sesi. Setelah sesi selesai atau dihentikan, ketiganya dikembalikan ke 1x. Kalau sesi terputus di tengah jalan, animasi dikembalikan otomatis saat aplikasi dibuka lagi.",
        "Nyala otomatis" to "Android mematikan layanan Aksesibilitas saat aplikasi di-force stop, crash, atau diperbarui. Kalau izin WRITE_SECURE_SETTINGS sudah diberikan (satu kali), aplikasi menyalakannya lagi sendiri tiap dibuka dan sebelum Mulai berjalan; Mulai menunggu tersambung maksimal 5 detik. Baris Nyala otomatis di Izin menunjukkan Siap atau Perlu izin; ketuk untuk menyalin perintah pm grant atau memberi izin lewat Shizuku. Izin hilang kalau aplikasi di-uninstall.",
        "Izin" to "Shizuku dipakai untuk membaca log, force stop, dan membersihkan recent, dan hanya berlaku untuk aplikasi yang kamu centang. Aksesibilitas untuk screenshot dan ketukan. Tampil di atas aplikasi untuk kapsul status. Baterai tanpa batasan supaya sesi tidak dihentikan sistem. Setelah memasang pembaruan APK, matikan lalu nyalakan lagi Aksesibilitas. Izin selain Shizuku (notifikasi, tampil di atas aplikasi, baterai, dan izin untuk Nyala otomatis) diberikan otomatis lewat Shizuku kalau masih kurang, jadi tidak perlu diatur manual. Tombol Atur tetap ada sebagai cadangan. Shizuku sendiri harus diizinkan manual.",
        "Tanda status" to "Titik di pojok kanan atas menyala kalau Shizuku, Aksesibilitas, dan Overlay sudah aktif. Merah artinya ada izin yang belum aktif; ketuk untuk melihat yang mana. Saat sesi berjalan, titiknya berkedip pelan."
    )

    private fun buildSheet() {
        dim = View(this)
        dim.setBackgroundColor(pal.dim)
        dim.alpha = 0f
        dim.visibility = View.GONE
        dim.setOnClickListener { closeSheet() }
        root.addView(dim, FrameLayout.LayoutParams(MATCH, MATCH))

        sheet = vbox()
        val bg = GradientDrawable()
        bg.setColor(pal.card)
        val r = dp(26).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setStroke(maxOf(1, dp(0.6f)), pal.border)
        sheet.background = bg
        sheet.setPadding(dp(20), dp(10), dp(20), dp(28))
        sheet.isClickable = true
        sheet.elevation = dp(12).toFloat()
        sheet.visibility = View.GONE

        val handle = View(this)
        handle.background = rounded(pal.borderStrong, 999f)
        sheet.addView(handle, LinearLayout.LayoutParams(dp(36), dp(4)).also {
            it.gravity = Gravity.CENTER_HORIZONTAL
            it.bottomMargin = dp(14)
        })

        // Menu utama
        sheetMenu = vbox()
        val rHelp = hbox()
        rHelp.setPadding(0, dp(14), 0, dp(14))
        rHelp.isClickable = true
        rHelp.background = pressable(rounded(Color.TRANSPARENT, 12f))
        rHelp.addView(text("Penjelasan pengaturan", 15f, pal.text), lpWeight())
        rHelp.addView(text("\u203A", 20f, pal.muted))
        rHelp.setOnClickListener { showSheetHelp() }
        sheetMenu.addView(rHelp, lpMW())
        val line = View(this)
        line.setBackgroundColor(pal.border)
        sheetMenu.addView(line, LinearLayout.LayoutParams(MATCH, 1))

        val rTheme = hbox()
        rTheme.setPadding(0, dp(12), 0, dp(12))
        rTheme.addView(text("Tema", 15f, pal.text), lpWeight())
        var segRef: TabBar? = null
        val seg = TabBar(this, pal, arrayOf("Gelap", "Terang"), 13f) { i ->
            segRef?.animateTo(i)
            setTheme(i == 0)
        }
        segRef = seg
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        seg.background = rounded(pal.bg, 999f, pal.border)
        seg.pos = if (pal.dark) 0f else 1f
        rTheme.addView(seg, LinearLayout.LayoutParams(dp(170), WRAP))
        sheetMenu.addView(rTheme, lpMW())
        sheet.addView(sheetMenu, lpMW())

        // Penjelasan
        sheetHelp = vbox()
        sheetHelp.visibility = View.GONE
        val back = text("\u2039  Kembali", 14f, pal.text, true)
        back.setPadding(0, dp(6), 0, dp(10))
        back.setOnClickListener { showSheetMenu() }
        sheetHelp.addView(back, lpMW())
        helpScroll = ScrollView(this)
        helpScroll.isVerticalScrollBarEnabled = false
        val hb = vbox()
        helpItems.forEach { (t, b) ->
            hb.addView(text(t, 14f, pal.text, true), lpMW(top = dp(8)))
            val bt = text(b, 13f, pal.muted)
            bt.setLineSpacing(0f, 1.3f)
            hb.addView(bt, lpMW(top = dp(3), bottom = dp(6)))
        }
        helpScroll.addView(hb, FrameLayout.LayoutParams(MATCH, WRAP))
        sheetHelp.addView(helpScroll, LinearLayout.LayoutParams(MATCH, dp(360)))
        sheet.addView(sheetHelp, lpMW())

        root.addView(sheet, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
    }

    private fun openSheet() {
        if (sheetOpen) return
        hideKeyboard()
        sheetOpen = true
        showSheetMenu()
        dim.visibility = View.VISIBLE
        sheet.visibility = View.VISIBLE
        dim.animate().alpha(1f).setDuration(300).start()
        sheet.post {
            sheet.translationY = sheet.height.toFloat()
            sheet.animate().translationY(0f).setDuration(450).setInterpolator(IOS_EASE).start()
        }
    }

    private fun closeSheet(after: (() -> Unit)? = null) {
        if (!sheetOpen) {
            after?.invoke()
            return
        }
        sheetOpen = false
        dim.animate().alpha(0f).setDuration(250).withEndAction { dim.visibility = View.GONE }.start()
        sheet.animate().translationY(sheet.height.toFloat()).setDuration(350).setInterpolator(IOS_EASE)
            .withEndAction {
                sheet.visibility = View.GONE
                after?.invoke()
            }.start()
    }

    private fun showSheetMenu() {
        sheetMenu.visibility = View.VISIBLE
        sheetHelp.visibility = View.GONE
    }

    private fun showSheetHelp() {
        val h = (root.height * 0.6f).toInt()
        val lp = helpScroll.layoutParams
        if (h > 0 && lp.height != h) {
            lp.height = h
            helpScroll.layoutParams = lp
        }
        helpScroll.scrollTo(0, 0)
        sheetMenu.visibility = View.GONE
        sheetHelp.visibility = View.VISIBLE
    }

    private fun setTheme(dark: Boolean) {
        if (dark == pal.dark) return
        prefs.edit().putString("theme", if (dark) "dark" else "light").apply()
        // Tunggu pil meluncur dulu, tutup lembar, lalu pasang tema baru
        main.postDelayed({
            if (!isFinishing && !isDestroyed) closeSheet { applyTheme(dark) }
        }, 260)
    }

    // =====================================================================
    // Setelan tersimpan
    // =====================================================================

    private fun loadSettings() {
        loadingUi = true
        etD1.setText(prefs.getString("d1", "5700"))
        etD2.setText(prefs.getString("d2", "25000"))
        etD3.setText((prefs.getString("d3", "") ?: "").ifEmpty { "600" })
        etTarget.setText(prefs.getString("target", "0"))
        etQf.setText(prefs.getString("qf", ""))
        swAnim.isChecked = prefs.getBoolean("animOff", true)
        swTapOn.isChecked = prefs.getBoolean("tapOn", false)
        etTapMs.setText((prefs.getString("tapMs", "") ?: "").ifEmpty { "4900" })
        etTapX.setText((prefs.getString("tapX", "") ?: "").ifEmpty { "1200" })
        etTapY.setText((prefs.getString("tapY", "") ?: "").ifEmpty { "960" })
        swFirst.isChecked = prefs.getBoolean("firstOn", true)
        etFirstMax.setText((prefs.getString("firstMax", "") ?: "").ifEmpty { "10000" })
        etAfterTap.setText((prefs.getString("afterTap", "") ?: "").ifEmpty { "1800" })
        etLoginKeys.setText((prefs.getString("loginKeys", "") ?: "").ifEmpty { "Login kembali" })
        swNick.isChecked = prefs.getBoolean("nickOn", true)
        swKaitkan.isChecked = EmailStock.kaitkanOn(this)
        etKaitkan.setText(EmailStock.field(this))
        etNick.setText(prefs.getString("nickBase", "Ats-"))
        etNickStart.setText((prefs.getString("nickStart", "") ?: "").ifEmpty { "1" })
        sel.clear()
        sel.addAll(prefs.getStringSet("sel", null) ?: emptySet())
        loadingUi = false
        updateSelCount()
    }

    private fun saveSet() {
        if (loadingUi) return
        prefs.edit()
            .putString("d1", etD1.text.toString())
            .putString("d2", etD2.text.toString())
            .putString("d3", etD3.text.toString())
            .putString("target", etTarget.text.toString())
            .putString("qf", etQf.text.toString())
            .putBoolean("animOff", swAnim.isChecked)
            .putBoolean("tapOn", swTapOn.isChecked)
            .putString("tapMs", etTapMs.text.toString())
            .putString("tapX", etTapX.text.toString())
            .putString("tapY", etTapY.text.toString())
            .putBoolean("firstOn", swFirst.isChecked)
            .putString("firstMax", etFirstMax.text.toString())
            .putString("afterTap", etAfterTap.text.toString())
            .putString("loginKeys", etLoginKeys.text.toString())
            .putBoolean("nickOn", swNick.isChecked)
            .putString("nickBase", etNick.text.toString())
            .putString("nickStart", etNickStart.text.toString())
            .apply()
        updateSelCount()
    }

    private fun saveSel() {
        prefs.edit().putStringSet("sel", HashSet(sel)).apply()
        updateSelCount()
    }

    private fun updateSelCount() {
        val n = if (appsLoaded) apps.count { sel.contains(it.pkg) } else sel.size
        if (::tvCount.isInitialized) tvCount.text = "$n dipilih"
        if (::tvSel.isInitialized) tvSel.text = "0 = tanpa target \u00B7 $n aplikasi dipilih"
        updateNickWarn()
    }

    // Alasan kenapa Nickname otomatis tidak bisa jalan (null = aman)
    private fun nickProblem(): String? {
        if (!swNick.isChecked) return null
        val base = etNick.text.toString()
        val start = etNickStart.text.toString().toIntOrNull() ?: 1
        val selected = if (appsLoaded) apps.count { sel.contains(it.pkg) } else sel.size
        val target = etTarget.text.toString().toIntOrNull() ?: 0
        val count = maxOf(1, if (target > 0) target else selected)
        val first = base + start
        val last = base + (start + count - 1)
        fun len(s: String): Int = s.codePointCount(0, s.length)
        if (len(first) < 4) return "Nama '$first' hanya ${len(first)} karakter. Game butuh 4-20 karakter."
        if (len(last) > 20) return "Nama terpanjang '$last' ada ${len(last)} karakter. Game butuh 4-20 karakter."
        if (!ShizukuHelper.hasPermission()) return "Shizuku belum diizinkan."
        if (!OcrA11yService.isRunning()) return "Aksesibilitas belum aktif."
        return null
    }

    private fun updateNickWarn() {
        if (!::tvNickWarn.isInitialized || !::swAnim.isInitialized) return
        val msg = nickProblem()
        setIfChanged(tvNickWarn, msg ?: "")
        val v = if (msg == null) View.GONE else View.VISIBLE
        if (tvNickWarn.visibility != v) tvNickWarn.visibility = v
    }

    // =====================================================================
    // Izin dan status
    // =====================================================================

    private fun batteryUnrestricted(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Throwable) {
        false
    }

    // Selalu tampilkan dialog permintaan ("Izinkan aplikasi selalu berjalan di latar belakang?").
    // Halaman pengaturan hanya dipakai kalau dialog tidak bisa dibuka.
    private fun requestBattery() {
        val was = batteryUnrestricted()
        try {
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            if (was) toast("Sudah diizinkan")
        } catch (e: Exception) {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun missingPerms(): List<String> {
        val m = ArrayList<String>()
        if (!ShizukuHelper.hasPermission()) m.add("Shizuku")
        if (!OcrA11yService.isRunning()) m.add("Aksesibilitas")
        if (!Settings.canDrawOverlays(this)) m.add("Tampil di atas aplikasi")
        return m
    }

    private fun explainStatus() {
        if (RunnerService.running) {
            alert("Sesi sedang berjalan.")
            return
        }
        val m = missingPerms()
        val bat = if (batteryUnrestricted()) "" else
            "\n\nDisarankan juga: atur baterai ke Tanpa batasan."
        if (m.isEmpty()) {
            alert("Semua izin utama sudah aktif. Siap dijalankan.$bat")
        } else {
            AlertDialog.Builder(this, dialogTheme())
                .setMessage("Izin yang belum aktif:\n\u2022 " + m.joinToString("\n\u2022 ") + bat)
                .setPositiveButton("Buka Setelan") { _, _ -> showTab(3) }
                .setNegativeButton("Tutup", null)
                .show()
        }
    }

    // 0 = belum siap, 1 = siap, 2 = berjalan
    private fun setStatus(state: Int) {
        if (state == statusState) return
        statusState = state
        pulse?.cancel()
        hdDot.alpha = 1f
        when (state) {
            2 -> {
                setDotColor(hdDot, pal.dotOn)
                hdTxt.text = "Berjalan"
                pulse = ObjectAnimator.ofFloat(hdDot, View.ALPHA, 1f, 0.25f).apply {
                    duration = 900
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    start()
                }
            }
            1 -> {
                setDotColor(hdDot, pal.dotOn)
                hdTxt.text = "Siap"
            }
            else -> {
                setDotColor(hdDot, pal.danger)
                hdTxt.text = "Belum siap"
            }
        }
    }

    // =====================================================================
    // Aksi
    // =====================================================================

    private fun doStart() {
        hideKeyboard()
        if (!appsLoaded) {
            alert("Daftar aplikasi masih dimuat, tunggu sebentar.")
            return
        }
        val p = apps.filter { sel.contains(it.pkg) }.map { it.pkg }
        if (p.isEmpty()) {
            alert("Centang aplikasi dulu di tab Apps.")
            return
        }
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.putExtra("pkgs", p.toTypedArray())
        i.putExtra("d1", etD1.text.toString().toLongOrNull() ?: 5700L)
        i.putExtra("d2", etD2.text.toString().toLongOrNull() ?: 25000L)
        i.putExtra("d3", etD3.text.toString().toLongOrNull() ?: 600L)
        i.putExtra("target", etTarget.text.toString().toIntOrNull() ?: 0)
        i.putExtra("animOff", swAnim.isChecked)
        i.putExtra("tapOn", swTapOn.isChecked)
        i.putExtra("tapMs", etTapMs.text.toString().toLongOrNull() ?: 4900L)
        i.putExtra("tapX", etTapX.text.toString().toIntOrNull() ?: 1200)
        i.putExtra("tapY", etTapY.text.toString().toIntOrNull() ?: 960)
        i.putExtra("firstOn", swFirst.isChecked)
        i.putExtra("firstMax", etFirstMax.text.toString().toLongOrNull() ?: 10000L)
        i.putExtra("afterTap", etAfterTap.text.toString().toLongOrNull() ?: 1800L)
        i.putExtra("loginKeys", etLoginKeys.text.toString())
        i.putExtra("nickOn", swNick.isChecked)
        i.putExtra("nickBase", etNick.text.toString())
        i.putExtra("nickStart", etNickStart.text.toString().toIntOrNull() ?: 1)
        i.putExtra("kaitkanOn", EmailStock.kaitkanOn(this))
        i.putExtra("kaitkanEmail", EmailStock.effective(this))

        // Aksesibilitas mati? Nyalakan otomatis dulu (Jalur A), tunggu tersambung maksimal 5 detik.
        // Kalau belum tersambung, proses tetap dimulai (tidak diblokir).
        // Izin yang masih kurang juga diberikan otomatis lewat Shizuku sebelum mulai.
        val needPerms = AutoPerms.hasMissing(this) && ShizukuHelper.hasPermission()
        if (needPerms || (!OcrA11yService.isRunning() && SecureA11y.granted(this))) {
            toast(if (needPerms) "Menyiapkan izin..." else "Menyalakan Aksesibilitas...")
            Thread {
                try {
                    if (needPerms) AutoPerms.run(this)
                    if (!OcrA11yService.isRunning() && SecureA11y.granted(this)) {
                        SecureA11y.ensureAndWait(this, 5000L) { }
                    }
                } catch (e: Throwable) {
                }
                runOnUiThread { if (!isFinishing && !isDestroyed) launchService(i) }
            }.start()
            return
        }
        launchService(i)
    }

    private fun launchService(i: Intent) {
        try {
            startForegroundService(i)
        } catch (e: Exception) {
            alert("Gagal memulai: " + e.javaClass.simpleName)
        }
        main.postDelayed({ poll() }, 150)
    }

    // Tugas otomatis ringan, dicek tiap penyegaran status:
    // (1) nyalakan Aksesibilitas kalau mati, (2) kembalikan animasi sistem kalau sesi sebelumnya terputus
    private var lastAnimTry = 0L
    private var animBusy = false

    private var lastPermTry = 0L
    private var permTries = 0
    private var permBusy = false

    private fun autoTasks() {
        val now = SystemClock.uptimeMillis()

        // Izin yang kurang diberikan otomatis lewat Shizuku (maksimal 4 kali, jarak 8 detik)
        if (!AutoPerms.hasMissing(this)) {
            permTries = 0
        } else if (!permBusy && !RunnerService.running && permTries < 4 &&
            now - lastPermTry > 8000L && ShizukuHelper.hasPermission()
        ) {
            permBusy = true
            permTries++
            lastPermTry = now
            Thread {
                try {
                    AutoPerms.run(this)
                } catch (e: Throwable) {
                } finally {
                    permBusy = false
                }
            }.start()
        }

        if (!RunnerService.running && !animBusy && AnimScale.isPending(this) &&
            now - lastAnimTry > 8000L && ShizukuHelper.hasPermission()
        ) {
            animBusy = true
            lastAnimTry = now
            Thread {
                try {
                    AnimScale.restore(this) { }
                } catch (e: Throwable) {
                } finally {
                    animBusy = false
                }
            }.start()
        }
    }

    private fun doStop() {
        val i = Intent(this, RunnerService::class.java)
        i.action = "STOP"
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    private fun doTapTest() {
        hideKeyboard()
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.action = "TAP_TEST"
        i.putExtra("tapX", etTapX.text.toString().toIntOrNull() ?: 1200)
        i.putExtra("tapY", etTapY.text.toString().toIntOrNull() ?: 960)
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    private fun doOcrTest(which: String) {
        hideKeyboard()
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.action = "OCR_TEST"
        i.putExtra("which", which)
        i.putExtra("loginKeys", etLoginKeys.text.toString())
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Kaitkan otomatis dan Stok email
    // =====================================================================

    private fun buildKaitkanCard(): View {
        val c = card()
        val top = hbox()
        top.addView(text("Kaitkan otomatis", 14f, pal.text, true), lpWeight())
        swKaitkan = switchView()
        top.addView(swKaitkan)
        c.addView(top, lpMW(bottom = dp(10)))

        c.addView(text("Email", 12f, pal.muted), lpMW(bottom = dp(4)))
        etKaitkan = input(false, "nama@email.com")
        etKaitkan.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        c.addView(etKaitkan)

        tvKaitkanWarn = text("", 12f, pal.danger)
        tvKaitkanWarn.visibility = View.GONE
        c.addView(tvKaitkanWarn, lpMW(top = dp(6)))
        return c
    }

    // Segarkan kolom email (ikut stok), keterangan, dan peringatan
    private fun updateKaitkan() {
        if (!::etKaitkan.isInitialized || !::swNick.isInitialized) return
        val f = EmailStock.field(this)
        if (!etKaitkan.hasFocus() && etKaitkan.text.toString() != f) {
            kaitkanSyncing = true
            etKaitkan.setText(f)
            kaitkanSyncing = false
        }
        val on = EmailStock.stockOn(this)
        val eff = EmailStock.effective(this)
        var w = ""
        if (swKaitkan.isChecked) {
            w = if (!swNick.isChecked) {
                "Butuh Nickname otomatis yang nyala."
            } else if (eff.isEmpty()) {
                if (on) "Stok email habis dan kolom kosong: fitur akan dilewati." else "Kolom email kosong: fitur akan dilewati."
            } else if (eff.indexOf('@') < 1) {
                "Email tidak valid."
            } else {
                ""
            }
        }
        setIfChanged(tvKaitkanWarn, w)
        val v = if (w.isEmpty()) View.GONE else View.VISIBLE
        if (tvKaitkanWarn.visibility != v) tvKaitkanWarn.visibility = v
    }

    private fun updateStockRowValue() {
        if (!::tvStockRow.isInitialized) return
        val n = EmailStock.stock(this).size
        setIfChanged(tvStockRow, (if (EmailStock.stockOn(this)) "Nyala" else "Mati") + " \u00B7 $n email")
    }

    private fun buildStockPage(): FrameLayout {
        stockOpen = false
        val pg = FrameLayout(this)
        pg.setBackgroundColor(pal.bg)
        pg.isClickable = true
        pg.visibility = View.GONE
        pg.addView(HeaderDecor(this, pal), FrameLayout.LayoutParams(MATCH, dp(DECOR_H)))

        val col = vbox()
        pg.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val h = hbox()
        h.setPadding(dp(16), dp(18), dp(16), dp(6))
        val back = roundIcon("\u2039") { closeStockPage() }
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        h.addView(back, LinearLayout.LayoutParams(dp(38), dp(38)))
        h.addView(text("Stok email", 17f, pal.text, true), lpWeight(left = dp(12)))
        swStock = switchView()
        swStock.setOnCheckedChangeListener { _, on ->
            if (!stockSyncing) {
                EmailStock.setStockOn(this, on)
                stockRefresh()
            }
        }
        h.addView(swStock)
        col.addView(h, LinearLayout.LayoutParams(MATCH, WRAP))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val inner = vbox()
        inner.setPadding(dp(16), dp(PAGE_TOP - 20), dp(16), dp(110))
        inner.addView(
            text("Email paling atas dipakai lebih dulu.", 12f, pal.muted),
            lpMW(bottom = dp(10)).also { it.leftMargin = dp(4) }
        )
        val lc = vbox()
        lc.background = rounded(pal.card, 22f, pal.border)
        lc.setPadding(0, dp(6), 0, dp(6))
        stockRows = vbox()
        lc.addView(stockRows, lpMW())
        inner.addView(lc, lpMW())
        tvStockCount = text("", 12f, pal.muted)
        inner.addView(tvStockCount, lpMW(top = dp(10)).also { it.leftMargin = dp(6) })
        sv.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val fab = TextView(this)
        fab.text = "+"
        fab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        fab.setTextColor(pal.onPrimary)
        fab.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(pal.primary)
        fab.background = pressable(g)
        fab.elevation = dp(4).toFloat()
        fab.isClickable = true
        fab.setOnClickListener { showAddDialog() }
        val flp = FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END)
        flp.setMargins(0, 0, dp(20), dp(24))
        pg.addView(fab, flp)
        return pg
    }

    private fun stockRefresh() {
        if (!::stockRows.isInitialized) return
        val list = EmailStock.stock(this)
        stockVer = EmailStock.version
        stockSyncing = true
        swStock.isChecked = EmailStock.stockOn(this)
        stockSyncing = false
        stockRows.removeAllViews()
        if (list.isEmpty()) {
            val t = text("Belum ada email. Ketuk + untuk menambah.", 13f, pal.muted)
            t.setPadding(dp(16), dp(10), dp(16), dp(10))
            stockRows.addView(t, lpMW())
        }
        list.forEachIndexed { i, mail ->
            stockRows.addView(stockRow(i, mail), LinearLayout.LayoutParams(MATCH, dp(36)))
        }
        tvStockCount.text = "Sisa: ${list.size} email"
        updateStockRowValue()
        updateKaitkan()
    }

    private fun stockRow(i: Int, mail: String): View {
        val r = hbox()
        r.isClickable = true
        r.background = pressable(rounded(Color.TRANSPARENT, 0f))
        val n = text((i + 1).toString(), 12f, pal.muted)
        n.typeface = Typeface.MONOSPACE
        n.gravity = Gravity.END
        n.setPadding(0, 0, dp(8), 0)
        r.addView(n, LinearLayout.LayoutParams(dp(38), WRAP))
        val line = View(this)
        line.setBackgroundColor(pal.border)
        r.addView(line, LinearLayout.LayoutParams(1, MATCH))
        val e = text(mail, 13f, pal.text)
        e.typeface = Typeface.MONOSPACE
        e.setSingleLine(true)
        e.ellipsize = TextUtils.TruncateAt.END
        e.setPadding(dp(10), 0, dp(10), 0)
        r.addView(e, lpWeight())
        r.setOnClickListener { showRowMenu(i, mail) }
        return r
    }

    private fun showRowMenu(i: Int, mail: String) {
        if (isFinishing) return
        AlertDialog.Builder(this, dialogTheme())
            .setTitle(mail)
            .setItems(arrayOf("Edit", "Hapus")) { _, which ->
                if (which == 0) showEditDialog(i, mail) else deleteEmail(i)
            }
            .show()
    }

    private fun deleteEmail(i: Int) {
        val list = ArrayList(EmailStock.stock(this))
        if (i < 0 || i >= list.size) return
        list.removeAt(i)
        EmailStock.setStock(this, list)
        stockRefresh()
        toast("Dihapus")
    }

    private fun showEditDialog(i: Int, mail: String) {
        if (isFinishing) return
        val et = input(false, "nama@email.com")
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        et.setText(mail)
        et.setSelection(et.text.length)
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et, lpMW())
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Edit email")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().trim()
                val list = ArrayList(EmailStock.stock(this))
                if (i >= 0 && i < list.size) {
                    if (v.indexOf('@') < 1 || v.contains(' ')) {
                        toast("Email tidak valid")
                    } else if (list.indices.any { it != i && list[it].equals(v, ignoreCase = true) }) {
                        toast("Email sudah ada di stok")
                    } else {
                        list[i] = v
                        EmailStock.setStock(this, list)
                        stockRefresh()
                        toast("Disimpan")
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showAddDialog() {
        if (isFinishing) return
        val et = EditText(this)
        et.setTextColor(pal.text)
        et.setHintTextColor(pal.hint)
        et.hint = "nama01@contoh.com"
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        et.typeface = Typeface.MONOSPACE
        et.background = rounded(pal.field, 14f, pal.border)
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.minLines = 4
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val st = text("", 12f, pal.muted)
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(text("Tempel satu atau banyak email, satu per baris.", 12f, pal.muted), lpMW(bottom = dp(8)))
        box.addView(et, lpMW())
        box.addView(st, lpMW(top = dp(8)))
        watch(et) {
            val r = EmailStock.parse(et.text.toString(), EmailStock.stock(this))
            st.text = "${r.first.size} siap ditambahkan \u00B7 ${r.second} baris diabaikan"
        }
        val dlg = AlertDialog.Builder(this, dialogTheme())
            .setTitle("Tambah email")
            .setView(box)
            .setPositiveButton("Tambah") { _, _ ->
                val cur = EmailStock.stock(this)
                val r = EmailStock.parse(et.text.toString(), cur)
                if (r.first.isEmpty()) {
                    toast("Tidak ada email valid untuk ditambahkan")
                } else {
                    EmailStock.setStock(this, cur + r.first)
                    stockRefresh()
                    toast("${r.first.size} ditambahkan, ${r.second} diabaikan")
                }
            }
            .setNegativeButton("Batal", null)
            .create()
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
    }

    private fun openStockPage() {
        if (stockOpen) return
        hideKeyboard()
        stockRefresh()
        stockOpen = true
        stockPage.visibility = View.VISIBLE
        stockPage.translationX = root.width.toFloat()
        stockPage.animate().translationX(0f).setDuration(380).setInterpolator(IOS_EASE).start()
    }

    private fun closeStockPage() {
        if (!stockOpen) return
        hideKeyboard()
        stockOpen = false
        updateKaitkan()
        stockPage.animate().translationX(root.width.toFloat()).setDuration(320).setInterpolator(IOS_EASE)
            .withEndAction { if (!stockOpen) stockPage.visibility = View.GONE }
            .start()
    }

    // Tes isi nama: hitung mundur 5 detik, lalu kolom nama diisi (Okay tidak diketuk)
    private fun doNameTest() {
        hideKeyboard()
        saveSet()
        val i = Intent(this, RunnerService::class.java)
        i.action = "OCR_TEST"
        i.putExtra("which", "name")
        i.putExtra("nickBase", etNick.text.toString())
        i.putExtra("nickStart", etNickStart.text.toString().toIntOrNull() ?: 1)
        try {
            startService(i)
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Penyegaran status (tiap 700 ms)
    // =====================================================================

    private fun poll() {
        if (!uiReady) return
        try {
            pollInner()
        } catch (e: Throwable) {
            showCrashScreen("Pembaruan status gagal", android.util.Log.getStackTraceString(e))
        }
    }

    private fun pollInner() {
        updateKaitkan()
        updateStockRowValue()
        if (stockOpen && stockVer != EmailStock.version) stockRefresh()
        updateSecureRow()
        updateNickWarn()
        autoTasks()
        val run = RunnerService.running
        val rv = if (run) View.GONE else View.VISIBLE
        if (vReady.visibility != rv) vReady.visibility = rv
        val rr = if (run) View.VISIBLE else View.GONE
        if (vRun.visibility != rr) vRun.visibility = rr

        ring.setProgress(RunnerService.done, RunnerService.total)
        setIfChanged(tvPhase, RunnerService.phase)
        setIfChanged(tvFound, RunnerService.found.toString())
        val t = etTarget.text.toString().toIntOrNull() ?: 0
        setIfChanged(tvTgt, if (t > 0) t.toString() else "Bebas")

        val ov = Settings.canDrawOverlays(this)
        val sz = ShizukuHelper.hasPermission()
        val a11y = OcrA11yService.isRunning()
        setDot(dOv, ov)
        setDot(pOv, ov)
        setDot(dSz, sz)
        setDot(pSz, sz)
        setDot(dA11y, a11y)
        setDot(pA11y, a11y)
        setDot(dBat, batteryUnrestricted())
        setStatus(if (run) 2 else if (ov && sz && a11y) 1 else 0)

        setEnabledLook(bTap, !RunnerService.tapTestBusy)
        setIfChanged(tvTapRes, RunnerService.tapTestResult)
        val ob = !RunnerService.ocrTestBusy
        setEnabledLook(bLogin, ob)
        setEnabledLook(bNameTest, ob)
        val res = RunnerService.ocrTestResult
        when (RunnerService.ocrTestTag) {
            "login" -> setIfChanged(tvLoginRes, res)
            "name" -> setIfChanged(tvNameRes, res)
        }

        renderLog(RunnerService.logsSnapshot())

        val sv = RunnerService.serversSnapshot()
        val notes = RunnerService.notesSnapshot()
        val topText = listOf(notes.first, notes.second).filter { it.isNotEmpty() }.joinToString("\n")
        setIfChanged(tvNotesTop, topText)
        val tv = if (topText.isEmpty()) View.GONE else View.VISIBLE
        if (tvNotesTop.visibility != tv) tvNotesTop.visibility = tv
        val lv = if (topText.isNotEmpty() && sv.isNotEmpty()) View.VISIBLE else View.GONE
        if (vNotesLine.visibility != lv) vNotesLine.visibility = lv
        setIfChanged(tvSrv, if (sv.isEmpty()) (if (topText.isEmpty()) "Belum ada catatan." else "") else sv.joinToString("\n"))
        val sg = if (sv.isEmpty() && topText.isNotEmpty()) View.GONE else View.VISIBLE
        if (tvSrv.visibility != sg) tvSrv.visibility = sg
        setIfChanged(tvSrvTitle, "Catatan umum (${sv.size})")
    }
}
