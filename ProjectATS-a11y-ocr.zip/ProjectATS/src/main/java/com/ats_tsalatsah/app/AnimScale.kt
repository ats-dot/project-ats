package com.ats_tsalatsah.app

import android.content.Context
import android.os.SystemClock

// Matikan animasi sistem (3 skala di Opsi pengembang) selama sesi, lalu kembalikan ke 1x.
// Dua cara dipakai bersamaan: lewat pengelola jendela (seperti Opsi pengembang) dan lewat
// "settings put global". Setelah itu nilainya DIBACA ULANG dan dicatat di log, jadi hasil
// sebenarnya kelihatan, bukan sekadar "perintah terkirim".
object AnimScale {

    private const val PREFS = "ats_anim"
    private const val KEY_PENDING = "pending"
    private const val NORMAL = "1.0"

    private val KEYS = arrayOf(
        "window_animation_scale",
        "transition_animation_scale",
        "animator_duration_scale"
    )

    // true = animasi sedang dimatikan oleh aplikasi ini dan belum dikembalikan
    fun isPending(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_PENDING, false)

    private fun setPending(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_PENDING, v).apply()
    }

    // Tulis lewat "settings put global" (3 skala sekaligus)
    private fun applySettings(value: String): Pair<Boolean, String> {
        val cmd = KEYS.joinToString(" && ") { "settings put global $it $value" }
        return ShizukuHelper.exec(arrayOf("sh", "-c", cmd), 6000L)
    }

    // Baca nilai ketiga skala. null = gagal membaca. "null" (belum diatur) dihitung 1.
    private fun readValues(): FloatArray? {
        val cmd = KEYS.joinToString("; ") { "settings get global $it" }
        val r = ShizukuHelper.execOut(arrayOf("sh", "-c", cmd), 6000L)
        if (!r.first) return null
        val lines = r.second.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size < 3) return null
        val out = FloatArray(3)
        for (i in 0..2) {
            out[i] = if (lines[i] == "null") 1f else (lines[i].toFloatOrNull() ?: return null)
        }
        return out
    }

    private fun num(f: Float): String = if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString()

    private fun fmt(v: FloatArray?): String =
        if (v == null) "tidak terbaca" else "jendela=${num(v[0])}, transisi=${num(v[1])}, animator=${num(v[2])}"

    private fun allNear(v: FloatArray?, target: Float): Boolean =
        v != null && v.all { kotlin.math.abs(it - target) < 0.01f }

    // Terapkan dengan kedua cara. Hasil: (keterangan wm, keterangan settings)
    private fun applyBoth(scale: Float, value: String): Pair<Pair<Boolean, String>, Pair<Boolean, String>> {
        val wm = ShizukuHelper.setAnimationScales(scale)
        val st = applySettings(value)
        return Pair(wm, st)
    }

    private fun res(r: Pair<Boolean, String>): String = if (r.first) "ok" else "gagal (${r.second.take(100)})"

    @Synchronized
    fun disable(ctx: Context, log: (String) -> Unit): Boolean {
        // Ditandai dulu: kalau proses terputus di tengah jalan, animasi tetap dikembalikan nanti
        setPending(ctx, true)
        val t0 = SystemClock.uptimeMillis()
        val a = applyBoth(0f, "0")
        val v = readValues()
        val ms = SystemClock.uptimeMillis() - t0
        val ok = allNear(v, 0f)
        log("Animasi sistem: pengelola jendela ${res(a.first)}, settings ${res(a.second)} ($ms ms)")
        log("Animasi sistem: nilai terbaca ${fmt(v)}" + (if (ok) " (sudah mati)" else " (BELUM 0)"))
        return ok
    }

    @Synchronized
    fun restore(ctx: Context, log: (String) -> Unit): Boolean {
        val t0 = SystemClock.uptimeMillis()
        val a = applyBoth(1f, NORMAL)
        val v = readValues()
        val ms = SystemClock.uptimeMillis() - t0
        val ok = allNear(v, 1f)
        if (ok) {
            setPending(ctx, false)
            log("Animasi sistem dikembalikan ke 1x, nilai terbaca ${fmt(v)} ($ms ms)")
        } else {
            log("Animasi sistem: pengelola jendela ${res(a.first)}, settings ${res(a.second)}; nilai terbaca ${fmt(v)}. Coba lagi saat aplikasi dibuka.")
        }
        return ok
    }

    // Penjaga berkala selama sesi. verbose = true: hasil cek selalu dicatat (untuk cek pertama).
    // Kalau ada yang mengembalikan nilainya dari 0, diterapkan ulang dan dicatat.
    @Synchronized
    fun keep(ctx: Context, verbose: Boolean, log: (String) -> Unit) {
        if (!isPending(ctx)) return
        val v = readValues()
        if (allNear(v, 0f)) {
            if (verbose) log("Animasi sistem dicek ulang: ${fmt(v)} (masih mati)")
            return
        }
        log("Animasi sistem dikembalikan oleh sistem (${fmt(v)}), diterapkan ulang")
        applyBoth(0f, "0")
        log("Animasi sistem setelah diterapkan ulang: ${fmt(readValues())}")
    }
}
