package com.ats_tsalatsah.app

import android.content.Context
import android.os.SystemClock

// Matikan animasi sistem (3 skala di Opsi pengembang) selama sesi, lalu kembalikan ke 1x.
// Perubahan dilakukan lewat Shizuku (settings put global ...).
object AnimScale {

    private const val PREFS = "ats_anim"
    private const val KEY_PENDING = "pending"
    private const val NORMAL = "1.0"

    private val KEYS = arrayOf(
        "window_animation_scale",
        "transition_animation_scale",
        "animator_duration_scale"
    )

    // true = animasi sedang dimatikan oleh aplikasi ini dan belum dikembalikan
    fun isPending(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_PENDING, false)

    private fun setPending(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_PENDING, v).apply()
    }

    // Ketiga skala diubah dalam satu perintah supaya cepat
    private fun apply(value: String): Pair<Boolean, String> {
        val cmd = KEYS.joinToString(" && ") { "settings put global $it $value" }
        return ShizukuHelper.exec(arrayOf("sh", "-c", cmd), 6000L)
    }

    fun disable(ctx: Context, log: (String) -> Unit): Boolean {
        // Ditandai dulu: kalau proses terputus di tengah jalan, animasi tetap dikembalikan nanti
        setPending(ctx, true)
        val t0 = SystemClock.uptimeMillis()
        val r = apply("0")
        val ms = SystemClock.uptimeMillis() - t0
        if (r.first) log("Animasi sistem dimatikan selama proses ($ms ms)")
        else log("Gagal mematikan animasi sistem: ${r.second}")
        return r.first
    }

    fun restore(ctx: Context, log: (String) -> Unit): Boolean {
        val t0 = SystemClock.uptimeMillis()
        val r = apply(NORMAL)
        val ms = SystemClock.uptimeMillis() - t0
        if (r.first) {
            setPending(ctx, false)
            log("Animasi sistem dikembalikan ke 1x ($ms ms)")
        } else {
            log("Gagal mengembalikan animasi sistem: ${r.second}. Coba lagi saat aplikasi dibuka.")
        }
        return r.first
    }
}
