package com.ats_tsalatsah.app

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Mencatat crash ke file (langsung, tanpa menunggu), supaya penyebabnya
// bisa ditampilkan di log saat aplikasi dibuka lagi.
object CrashLog {

    @Volatile private var installed = false

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                File(app.filesDir, "crash.txt").writeText(
                    "$time [${t.name}]\n" + Log.getStackTraceString(e).take(4000)
                )
            } catch (x: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    // Ambil laporan crash terakhir (sekali saja), atau null kalau tidak ada
    fun takeReport(ctx: Context): String? {
        return try {
            val f = File(ctx.filesDir, "crash.txt")
            if (!f.exists()) return null
            val s = f.readText()
            f.delete()
            s
        } catch (e: Throwable) {
            null
        }
    }
}
