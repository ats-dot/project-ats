package com.ats_tsalatsah.app

import android.content.Context
import android.net.Uri
import android.os.Bundle

// Mengirim akun dan semua server yang terbaca ke aplikasi Catatan Cabang (com.catatan.cabang)
// lewat ContentProvider miliknya. Kalau aplikasinya tidak terpasang, hanya mengembalikan teks untuk log.
object CatatanLink {
    private const val AUTH = "content://com.catatan.cabang.bukti"

    fun sendAccount(ctx: Context, email: String, id: String, servers: List<Int>): String {
        if (id.isBlank()) return "Catatan Cabang dilewati: ID akun belum terbaca"
        if (servers.isEmpty()) return "Catatan Cabang dilewati: tidak ada server yang terbaca"
        val b = Bundle()
        b.putString("email", email)
        b.putString("servers", servers.sorted().joinToString(","))
        return try {
            val r = ctx.contentResolver.call(Uri.parse(AUTH), "akun", id, b)
            if (r != null) {
                "Catatan Cabang: akun " + id + ", " + servers.size + " server terkirim" +
                    (if (email.isBlank()) " (tanpa email)" else " (" + email + ")")
            } else {
                "Catatan Cabang tidak menjawab (belum terpasang atau versinya lama)"
            }
        } catch (e: Throwable) {
            "Catatan Cabang tidak terjangkau (" + e.javaClass.simpleName + ")"
        }
    }
}
