package com.ats_tsalatsah.app

import android.content.Context

// Sumber data untuk halaman stok. Satu halaman (tampilan dan animasinya) dipakai untuk Stok email dan Stok nickname
interface StockSrc {
    val title: String
    val hint: String
    val unit: String            // "email" atau "nama"
    val emptyText: String
    val addTitle: String
    val addHint: String
    val addPlaceholder: String
    val editTitle: String
    val invalidMsg: String
    val dupMsg: String
    val isEmail: Boolean
    fun list(ctx: Context): List<String>
    fun on(ctx: Context): Boolean
    fun setOn(ctx: Context, on: Boolean)
    fun setList(ctx: Context, l: List<String>)
    fun version(): Int
    // Layak masuk stok (selain tidak kembar)
    fun valid(line: String): Boolean
}

object EmailSrc : StockSrc {
    override val title = "Stok email"
    override val hint = "Email paling atas dipakai lebih dulu."
    override val unit = "email"
    override val emptyText = "Belum ada email. Ketuk + untuk menambah."
    override val addTitle = "Tambah email"
    override val addHint = "Tempel satu atau banyak email, satu per baris."
    override val addPlaceholder = "nama01@contoh.com"
    override val editTitle = "Edit email"
    override val invalidMsg = "Email tidak valid"
    override val dupMsg = "Email sudah ada di stok"
    override val isEmail = true
    override fun list(ctx: Context) = EmailStock.stock(ctx)
    override fun on(ctx: Context) = EmailStock.stockOn(ctx)
    override fun setOn(ctx: Context, on: Boolean) = EmailStock.setStockOn(ctx, on)
    override fun setList(ctx: Context, l: List<String>) = EmailStock.setStock(ctx, l)
    override fun version() = EmailStock.version
    override fun valid(line: String) = line.indexOf('@') > 0 && !line.contains(' ')
}

object NickSrc : StockSrc {
    override val title = "Stok nickname"
    override val hint = "Awalan paling atas dipakai satu sesi penuh, dan keluar dari stok saat Mulai ditekan."
    override val unit = "awalan"
    override val emptyText = "Belum ada awalan. Ketuk + untuk menambah."
    override val addTitle = "Tambah awalan"
    override val addHint = "Tempel satu atau banyak awalan, satu per baris. Nama server = awalan + nomor."
    override val addPlaceholder = "SCRP-"
    override val editTitle = "Edit awalan"
    override val invalidMsg = "Awalan harus 3 sampai 17 karakter"
    override val dupMsg = "Awalan sudah ada di stok"
    override val isEmail = false
    override fun list(ctx: Context) = NickStock.stock(ctx)
    override fun on(ctx: Context) = NickStock.stockOn(ctx)
    override fun setOn(ctx: Context, on: Boolean) = NickStock.setStockOn(ctx, on)
    override fun setList(ctx: Context, l: List<String>) = NickStock.setStock(ctx, l)
    override fun version() = NickStock.version
    override fun valid(line: String) = NickStock.valid(line)
}

object StockParse {
    class Result(val ok: List<String>, val ignored: Int, val ignoredRanges: List<IntRange>)

    // Pecah teks jadi baris yang layak dan tidak kembar. ignoredRanges = posisi karakter baris yang diabaikan (untuk dicoret)
    fun parse(src: StockSrc, text: String, existing: List<String>): Result {
        val seen = HashSet<String>()
        existing.forEach { seen.add(it.lowercase()) }
        val ok = ArrayList<String>()
        val ranges = ArrayList<IntRange>()
        var off = 0
        for (raw in text.split("\n")) {
            val start = off
            off += raw.length + 1
            val l = raw.trim()
            if (l.isEmpty()) continue
            val k = l.lowercase()
            if (src.valid(l) && !seen.contains(k)) {
                seen.add(k)
                ok.add(l)
            } else if (raw.isNotEmpty()) {
                ranges.add(start until (start + raw.length))
            }
        }
        return Result(ok, ranges.size, ranges)
    }
}
