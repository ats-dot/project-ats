package com.ats_tsalatsah.app

// Pencocokan teks longgar untuk hasil OCR:
// huruf kecil, simbol dibuang, contains, toleransi Levenshtein 1 untuk kata >= 4 huruf.
object TextMatch {

    // Huruf kecil, selain huruf/angka jadi spasi, spasi dirapatkan
    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        var space = false
        for (ch in s.lowercase()) {
            if (ch.isLetterOrDigit()) {
                sb.append(ch)
                space = false
            } else if (!space && sb.isNotEmpty()) {
                sb.append(' ')
                space = true
            }
        }
        return sb.toString().trim()
    }

    private fun compact(s: String): String = s.replace(" ", "")

    // "Create Character, Buat Karakter" -> daftar kata kunci
    fun parseKeys(s: String): List<String> =
        s.split(',', '\n').map { it.trim() }.filter { compact(norm(it)).isNotEmpty() }

    // Jarak Levenshtein, berhenti lebih awal kalau sudah pasti > max
    fun lev(a: String, b: String, max: Int): Int {
        if (kotlin.math.abs(a.length - b.length) > max) return max + 1
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                val v = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > max) return max + 1
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }

    private fun wordOk(lineWord: String, keyWord: String): Boolean {
        if (lineWord == keyWord) return true
        if (keyWord.length < 4) return false // kata pendek: harus persis
        return lineWord.contains(keyWord) || lev(lineWord, keyWord, 1) <= 1
    }

    fun matches(text: String, key: String): Boolean {
        val n = norm(text)
        val k = norm(key)
        if (n.isEmpty() || k.isEmpty()) return false
        val cn = compact(n)
        val ck = compact(k)

        // 1) contains (tanpa spasi)
        if (cn.contains(ck)) return true

        // 2) per kata: semua kata kunci ada, kata >= 4 huruf boleh salah 1 huruf
        val lw = n.split(' ')
        if (k.split(' ').all { kw -> lw.any { wordOk(it, kw) } }) return true

        // 3) kata menempel/terpotong ("createcharacter"): jendela geser, salah maksimal 1
        if (ck.length >= 4) {
            for (len in (ck.length - 1)..(ck.length + 1)) {
                if (len <= 0 || len > cn.length) continue
                for (i in 0..(cn.length - len)) {
                    if (lev(cn.substring(i, i + len), ck, 1) <= 1) return true
                }
            }
        }
        return false
    }

    // Cari kata kunci di hasil OCR. Per baris dulu (punya kotak untuk diketuk),
    // lalu di seluruh teks (tanpa kotak).
    fun find(r: OcrResult, keys: List<String>): Pair<String, OcrLine>? {
        for (key in keys) {
            for (line in r.lines) {
                if (matches(line.text, key)) return Pair(key, line)
            }
        }
        for (key in keys) {
            if (matches(r.text, key)) return Pair(key, OcrLine(r.text, null))
        }
        return null
    }
}
