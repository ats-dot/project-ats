package com.ats_tsalatsah.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.DecelerateInterpolator

// Cincin progres "done/total aplikasi" (pengganti SVG di versi HTML)
class RingView(ctx: Context, pal: Palette) : View(ctx) {

    private var label = "0/0"
    private var shown = 0f
    private var target = 0f
    private var anim: ValueAnimator? = null
    private val oval = RectF()

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = pal.track
    }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = pal.primary
        strokeCap = Paint.Cap.ROUND
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = pal.text
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = pal.muted
        textAlign = Paint.Align.CENTER
    }

    fun setProgress(done: Int, total: Int) {
        val l = "$done/$total"
        if (l != label) {
            label = l
            invalidate()
        }
        val p = if (total > 0) minOf(1f, done.toFloat() / total) else 0f
        if (p != target) {
            target = p
            anim?.cancel()
            anim = ValueAnimator.ofFloat(shown, p).apply {
                duration = 300
                addUpdateListener {
                    shown = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height) / 140f
        val cx = width / 2f
        val cy = height / 2f
        val r = 54f * s
        bg.strokeWidth = 10f * s
        fg.strokeWidth = 10f * s
        c.drawCircle(cx, cy, r, bg)
        oval.set(cx - r, cy - r, cx + r, cy + r)
        if (shown > 0f) c.drawArc(oval, -90f, 360f * shown, false, fg)
        big.textSize = 26f * s
        small.textSize = 10f * s
        c.drawText(label, cx, cy + 6f * s, big)
        c.drawText("aplikasi", cx, cy + 26f * s, small)
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}

// Ikon segitiga "play" untuk tombol Mulai
class PlayIcon(ctx: Context, col: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col
        style = Paint.Style.FILL
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height) / 24f
        path.reset()
        path.moveTo(7f * s, 4f * s)
        path.lineTo(20f * s, 12f * s)
        path.lineTo(7f * s, 20f * s)
        path.close()
        c.drawPath(path, paint)
    }
}

// Ikon garis sederhana untuk tombol kecil: 0 = unduh, 1 = hapus, 2 = salin, 3 = daftar centang
class GlyphView(ctx: Context, private val kind: Int, private val col: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val u = minOf(width, height) / 24f
        c.save()
        c.translate((width - 24f * u) / 2f, (height - 24f * u) / 2f)
        c.scale(u, u)
        paint.color = col
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.9f
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        path.reset()
        if (kind == 0) {
            c.drawLine(12f, 4f, 12f, 15f, paint)
            path.moveTo(7.5f, 10.5f); path.lineTo(12f, 15f); path.lineTo(16.5f, 10.5f)
            c.drawPath(path, paint)
            path.reset()
            path.moveTo(4.5f, 15.5f); path.lineTo(4.5f, 19.5f); path.lineTo(19.5f, 19.5f); path.lineTo(19.5f, 15.5f)
            c.drawPath(path, paint)
        } else if (kind == 2) {
            c.drawRoundRect(9f, 9f, 20f, 20f, 2f, 2f, paint)
            path.moveTo(5f, 15f); path.lineTo(5f, 6f); path.quadTo(5f, 4f, 7f, 4f); path.lineTo(15f, 4f)
            c.drawPath(path, paint)
        } else if (kind == 3) {
            path.moveTo(4f, 7f); path.lineTo(6f, 9f); path.lineTo(9f, 6f)
            c.drawPath(path, paint)
            path.reset()
            path.moveTo(4f, 15f); path.lineTo(6f, 17f); path.lineTo(9f, 14f)
            c.drawPath(path, paint)
            c.drawLine(12f, 8f, 20f, 8f, paint)
            c.drawLine(12f, 16f, 20f, 16f, paint)
        } else {
            c.drawLine(4f, 7f, 20f, 7f, paint)
            c.drawLine(10f, 11f, 10f, 17f, paint)
            c.drawLine(14f, 11f, 14f, 17f, paint)
            path.moveTo(6f, 7f); path.lineTo(7f, 19f); path.lineTo(17f, 19f); path.lineTo(18f, 7f)
            c.drawPath(path, paint)
            path.reset()
            path.moveTo(9f, 7f); path.lineTo(9f, 4f); path.lineTo(15f, 4f); path.lineTo(15f, 7f)
            c.drawPath(path, paint)
        }
        c.restore()
    }
}

// Lingkaran pilih (mode pilih banyak): cincin, dan titik di tengah yang membesar saat terpilih
class SelDot(ctx: Context, private val ring: Int, private val ringOn: Int, private val fill: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val argb = ArgbEvaluator()
    private var anim: ValueAnimator? = null
    private var p = 0f

    fun setSelectedState(on: Boolean, animate: Boolean) {
        anim?.cancel()
        val to = if (on) 1f else 0f
        if (!animate) {
            p = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(p, to)
        a.duration = 200
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            p = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 1.5f * d
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * d
        paint.color = argb.evaluate(p, ring, ringOn) as Int
        c.drawCircle(cx, cy, r, paint)
        if (p > 0f) {
            paint.style = Paint.Style.FILL
            paint.color = fill
            c.drawCircle(cx, cy, r * 0.55f * p, paint)
        }
    }
}
