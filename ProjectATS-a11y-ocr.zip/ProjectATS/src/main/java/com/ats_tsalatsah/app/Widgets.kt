package com.ats_tsalatsah.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

// Cincin progres "done/total aplikasi" (pengganti SVG di versi HTML)
class RingView(ctx: Context, pal: Palette) : View(ctx) {

    private var label = "0/0"
    private var shown = 0f
    private var target = 0f
    private var anim: ValueAnimator? = null
    private val oval = RectF()

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = pal.track
    }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = pal.primary
        strokeCap = Paint.Cap.ROUND
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = pal.text
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = pal.muted
        textAlign = Paint.Align.CENTER
    }

    fun setProgress(done: Int, total: Int) {
        val l = "$done/$total"
        if (l != label) {
            label = l
            invalidate()
        }
        val p = if (total > 0) minOf(1f, done.toFloat() / total) else 0f
        if (p != target) {
            target = p
            anim?.cancel()
            anim = ValueAnimator.ofFloat(shown, p).apply {
                duration = 300
                addUpdateListener {
                    shown = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height) / 140f
        val cx = width / 2f
        val cy = height / 2f
        val r = 54f * s
        bg.strokeWidth = 10f * s
        fg.strokeWidth = 10f * s
        c.drawCircle(cx, cy, r, bg)
        oval.set(cx - r, cy - r, cx + r, cy + r)
        if (shown > 0f) c.drawArc(oval, -90f, 360f * shown, false, fg)
        big.textSize = 26f * s
        small.textSize = 10f * s
        c.drawText(label, cx, cy + 6f * s, big)
        c.drawText("aplikasi", cx, cy + 26f * s, small)
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}

// Ikon segitiga "play" untuk tombol Mulai
class PlayIcon(ctx: Context, col: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col
        style = Paint.Style.FILL
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height) / 24f
        path.reset()
        path.moveTo(7f * s, 4f * s)
        path.lineTo(20f * s, 12f * s)
        path.lineTo(7f * s, 20f * s)
        path.close()
        c.drawPath(path, paint)
    }
}
