package com.ats_tsalatsah.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.DecelerateInterpolator

// Cincin progres "done/total aplikasi" (pengganti SVG di versi HTML)
class RingView(ctx: Context, pal: Palette) : View(ctx) {

    private var label = "0/0"
    private var shown = 0f
    private var target = 0f
    private var anim: ValueAnimator? = null
    private val oval = RectF()

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = pal.track
    }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = pal.primary
        strokeCap = Paint.Cap.ROUND
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = pal.text
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = pal.muted
        textAlign = Paint.Align.CENTER
    }

    fun setProgress(done: Int, total: Int) {
        val l = "$done/$total"
        if (l != label) {
            label = l
            invalidate()
        }
        val p = if (total > 0) minOf(1f, done.toFloat() / total) else 0f
        if (p != target) {
            target = p
            anim?.cancel()
            anim = ValueAnimator.ofFloat(shown, p).apply {
                duration = 300
                addUpdateListener {
                    shown = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height) / 140f
        val cx = width / 2f
        val cy = height / 2f
        val r = 54f * s
        bg.strokeWidth = 10f * s
        fg.strokeWidth = 10f * s
        c.drawCircle(cx, cy, r, bg)
        oval.set(cx - r, cy - r, cx + r, cy + r)
        if (shown > 0f) c.drawArc(oval, -90f, 360f * shown, false, fg)
        big.textSize = 26f * s
        small.textSize = 10f * s
        c.drawText(label, cx, cy + 6f * s, big)
        c.drawText("aplikasi", cx, cy + 26f * s, small)
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}

// Ikon segitiga "play" untuk tombol Mulai
class PlayIcon(ctx: Context, col: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col
        style = Paint.Style.FILL
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height) / 24f
        path.reset()
        path.moveTo(7f * s, 4f * s)
        path.lineTo(20f * s, 12f * s)
        path.lineTo(7f * s, 20f * s)
        path.close()
        c.drawPath(path, paint)
    }
}

// Ikon garis sederhana untuk tombol kecil: 0 unduh, 1 hapus, 2 salin, 3 daftar centang, 4 kembali (panah kiri), 5 tutup (X), 6 titik tiga
class GlyphView(ctx: Context, private val kind: Int, private val col: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val u = minOf(width, height) / 24f
        c.save()
        c.translate((width - 24f * u) / 2f, (height - 24f * u) / 2f)
        c.scale(u, u)
        paint.color = col
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.9f
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        path.reset()
        if (kind == 0) {
            c.drawLine(12f, 4f, 12f, 15f, paint)
            path.moveTo(7.5f, 10.5f); path.lineTo(12f, 15f); path.lineTo(16.5f, 10.5f)
            c.drawPath(path, paint)
            path.reset()
            path.moveTo(4.5f, 15.5f); path.lineTo(4.5f, 19.5f); path.lineTo(19.5f, 19.5f); path.lineTo(19.5f, 15.5f)
            c.drawPath(path, paint)
        } else if (kind == 4) {
            path.moveTo(15f, 5f); path.lineTo(8f, 12f); path.lineTo(15f, 19f)
            c.drawPath(path, paint)
        } else if (kind == 5) {
            c.drawLine(6f, 6f, 18f, 18f, paint)
            c.drawLine(18f, 6f, 6f, 18f, paint)
        } else if (kind == 6) {
            paint.style = Paint.Style.FILL
            c.drawCircle(12f, 5f, 1.9f, paint)
            c.drawCircle(12f, 12f, 1.9f, paint)
            c.drawCircle(12f, 19f, 1.9f, paint)
        } else if (kind == 2) {
            c.drawRoundRect(9f, 9f, 20f, 20f, 2f, 2f, paint)
            path.moveTo(5f, 15f); path.lineTo(5f, 6f); path.quadTo(5f, 4f, 7f, 4f); path.lineTo(15f, 4f)
            c.drawPath(path, paint)
        } else if (kind == 3) {
            path.moveTo(4f, 7f); path.lineTo(6f, 9f); path.lineTo(9f, 6f)
            c.drawPath(path, paint)
            path.reset()
            path.moveTo(4f, 15f); path.lineTo(6f, 17f); path.lineTo(9f, 14f)
            c.drawPath(path, paint)
            c.drawLine(12f, 8f, 20f, 8f, paint)
            c.drawLine(12f, 16f, 20f, 16f, paint)
        } else {
            c.drawLine(4f, 7f, 20f, 7f, paint)
            c.drawLine(10f, 11f, 10f, 17f, paint)
            c.drawLine(14f, 11f, 14f, 17f, paint)
            path.moveTo(6f, 7f); path.lineTo(7f, 19f); path.lineTo(17f, 19f); path.lineTo(18f, 7f)
            c.drawPath(path, paint)
            path.reset()
            path.moveTo(9f, 7f); path.lineTo(9f, 4f); path.lineTo(15f, 4f); path.lineTo(15f, 7f)
            c.drawPath(path, paint)
        }
        c.restore()
    }
}

// Lingkaran pilih (mode pilih banyak): cincin, dan titik di tengah yang membesar saat terpilih
class SelDot(ctx: Context, private val ring: Int, private val ringOn: Int, private val fill: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val argb = ArgbEvaluator()
    private var anim: ValueAnimator? = null
    private var p = 0f

    fun setSelectedState(on: Boolean, animate: Boolean) {
        anim?.cancel()
        val to = if (on) 1f else 0f
        if (!animate) {
            p = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(p, to)
        a.duration = 200
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            p = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 1.5f * d
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * d
        paint.color = argb.evaluate(p, ring, ringOn) as Int
        c.drawCircle(cx, cy, r, paint)
        if (p > 0f) {
            paint.style = Paint.Style.FILL
            paint.color = fill
            c.drawCircle(cx, cy, r * 0.55f * p, paint)
        }
    }
}


// Panah buka-tutup di dalam lingkaran kecil: menghadap ke atas saat tertutup, ke bawah saat terbuka (berputar halus)
class ChevronView(ctx: Context, private val pal: Palette) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val dens = ctx.resources.displayMetrics.density

    fun setOpen(open: Boolean, animate: Boolean = true) {
        val to = if (open) 180f else 0f
        if (animate) animate().rotation(to).setDuration(220).start() else rotation = to
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        p.style = Paint.Style.FILL
        p.color = pal.field
        c.drawCircle(cx, cy, w / 2f - dens, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dens
        p.color = pal.border
        c.drawCircle(cx, cy, w / 2f - dens, p)
        p.strokeWidth = 2f * dens
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = pal.muted
        val a = w * 0.17f
        path.reset()
        path.moveTo(cx - a, cy + a * 0.5f)
        path.lineTo(cx, cy - a * 0.5f)
        path.lineTo(cx + a, cy + a * 0.5f)
        c.drawPath(path, p)
    }
}


// Ikon kecil kartu memori (kotak dengan kaki) untuk tombol cek batas aplikasi latar
class RamIconView(ctx: Context, private val pal: Palette) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val dens = ctx.resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        p.style = Paint.Style.FILL
        p.color = pal.field
        c.drawCircle(cx, cy, w / 2f - dens, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dens
        p.color = pal.borderStrong
        c.drawCircle(cx, cy, w / 2f - dens, p)
        // badan kartu
        val bw = w * 0.34f
        val bh = h * 0.26f
        p.strokeWidth = 1.7f * dens
        p.color = pal.text
        r.set(cx - bw, cy - bh, cx + bw, cy + bh)
        c.drawRoundRect(r, 2.5f * dens, 2.5f * dens, p)
        // kaki atas dan bawah
        p.strokeCap = Paint.Cap.ROUND
        for (i in -1..1) {
            val x = cx + i * bw * 0.55f
            c.drawLine(x, cy - bh, x, cy - bh - h * 0.09f, p)
            c.drawLine(x, cy + bh, x, cy + bh + h * 0.09f, p)
        }
        // garis di dalam
        p.strokeWidth = 1.4f * dens
        c.drawLine(cx - bw * 0.5f, cy, cx + bw * 0.5f, cy, p)
    }
}
