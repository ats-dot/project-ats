package com.ats_tsalatsah.app

import android.graphics.Color
import android.os.SystemClock
import kotlin.math.abs

// Alur Kaitkan otomatis: dari halaman Level Up (atau lobi, kalau game sudah restart)
// sampai halaman "Email verifikasi telah dikirim".
// Tiap langkah menunggu halamannya terbaca (OCR) dulu, baru mengetuk. Langkah macet = berhenti.
class Linker(
    private val email: String,
    private val stop: () -> Boolean,
    private val log: (String) -> Unit,
    private val progress: (Int) -> Unit
) {

    class Result(val ok: Boolean, val reason: String, val profileId: String?, val profileServer: String?)

    private class Pg(val text: String, val lines: List<OcrLine>)

    companion object {
        const val STEPS = 14

        // Posisi ketukan, pecahan lebar/tinggi layar mendatar (dari screenshot 2400x1080)
        private const val CONT_X = 0.5f;       private const val CONT_Y = 0.929f      // Continue
        private const val SHOP_X = 0.076f;     private const val SHOP_Y = 0.233f      // Shop
        private const val PURCH_X = 0.284f;    private const val PURCH_Y = 0.656f     // Purchase (kartu pertama)
        private const val USEBP_X = 0.574f;    private const val USEBP_Y = 0.793f     // Use Battle Points
        private const val DLGX_X = 0.772f;     private const val DLGX_Y = 0.141f      // X di dialog
        private const val BACK_X = 0.105f;     private const val BACK_Y = 0.042f      // panah kembali
        private const val PROF_X = 0.077f;     private const val PROF_Y = 0.060f      // profil di lobi
        private const val ACCT_X = 0.105f;     private const val ACCT_Y = 0.449f      // Account
        private const val GIFT_X = 0.548f;     private const val GIFT_Y = 0.243f      // ikon hadiah
        private const val CNOW_X = 0.390f;     private const val CNOW_Y = 0.731f      // Connect Now
        private const val RECO_X = 0.507f;     private const val RECO_Y = 0.396f      // MOONTON Account (Recommend)
        private const val FIELD_X = 0.5f;      private const val FIELD_Y = 0.393f     // kolom Alamat Email
        private const val CLKB_X = 0.885f;     private const val CLKB_Y = 0.156f      // area kosong penutup keyboard
        private const val KIRIM_X = 0.5f;      private const val KIRIM_Y = 0.817f     // Kirim

        // Kalau deteksi keyboard lewat warna pernah gagal, sesi berikutnya langsung pakai jeda tetap
        @Volatile private var kbDetectFailed = false

        private val EMAIL_OPEN_AREA = Area("kolom email (keyboard terbuka)", 0.2f, 0.05f, 0.8f, 0.55f)
        // Hanya kotak kolom (keyboard terbuka): tidak ikut chip clipboard keyboard yang menampilkan email yang sama
        private val EMAIL_FIELD_AREA = Area("isi kolom email", 0.29f, 0.17f, 0.72f, 0.30f)
        private val PROFILE_ID_AREA = Area("id profil", 0.2f, 0.12f, 0.5f, 0.27f)
        private val EMAIL_AREA = Area("kolom email", 0.27f, 0.32f, 0.73f, 0.47f)
        private val PROFILE_RX = Regex("ID\\s*[:;]?\\s*(\\d{9,11})\\s*\\(\\s*(\\d{3,6})\\s*\\)")
    }

    private var svc: OcrA11yService? = null
    private var sw = 0
    private var sh = 0
    private var lastSeen = ""
    private var profileId: String? = null
    private var profileServer: String? = null

    private fun m(text: String, key: String): Boolean = TextMatch.matches(text, key)

    // Cocokkan per BARIS, supaya kata dari baris berbeda tidak dianggap satu frasa
    private fun has(p: Pg, key: String): Boolean =
        if (p.lines.isEmpty()) m(p.text, key) else p.lines.any { m(it.text, key) }

    private fun look(area: Area, scale: Float): Pg? {
        val v = svc ?: return null
        val s = v.capture(1500L)
        val b = s.bmp ?: return null
        sw = b.width
        sh = b.height
        val r = ScreenOcr.read(b, area, scale)
        if (!r.timedOut) b.recycle()
        if (r.error != null) return null
        if (area === Area.FULL) lastSeen = r.text.replace('\n', ' ').trim().take(80)
        return Pg(r.text, r.lines)
    }

    private fun waitPage(timeoutMs: Long, pred: (Pg) -> Boolean): Pg? {
        val end = SystemClock.uptimeMillis() + timeoutMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val p = look(Area.FULL, 0.6f) ?: continue
            if (pred(p)) return p
        }
        return null
    }

    private fun tapF(fx: Float, fy: Float): Boolean {
        val v = svc ?: return false
        return v.tap(fx * sw, fy * sh)
    }

    private fun tapLine(l: OcrLine?, fx: Float, fy: Float): Boolean {
        val b = l?.box
        val v = svc ?: return false
        return if (b != null) v.tap(b.exactCenterX(), b.exactCenterY()) else tapF(fx, fy)
    }

    // Keyboard terbuka = tiga titik di bagian bawah layar berwarna abu netral (R, G, B hampir sama).
    // Latar game kebiruan, jadi tidak netral. null = screenshot gagal.
    private fun kbOpen(): Boolean? {
        val v = svc ?: return null
        val s = v.capture(1500L)
        val b = s.bmp ?: return null
        sw = b.width
        sh = b.height
        var neutral = 0
        for (x in floatArrayOf(0.25f, 0.5f, 0.75f)) {
            val c = PixelCheck.at(b, x, 0.9f)
            if (abs(Color.red(c) - Color.green(c)) <= 8 && abs(Color.green(c) - Color.blue(c)) <= 8) neutral++
        }
        b.recycle()
        return neutral >= 3
    }

    // Tunggu keyboard terbuka (open = true) atau tertutup (open = false). true = tercapai.
    private fun waitKb(open: Boolean, limitMs: Long): Boolean {
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val k = kbOpen() ?: continue
            if (k == open) return true
        }
        return false
    }

    private fun sleepMs(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    private fun isLobby(p: Pg): Boolean = (has(p, "CLASSIC") || has(p, "Inventory")) && !has(p, "Level Up")
    private fun isShop(p: Pg): Boolean = has(p, "Purchase") && !has(p, "Purchase Hero")

    private fun fail(step: Int, name: String, why: String): Result {
        val seen = if (lastSeen.isEmpty()) "" else " (teks terakhir: '$lastSeen')"
        return Result(false, "langkah $step ($name): $why$seen", profileId, profileServer)
    }

    private fun ok(n: Int, name: String) {
        progress(n)
        log("langkah $n ($name): ok")
    }

    // Baca "ID: 2287446748 (57113)" di halaman Profil. ID = angka di luar kurung. Dua bacaan harus sama.
    private fun readProfileId() {
        var prev: String? = null
        val end = SystemClock.uptimeMillis() + 3500L
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val p = look(PROFILE_ID_AREA, 1.0f) ?: continue
            val mm = PROFILE_RX.find(p.text.replace('\n', ' '))
            if (mm == null) {
                prev = null
            } else {
                val id = mm.groupValues[1]
                if (id == prev) {
                    profileId = id
                    profileServer = mm.groupValues[2]
                    return
                }
                prev = id
            }
        }
    }

    private fun prepare(): Result? {
        svc = OcrA11yService.instance
        if (svc == null) return Result(false, "Aksesibilitas mati", null, null)
        if (!ShizukuHelper.hasPermission()) {
            return Result(false, "Shizuku belum diizinkan (dibutuhkan untuk mengisi email)", null, null)
        }
        return null
    }

    // Dari Level Up (atau lobi) sampai halaman ACCOUNT SETTINGS terbuka. null = berhasil.
    // Dipakai juga oleh aturan server yang belum dinamai dan apk Select a hero, tiap kali sebuah server selesai diperbaiki
    fun toAccount(): Result? {
        prepare()?.let { return it }

        // Keadaan awal: Level Up (mulai dari Continue) atau lobi (game sudah restart)
        var pg = waitPage(30000L) { has(it, "Level Up") || isLobby(it) }
            ?: return fail(0, "keadaan awal", "halaman Level Up atau lobi tidak muncul")
        if (has(pg, "Level Up")) {
            tapF(CONT_X, CONT_Y)
            ok(1, "Continue di Level Up")
        } else {
            progress(1)
            log("game sudah di lobi, langkah 1 dilewati")
        }

        pg = waitPage(15000L) { isLobby(it) } ?: return fail(2, "lobi", "lobi tidak muncul")
        tapF(SHOP_X, SHOP_Y)
        ok(2, "ketuk Shop")

        pg = waitPage(12000L) { isShop(it) } ?: return fail(3, "halaman Shop", "halaman Shop tidak muncul")
        val purchase = pg.lines.filter { m(it.text, "Purchase") && it.box != null }.minByOrNull { it.box!!.left }
        tapLine(purchase, PURCH_X, PURCH_Y)
        ok(3, "ketuk Purchase")

        pg = waitPage(10000L) { has(it, "Purchase Hero") } ?: return fail(4, "dialog Purchase Hero", "dialog tidak muncul")
        tapF(USEBP_X, USEBP_Y)
        ok(4, "ketuk Use Battle Points")

        sleepMs(700L)
        val dlg = look(Area.FULL, 0.6f)
        if (dlg != null && has(dlg, "Purchase Hero")) {
            tapF(DLGX_X, DLGX_Y)
            ok(5, "tutup dialog (X)")
        } else {
            progress(5)
            log("dialog sudah tertutup, langkah 5 dilewati")
        }

        pg = waitPage(12000L) { isShop(it) } ?: return fail(6, "kembali ke Shop", "halaman Shop tidak muncul setelah dialog ditutup")
        tapF(BACK_X, BACK_Y)
        ok(6, "ketuk panah kembali")

        pg = waitPage(12000L) { isLobby(it) } ?: return fail(7, "lobi", "lobi tidak muncul setelah kembali dari Shop")
        tapF(PROF_X, PROF_Y)
        ok(7, "ketuk profil")

        pg = waitPage(12000L) { has(it, "Current Rank") || has(it, "Highest Rank") || has(it, "Mythic Medal") }
            ?: return fail(8, "halaman Profil", "halaman Profil tidak muncul")
        readProfileId()
        if (profileId != null) log("ID dari Profil: $profileId (server $profileServer)") else log("ID di halaman Profil tidak terbaca")
        tapF(ACCT_X, ACCT_Y)
        ok(8, "ketuk Account")

        pg = waitPage(12000L) { has(it, "ACCOUNT SETTINGS") } ?: return fail(9, "Account Settings", "halaman tidak muncul")
        return null
    }

    // Dari halaman ACCOUNT SETTINGS (ikon hadiah) sampai email verifikasi terkirim
    fun fromAccount(): Result {
        prepare()?.let { return it }
        val v = svc ?: return Result(false, "Aksesibilitas mati", null, null)

        tapF(GIFT_X, GIFT_Y)
        ok(9, "ketuk ikon hadiah")

        var pg = waitPage(10000L) { has(it, "Connect Now") } ?: return fail(10, "Connect Now", "tombol tidak muncul")
        tapLine(pg.lines.firstOrNull { m(it.text, "Connect Now") && it.box != null }, CNOW_X, CNOW_Y)
        ok(10, "ketuk Connect Now")

        pg = waitPage(10000L) { has(it, "Recommend") } ?: return fail(11, "Connect Accounts", "pilihan MOONTON Account tidak muncul")
        tapF(RECO_X, RECO_Y)
        ok(11, "ketuk MOONTON Account")

        // Loading maksimal sekitar 5 detik, kadang tidak muncul
        pg = waitPage(15000L) { has(it, "Daftar dengan Email") || has(it, "Alamat Email") }
            ?: return fail(12, "form email", "form Daftar dengan Email tidak muncul")

        // Isi email: tunggu keyboard benar-benar terbuka, tempel, cek selagi keyboard masih terbuka, lalu tutup
        var kbSeen = false
        if (!kbDetectFailed) {
            for (k in 1..2) {
                if (stop()) return fail(12, "isi email", "dihentikan")
                tapF(FIELD_X, FIELD_Y)
                if (waitKb(true, 1200L)) {
                    kbSeen = true
                    break
                }
                log("keyboard belum terbuka setelah ketukan ke-$k")
            }
            if (!kbSeen) {
                kbDetectFailed = true
                log("keyboard tidak terdeteksi lewat warna, sesi berikutnya pakai jeda tetap")
                sleepMs(500L)
            }
        } else {
            tapF(FIELD_X, FIELD_Y)
            sleepMs(900L)
        }

        var typed = false
        var seenField = ""
        for (k in 1..2) {
            if (stop()) return fail(12, "isi email", "dihentikan")
            if (k > 1) {
                val c = ShizukuHelper.clearField(40, 3000L)
                if (!c.first) log("hapus isi kolom gagal: ${c.second}")
                sleepMs(250L)
            }
            val t = NameFiller.typeText(v, email, log)
            if (!t.first) return fail(12, "isi email", "gagal mengetik: ${t.second}")
            sleepMs(350L)
            val f = look(EMAIL_FIELD_AREA, 1.0f)
            seenField = f?.text?.replace('\n', ' ')?.trim() ?: ""
            val head = email.substringBefore('@').take(4)
            if (seenField.contains('@') || (head.length >= 3 && seenField.contains(head, ignoreCase = true))) {
                typed = true
                break
            }
            val empty = seenField.isEmpty() || seenField.contains("Alamat Email", ignoreCase = true)
            log("isi email percobaan $k: kolom " + (if (empty) "masih kosong" else "terbaca '${seenField.take(40)}'"))
        }
        if (!typed) return fail(12, "isi email", "email tidak masuk ke kolom setelah ditempel (terbaca di kolom: '${seenField.take(40)}'). Berhenti di sini")
        if (!seenField.replace(" ", "").contains(email, ignoreCase = true)) {
            log("catatan: teks di kolom terbaca '${seenField.take(40)}', beda dari email (kemungkinan salah baca OCR)")
        }

        tapF(CLKB_X, CLKB_Y)
        if (kbSeen) {
            if (!waitKb(false, 1200L)) log("keyboard belum tertutup setelah ketukan, lanjut")
        } else {
            sleepMs(700L)
        }
        ok(12, "isi email")

        tapF(KIRIM_X, KIRIM_Y)
        ok(13, "ketuk Kirim")

        pg = waitPage(15000L) {
            has(it, "Email verifikasi telah dikirim") || (has(it, "Buat Akun Moonton") && has(it, "Cek Email"))
        } ?: return fail(14, "konfirmasi", "halaman Email verifikasi telah dikirim tidak muncul")
        progress(14)
        log("langkah 14 (konfirmasi): ok")
        return Result(true, "email verifikasi dikirim ke $email", profileId, profileServer)
    }

    fun run(): Result {
        toAccount()?.let { return it }
        return fromAccount()
    }
}
