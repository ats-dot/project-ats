package com.ats_tsalatsah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class RunnerService : Service() {

    companion object {
        const val MARK = "===== Sesi baru"
        private const val MAX_SESSIONS = 20
        private const val MAX_LINES = 4000

        @Volatile var running = false
        @Volatile var done = 0
        @Volatile var total = 0
        @Volatile var found = 0
        @Volatile var phase = "Siap"

        // Ringkasan hasil cek batas aplikasi latar; ditampilkan sekali oleh MainActivity lalu dikosongkan
        @Volatile var memReport: String? = null

        // Jeda setelah mengetuk "Login kembali" sebelum lanjut ke apk berikutnya
        const val AFTER_LOGIN_TAP_MS = 1800L   // bawaan; bisa diatur di Setelan
        private val logs = ArrayList<String>()
        private val servers = ArrayList<String>()
        private var noteEmail = ""
        private var noteId = ""
        private var prefs: SharedPreferences? = null
        private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

        // Muat log dan daftar server yang tersimpan
        fun initStore(ctx: Context) {
            synchronized(logs) {
                if (prefs != null) return
                val p = ctx.applicationContext.getSharedPreferences("ats_store", Context.MODE_PRIVATE)
                prefs = p
                val l = p.getString("logs", "") ?: ""
                if (l.isNotEmpty()) logs.addAll(l.split("\n"))
                val s = p.getString("servers", "") ?: ""
                if (s.isNotEmpty()) servers.addAll(s.split("\n"))
                noteEmail = p.getString("noteEmail", "") ?: ""
                noteId = p.getString("noteId", "") ?: ""
            }
        }

        private fun persist() {
            prefs?.edit()
                ?.putString("logs", logs.joinToString("\n"))
                ?.putString("servers", servers.joinToString("\n"))
                ?.putString("noteEmail", noteEmail)
                ?.putString("noteId", noteId)
                ?.apply()
        }

        private fun sessionCount(): Int = logs.count { it.contains(MARK) }

        // Buang satu sesi utuh yang paling lama (bukan baris acak)
        private fun trimLogs() {
            while (logs.size > MAX_LINES || sessionCount() > MAX_SESSIONS) {
                var idx = -1
                for (i in 1 until logs.size) {
                    if (logs[i].contains(MARK)) {
                        idx = i
                        break
                    }
                }
                if (idx > 0) {
                    for (k in 0 until idx) logs.removeAt(0)
                } else {
                    logs.removeAt(0)
                }
            }
        }

        fun addLog(s: String) {
            synchronized(logs) {
                logs.add(fmt.format(Date()) + "  " + s)
                trimLogs()
                persist()
            }
        }

        // Catatan umum: nomor server dan nickname-nya (nama apk tidak ditampilkan di sini; apk ada di log sesi)
        private val serverKeys = ArrayList<Int>()
        private val serverNicks = HashMap<Int, String>()

        private fun rebuildServers() {
            servers.clear()
            serverKeys.forEach { k ->
                val n = serverNicks[k]
                servers.add(if (n.isNullOrEmpty()) "$k" else "$k  $n")
            }
        }

        // Simpan daftar server, urut dari kecil ke besar
        fun setServers(map: Map<Int, String>) {
            synchronized(logs) {
                serverKeys.clear()
                serverKeys.addAll(map.keys.sorted())
                rebuildServers()
                persist()
            }
        }

        // Nickname yang diterima game untuk satu server
        fun setServerNick(server: Int, nick: String) {
            synchronized(logs) {
                serverNicks[server] = nick
                rebuildServers()
                persist()
            }
        }

        fun clearServerNicks() {
            synchronized(logs) {
                serverNicks.clear()
            }
        }

        // Hapus log dan daftar server (tidak bisa saat sedang berjalan)
        fun clearAll(): Boolean {
            if (running) return false
            synchronized(logs) {
                logs.clear()
                servers.clear()
                serverKeys.clear()
                serverNicks.clear()
                noteEmail = ""
                noteId = ""
                persist()
            }
            found = 0
            done = 0
            total = 0
            phase = "Siap"
            return true
        }

        // Nomor baris tempat tiap sesi dimulai (urutan sama dengan di tampilan)
        private fun sessionStarts(): List<Int> {
            val st = ArrayList<Int>()
            if (logs.isNotEmpty() && !logs[0].contains(MARK)) st.add(0)
            for (i in logs.indices) {
                if (logs[i].contains(MARK)) st.add(i)
            }
            return st
        }

        // Hapus hanya sesi terakhir. Arsip dan daftar server tidak disentuh.
        fun clearLastSession(): Boolean {
            if (running) return false
            synchronized(logs) {
                val st = sessionStarts()
                if (st.isNotEmpty()) {
                    logs.subList(st.last(), logs.size).clear()
                    persist()
                }
            }
            return true
        }

        // Hapus satu sesi arsip (nomor sesi mulai dari 0)
        fun deleteSession(n: Int): Boolean {
            if (running) return false
            synchronized(logs) {
                val st = sessionStarts()
                if (n < 0 || n >= st.size) return false
                val from = st[n]
                val to = if (n + 1 < st.size) st[n + 1] else logs.size
                logs.subList(from, to).clear()
                persist()
            }
            return true
        }

        // Hapus semua arsip, sesi terakhir tetap ada
        fun clearArchive(): Boolean {
            if (running) return false
            synchronized(logs) {
                val st = sessionStarts()
                if (st.size > 1) {
                    logs.subList(0, st.last()).clear()
                    persist()
                }
            }
            return true
        }

        // Hapus hanya daftar server
        fun clearServers(): Boolean {
            if (running) return false
            synchronized(logs) {
                servers.clear()
                serverKeys.clear()
                serverNicks.clear()
                noteEmail = ""
                noteId = ""
                persist()
            }
            found = 0
            return true
        }

        // Salinan log & daftar server untuk tampilan native
        fun logsSnapshot(): List<String> = synchronized(logs) { ArrayList(logs) }

        fun serversSnapshot(): List<String> = synchronized(logs) { ArrayList(servers) }

        // Catatan umum: email (kalau dikaitkan) dan ID akun. Satu per sesi.
        fun notesSnapshot(): Pair<String, String> = synchronized(logs) { Pair(noteEmail, noteId) }

        fun noteIdNow(): String = synchronized(logs) { noteId }

        fun setNoteId(id: String) {
            synchronized(logs) {
                noteId = id
                persist()
            }
        }

        fun setNoteEmail(e: String) {
            synchronized(logs) {
                noteEmail = e
                persist()
            }
        }

        fun resetNotes() {
            synchronized(logs) {
                noteEmail = ""
                noteId = ""
                persist()
            }
        }

        fun statusJson(): String {
            val o = JSONObject()
            o.put("running", running)
            o.put("done", done)
            o.put("total", total)
            o.put("found", found)
            o.put("phase", phase)
            val arr = JSONArray()
            val srv = JSONArray()
            synchronized(logs) {
                logs.forEach { arr.put(it) }
                servers.forEach { srv.put(it) }
            }
            o.put("logs", arr)
            o.put("servers", srv)
            return o.toString()
        }
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var stopRequested = false
    private var capsule: TextView? = null

    // Pengaturan ketukan "Got it" (dibaca dari intent saat Mulai)
    @Volatile private var tapOn = false
    @Volatile private var tapMs = 4900L
    @Volatile private var tapX = 1200
    @Volatile private var tapY = 960
    @Volatile private var tapActive = false

    // Pengaturan OCR putaran 2 (dibaca dari intent saat Mulai)
    @Volatile private var ocrOn = true
    @Volatile private var ocrKeys: List<String> = listOf("Create Character")

    // Apk pertama putaran 1: tunggu popup "Info Sistem" lalu ketuk "Login kembali"
    // Matikan animasi sistem selama sesi (dikembalikan ke 1x setelah selesai)
    @Volatile private var animOff = true
    @Volatile private var animKeeping = false

    // Kaitkan otomatis (email ke akun Moonton) di akhir putaran 2
    @Volatile private var kaitkanOn = false
    @Volatile private var kaitkanEmail = ""
    @Volatile private var kaitkanActive = false

    // Email sudah berhasil dikaitkan di sesi ini (akunnya sah dan harus tetap dicatat walau sesi dihentikan sesudahnya)
    @Volatile private var kaitkanLinked = false

    // Isi nickname otomatis di putaran 2
    @Volatile private var nickOn = false
    @Volatile private var nickBase = "Ats-"
    @Volatile private var nickStart = 1

    @Volatile private var firstOn = true
    @Volatile private var firstMax = 10000L
    @Volatile private var afterTapMs = AFTER_LOGIN_TAP_MS
    @Volatile private var loginKeys: List<String> = listOf("Login kembali")

    override fun onCreate() {
        SwipeCfg.init(this)
        MemCfg.init(this)
        super.onCreate()
        initStore(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopRequested = true
            if (running) {
                // Beri tahu di notifikasi bahwa penghentian sedang diproses (tombol dihilangkan)
                try {
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.notify(1, buildNotification("Menghentikan...", false))
                } catch (e: Throwable) {
                }
            } else {
                stopSelf()
            }
            return START_NOT_STICKY
        }
        if (running || intent == null) return START_NOT_STICKY

        val pkgs = intent.getStringArrayExtra("pkgs") ?: emptyArray()
        val d1 = intent.getLongExtra("d1", 5700L)
        val d2 = intent.getLongExtra("d2", 25000L)
        val d3 = intent.getLongExtra("d3", 600L)
        val target = intent.getIntExtra("target", 0)
        val back = intent.getBooleanExtra("back", false)
        tapOn = intent.getBooleanExtra("tapOn", false)
        tapMs = maxOf(0L, intent.getLongExtra("tapMs", 4900L))
        tapX = intent.getIntExtra("tapX", 1200)
        tapY = intent.getIntExtra("tapY", 960)
        ocrOn = intent.getBooleanExtra("ocrOn", true)
        ocrKeys = TextMatch.parseKeys(intent.getStringExtra("ocrKeys") ?: "Create Character")
        // Popup login apk pertama: bawaan (tidak lagi diatur di Setelan), dikenali lewat OCR
        firstOn = true
        firstMax = 5700L
        afterTapMs = AFTER_LOGIN_TAP_MS
        loginKeys = TextMatch.parseKeys("Login kembali")
        animOff = intent.getBooleanExtra("animOff", true)
        nickOn = intent.getBooleanExtra("nickOn", false)
        nickBase = intent.getStringExtra("nickBase") ?: ""
        nickStart = intent.getIntExtra("nickStart", 1)
        kaitkanOn = intent.getBooleanExtra("kaitkanOn", false)
        kaitkanEmail = (intent.getStringExtra("kaitkanEmail") ?: "").trim()

        if (intent.getBooleanExtra("memTest", false)) {
            val cnt = intent.getIntExtra("memCount", 0)
            val n = if (cnt > 0) minOf(cnt, pkgs.size) else pkgs.size
            startAsForeground()
            running = true
            stopRequested = false
            Thread { runMemTest(pkgs.toList().take(n), d1) }.start()
            return START_NOT_STICKY
        }

        startAsForeground()
        running = true
        stopRequested = false
        Thread { runAll(pkgs.toList(), d1, d2, d3, target, back) }.start()
        return START_NOT_STICKY
    }

    // Gambar ikon aplikasi (latar hitam + logo putih) untuk notifikasi
    private fun appIconBitmap(): Bitmap? {
        return try {
            val d = getDrawable(R.mipmap.ic_launcher) ?: return null
            val size = 192
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            d.setBounds(0, 0, size, size)
            d.draw(c)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    // Notifikasi sesi. withStop = true: ada tombol "Berhenti" supaya sesi bisa dihentikan
    // tanpa membuka aplikasi. Ketuk badan notifikasi untuk membuka aplikasi.
    private fun buildNotification(text: String, withStop: Boolean): Notification {
        val b = Notification.Builder(this, "ats")
            .setContentTitle("Project ats")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notif)
            .setColor(Color.BLACK)
            .setOnlyAlertOnce(true)
        val big = appIconBitmap()
        if (big != null) b.setLargeIcon(big)

        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        b.setContentIntent(PendingIntent.getActivity(this, 6, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))

        if (withStop) {
            val stop = Intent(this, RunnerService::class.java).setAction("STOP")
            val pi = PendingIntent.getService(this, 7, stop, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), "Berhenti", pi).build())
        }
        return b.build()
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ats", "Project ats", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = buildNotification("Sedang berjalan", true)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // Tunggu sampai jam tertentu (uptime), dihitung dari jam sungguhan
    private fun sleepUntil(t: Long) {
        while (!stopRequested) {
            val left = t - SystemClock.uptimeMillis()
            if (left <= 0) break
            Thread.sleep(if (left > 50) 50L else left)
        }
    }

    private fun sleepMs(ms: Long) {
        sleepUntil(SystemClock.uptimeMillis() + ms)
    }

    private fun launch(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Pindah ke layar utama (home)
    private fun goHome() {
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_HOME)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    // Jalankan pekerjaan di thread terpisah dengan batas waktu,
    // supaya tidak pernah menggantung dan jatah waktu tetap seragam.
    private fun <T> limited(limit: Long, fallback: T, job: () -> T): T {
        val latch = CountDownLatch(1)
        var res: T = fallback
        val th = Thread {
            try {
                res = job()
            } catch (e: Throwable) {
            }
            latch.countDown()
        }
        th.isDaemon = true
        th.start()
        latch.await(limit, TimeUnit.MILLISECONDS)
        return res
    }

    // Tutup pembaca log di latar belakang (tidak menunda waktu aplikasi)
    private fun closeAsync(s: ShizukuHelper.ZoneStream?) {
        if (s == null) return
        val th = Thread {
            try {
                s.close()
            } catch (e: Throwable) {
            }
        }
        th.isDaemon = true
        th.start()
    }

    // Ketukan "Got it" di thread sendiri, N ms setelah aplikasi dibuka (dihitung dari t0).
    // Tidak menyentuh pembaca log. Batal kalau Hentikan ditekan atau jatah waktu habis.
    // Ketukan "Got it" (pengumuman di putaran 1): diketuk begitu tulisannya terbaca lewat OCR, SATU kali per aplikasi,
    // di dalam jatah waktu aplikasi itu. Posisi diambil dari kotak tulisannya; perkiraan 50% lebar, 88,9% tinggi hanya
    // dipakai kalau kotaknya tidak ada
    private val gotItArea = Area("got it", 0.30f, 0.80f, 0.70f, 0.98f)

    private fun watchGotIt(t0: Long, d1: Long) {
        val th = Thread {
            try {
                val end = t0 + d1 - 300L
                while (!stopRequested && SystemClock.uptimeMillis() < end) {
                    val svc = OcrA11yService.instance ?: return@Thread
                    val shot = svc.capture(1500L)
                    val b = shot.bmp ?: continue
                    val w = b.width
                    val h = b.height
                    val r = ScreenOcr.read(b, gotItArea, 1.0f)
                    if (!r.timedOut) b.recycle()
                    if (r.error != null) continue
                    val hit = TextMatch.find(r, listOf("Got it")) ?: continue
                    val box = hit.second.box
                    val x = box?.exactCenterX() ?: (0.5f * w)
                    val y = box?.exactCenterY() ?: (0.889f * h)
                    val ok = svc.tap(x, y)
                    addLog("Ketukan Got it: terbaca di ${SystemClock.uptimeMillis() - t0} ms, diketuk di (${x.toInt()}, ${y.toInt()}): " + (if (ok) "OK" else "GAGAL"))
                    return@Thread
                }
            } catch (e: Throwable) {
            }
        }
        th.isDaemon = true
        th.start()
    }

    private fun scheduleTap(t0: Long, d1: Long) {
        val ms = tapMs
        val x = tapX
        val y = tapY
        val th = Thread {
            try {
                addLog("Ketukan Got it: dijadwalkan $ms ms setelah dibuka (x=$x, y=$y)")
                sleepUntil(t0 + ms)
                if (stopRequested) {
                    addLog("Ketukan Got it dibatalkan: tombol Hentikan ditekan")
                    return@Thread
                }
                if (SystemClock.uptimeMillis() >= t0 + d1) {
                    addLog("Ketukan Got it dibatalkan: jatah waktu sudah habis")
                    return@Thread
                }
                val a = SystemClock.uptimeMillis() - t0
                val r = ShizukuHelper.tap(x, y, 2000L)
                val b = SystemClock.uptimeMillis() - t0
                addLog(
                    "Ketukan Got it: dikirim di $a ms, selesai di $b ms, hasil: " +
                        (if (r.first) "OK" else "gagal: " + r.second)
                )
            } catch (e: Throwable) {
            }
        }
        th.isDaemon = true
        th.start()
    }

    private fun nickOk(nick: String): Boolean = nick.isNotEmpty() && nick.none { it.code < 32 }

    // Awalan akun untuk sesi ini: diambil dari Stok nickname saat Mulai ditekan (kosong = pakai kolom Nickname manual)
    private var sessionPrefix = ""

    // Nickname untuk apk ke-idx: awalan sesi (dari stok, atau kolom manual) + nomor
    private fun plannedNick(idx: Int): String =
        (if (sessionPrefix.isNotEmpty()) sessionPrefix else nickBase) + (nickStart + idx)

    // Baca server dari logcat berdasarkan UID aplikasi, selama jatah waktunya.
    // Pembaca log dibuka segera, dicek tiap ~20 ms. Kalau gagal dibuka,
    // dicoba ulang maksimal 3 kali. Tidak ada cadangan lain.
    // Hasil: nomor server, atau null kalau tidak terbaca.
    private fun readUntil(pkg: String, uid: Int, t0: Long, wall: Long, deadline: Long): Int? =
        readUntilDyn(pkg, uid, t0, wall) { deadline }

    // Sama seperti readUntil, tapi batas waktunya dibaca ulang terus,
    // jadi bisa dipendekkan dari thread lain (dipakai apk pertama).
    private fun readUntilDyn(pkg: String, uid: Int, t0: Long, wall: Long, deadline: () -> Long): Int? {
        var stream: ShizukuHelper.ZoneStream? = null
        var opens = 0
        var lastLines = 0
        var lastHead = ""
        var lastPids = ""
        var lastOut = ""
        val reasons = ArrayList<String>()

        fun reason(s: String) {
            if (reasons.size < 5 && !reasons.contains(s)) reasons.add(s)
        }

        fun remember(st: ShizukuHelper.ZoneStream) {
            lastLines = st.lines
            lastHead = st.head
            lastPids = st.pids
            lastOut = st.outOfRange
        }

        try {
            while (!stopRequested) {
                val left = deadline() - SystemClock.uptimeMillis()
                if (left <= 0) break

                val st = stream
                if (st != null) {
                    val z = st.zone
                    if (z != null) {
                        val at = st.foundUptime - t0
                        val jam = if (st.logTime.isEmpty()) "-" else st.logTime
                        addLog("Baca log OK: server $z ketemu di $at ms (uid=$uid, jam pesan $jam, baris dibaca ${st.lines})")
                        closeAsync(st)
                        stream = null
                        return z
                    }
                    if (st.ended) {
                        remember(st)
                        reason("pembaca log berakhir sendiri (${st.lines} baris)")
                        closeAsync(st)
                        stream = null
                    } else {
                        sleepMs(minOf(20L, left))
                    }
                    continue
                }

                // Belum ada pembaca log yang jalan
                if (opens >= 3) {
                    reason("gagal dibuka 3 kali, tidak dicoba lagi")
                    while (!stopRequested && SystemClock.uptimeMillis() < deadline()) sleepMs(20L)
                    break
                }
                opens++
                val o = limited(
                    minOf(left - 20L, 1000L).coerceAtLeast(50L),
                    Pair<ShizukuHelper.ZoneStream?, String>(null, "terlalu lama")
                ) {
                    ShizukuHelper.openUidStream(uid, wall - 300L)
                }
                if (o.first != null) {
                    stream = o.first
                    addLog("Pembaca log dibuka di ${SystemClock.uptimeMillis() - t0} ms (uid=$uid, percobaan ke-$opens)")
                } else {
                    reason("buka pembaca log: " + o.second)
                    sleepMs(minOf(100L, maxOf(deadline() - SystemClock.uptimeMillis(), 0L)))
                }
            }
        } finally {
            val s = stream
            if (s != null) {
                remember(s)
                closeAsync(s)
            }
        }

        if (!stopRequested) {
            addLog("Baca log gagal: server tidak terbaca (uid=$uid, dibuka $opens kali, baris dibaca $lastLines)")
            addLog("  baris pertama keluaran: " + (if (lastHead.isEmpty()) "(kosong)" else lastHead))
            addLog("  PID terlihat: " + (if (lastPids.isEmpty()) "(tidak ada)" else lastPids))
            if (lastOut.isNotEmpty()) addLog("  angka di luar rentang: $lastOut")
            for (r in reasons) addLog("  alasan: $r")
        }
        return null
    }

    // Force stop + buang kartu dari recent apps lewat Shizuku, tanpa animasi.
    private fun dismiss(pkg: String) {
        if (!ShizukuHelper.hasPermission()) {
            addLog("Shizuku belum aktif/diizinkan, $pkg tidak dibersihkan")
            return
        }
        goHome()
        Thread.sleep(200)
        val ok = ShizukuHelper.forceStop(pkg)
        addLog(if (ok) "Force stop $pkg berhasil" else "Force stop $pkg gagal")
        val r = ShizukuHelper.removeFromRecents(pkg)
        addLog((if (r.first) "Recent $pkg: " else "Recent $pkg GAGAL: ") + r.second)
    }

    // Bersihkan aplikasi lalu tunggu sampai jeda tengah (waktu tetap)
    private fun cleanAndWait(pkg: String, d3: Long) {
        if (stopRequested) return
        val c0 = SystemClock.uptimeMillis()
        dismiss(pkg)
        val used = SystemClock.uptimeMillis() - c0
        if (used > d3) {
            addLog("Pembersihan butuh $used ms, melebihi jeda tengah $d3 ms")
        } else {
            sleepUntil(c0 + d3)
        }
    }

    // Buka satu aplikasi dan baca servernya selama jatah d1.
    // Hasil: (berhasil dibuka, nomor server atau null)
    // ID belum tercatat dan Aksesibilitas siap?
    private fun roleNeeded(): Boolean = noteIdNow().isEmpty() && OcrA11yService.instance != null

    private fun readRole(deadline: Long) {
        try {
            val id = RoleReader.readUntil(deadline) { stopRequested }
            if (id != null && noteIdNow().isEmpty()) {
                setNoteId(id)
                addLog("ID akun terbaca: $id")
                if (RoleReader.lastNote.isNotEmpty()) addLog("Peringatan ID: " + RoleReader.lastNote)
            }
        } catch (e: Throwable) {
        }
    }

    private fun openAndRead(pkg: String, d1: Long): Pair<Boolean, Int?> {
        // UID diambil sebelum aplikasi dibuka (cepat, tanpa Shizuku)
        var uid = -1
        var uidErr = ""
        try {
            uid = packageManager.getApplicationInfo(pkg, 0).uid
        } catch (e: Throwable) {
            uidErr = e.javaClass.simpleName + " " + (e.message ?: "")
        }

        val wall = System.currentTimeMillis()
        val t0 = SystemClock.uptimeMillis()
        if (!launch(pkg)) {
            addLog("Gagal buka $pkg")
            return Pair(false, null)
        }
        if (OcrA11yService.instance != null) watchGotIt(t0, d1)
        addLog("Buka $pkg")
        if (uid >= 0) {
            addLog("UID $pkg = $uid")
        } else {
            addLog("UID $pkg tidak bisa diambil: $uidErr")
        }

        val deadline = t0 + d1
        // ID akun (Role) dibaca sekali per sesi, bersamaan dengan pembacaan log, di dalam jatah waktu yang sama
        var roleThread: Thread? = null
        if (roleNeeded()) {
            roleThread = Thread { readRole(deadline) }
            roleThread.isDaemon = true
            roleThread.start()
        }
        val s: Int? = if (uid >= 0) readUntil(pkg, uid, t0, wall, deadline) else null
        // Walau sudah terbaca, tetap tunggu sampai jatah habis
        sleepUntil(deadline)
        try {
            roleThread?.join(1500L)
        } catch (e: InterruptedException) {
        }
        return Pair(true, s)
    }

    // Apk pertama putaran 1. Pembaca log jalan bersamaan dengan pemantau popup.
    // Popup muncul  -> ketuk "Login kembali", tunggu AFTER_LOGIN_TAP_MS (pembaca log
    //                  tetap jalan sampai saat itu), lalu:
    //                  server baru -> dicatat, aplikasi dibiarkan
    //                  kembar / tidak terbaca -> force stop + recent
    // Popup tidak muncul sampai firstMax -> force stop + recent (apa pun servernya).
    private fun firstApp(pkg: String, d3: Long, map: LinkedHashMap<Int, String>) {
        var uid = -1
        var uidErr = ""
        try {
            uid = packageManager.getApplicationInfo(pkg, 0).uid
        } catch (e: Throwable) {
            uidErr = e.javaClass.simpleName + " " + (e.message ?: "")
        }

        val wall = System.currentTimeMillis()
        val t0 = SystemClock.uptimeMillis()
        if (!launch(pkg)) {
            addLog("Gagal buka $pkg (apk pertama)")
            return
        }
        addLog("Buka $pkg (apk pertama, tunggu popup maksimal $firstMax ms)")
        if (uid >= 0) addLog("UID $pkg = $uid") else addLog("UID $pkg tidak bisa diambil: $uidErr")

        // Batas pembaca log: awalnya batas popup, dipendekkan setelah popup diketuk
        val cutoff = AtomicLong(t0 + firstMax)
        var server: Int? = null
        val reader = if (uid >= 0) Thread {
            server = readUntilDyn(pkg, uid, t0, wall) { cutoff.get() }
        } else null
        reader?.isDaemon = true
        reader?.start()

        val r = ScreenWatcher.waitAndTap(
            Targets.loginPopup(loginKeys),
            t0 + firstMax - SystemClock.uptimeMillis(),
            { stopRequested },
            { addLog("  $it") }
        )
        val popup = r is WatchResult.Found
        if (popup) {
            val tapAt = SystemClock.uptimeMillis()
            addLog("Popup terdeteksi, '${(r as WatchResult.Found).key}' diketuk di ${tapAt - t0} ms")
            cutoff.set(tapAt + afterTapMs)
            // Role baru muncul setelah login: dibaca selama menunggu setelah ketukan
            if (roleNeeded()) readRole(tapAt + afterTapMs)
            sleepUntil(tapAt + afterTapMs)
        } else if (!stopRequested) {
            addLog("Popup tidak muncul: " + ((r as? WatchResult.NotFound)?.reason ?: ""))
            sleepUntil(t0 + firstMax)
        }

        // Tunggu pembaca log selesai (sudah lewat batasnya, jadi singkat)
        try {
            reader?.join(maxOf(0L, cutoff.get() - SystemClock.uptimeMillis()) + 1500L)
        } catch (e: InterruptedException) {
        }
        if (stopRequested) return

        val s = server
        if (popup && s != null && !map.containsKey(s)) {
            map[s] = pkg
            found = map.size
            setServers(map)
            addLog("Server $s dicatat ($pkg)")
            addLog("Lanjut ke aplikasi berikutnya")
        } else {
            when {
                !popup && s != null -> addLog("Server $s diabaikan karena popup tidak muncul")
                s != null -> addLog("Server $s sudah ada")
                popup -> addLog("Server tidak terbaca sampai ${afterTapMs} ms setelah ketukan")
            }
            addLog("Bersihkan $pkg (force stop + recent)")
            cleanAndWait(pkg, d3)
        }
        addLog("Waktu apk pertama: ${SystemClock.uptimeMillis() - t0} ms")
    }

    // Penjaga animasi: cek pertama 5 detik setelah dimatikan, lalu tiap 10 detik selama sesi.
    // Kalau ada yang mengembalikan skala animasi dari 0, diterapkan ulang.
    private fun startAnimKeeper() {
        animKeeping = true
        val th = Thread {
            try {
                var first = true
                while (animKeeping && running) {
                    var waited = 0L
                    val wait = if (first) 5000L else 10000L
                    while (waited < wait && animKeeping && running) {
                        Thread.sleep(250)
                        waited += 250
                    }
                    if (!animKeeping || !running) break
                    AnimScale.keep(this, first) { addLog(it) }
                    first = false
                }
            } catch (e: Throwable) {
            }
        }
        th.isDaemon = true
        th.start()
    }

    // Pembungkus: apa pun yang terjadi di dalam sesi, animasi sistem dikembalikan di akhir
    private fun runAll(pkgs: List<String>, d1: Long, d2: Long, d3: Long, target: Int, back: Boolean) {
        try {
            runAllInner(pkgs, d1, d2, d3, target, back)
        } finally {
            OcrA11yService.instance?.hideDot()
            animKeeping = false   // hentikan penjaga dulu, baru dikembalikan
            if (AnimScale.isPending(this)) AnimScale.restore(this) { addLog(it) }
        }
    }

    private fun runAllInner(pkgs: List<String>, d1: Long, d2: Long, d3: Long, target: Int, back: Boolean) {
        done = 0
        found = 0
        total = pkgs.size
        val map = LinkedHashMap<Int, String>()
        clearServerNicks()
        setServers(map)
        resetNotes()

        addLog("$MARK ${dateFmt.format(Date())} =====")
        // Titik melayang dipasang saat proses mulai, dilepas saat selesai
        OcrA11yService.instance?.showDot()
        addLog("Jeda 1 = $d1 ms, jeda 2 = $d2 ms, jeda tengah = $d3 ms, target = $target")
        if (ocrOn && ocrKeys.isEmpty()) {
            ocrOn = false
            addLog("OCR putaran 2 dimatikan: kata kunci kosong")
        }
        if (ocrOn) {
            addLog("OCR putaran 2 aktif, kata kunci: " + ocrKeys.joinToString(", ") + " (jeda 2 = batas maksimal)")
            if (OcrA11yService.instance == null) {
                addLog("PERINGATAN: Aksesibilitas belum aktif, putaran 2 akan memakai jeda 2 tetap")
            }
            val w = Thread { ScreenOcr.warmUp() }
            w.isDaemon = true
            w.start()
        } else {
            addLog("OCR putaran 2 mati, pakai jeda 2 tetap")
        }

        sessionPrefix = ""
        kaitkanLinked = false
        failStop = false
        val topPrefix = if (NickStock.stockOn(this@RunnerService)) NickStock.top(this@RunnerService) else ""
        val baseNow = if (topPrefix.isNotEmpty()) topPrefix else nickBase
        if (nickOn) {
            if (!ocrOn) {
                nickOn = false
                addLog("Nickname otomatis dimatikan: OCR putaran 2 mati")
            } else if (!nickOk(baseNow + nickStart)) {
                nickOn = false
                addLog("Nickname otomatis dimatikan: nickname kosong atau berisi karakter kontrol")
            } else if (!ShizukuHelper.hasPermission()) {
                nickOn = false
                addLog("Nickname otomatis dimatikan: Shizuku belum diizinkan")
            } else {
                if (topPrefix.isNotEmpty()) {
                    // Mulai ditekan: awalan teratas diambil untuk sesi ini dan langsung keluar dari stok
                    sessionPrefix = NickStock.popTop(this@RunnerService)
                    addLog("Nickname otomatis aktif: awalan sesi ini $sessionPrefix (dari Stok nickname, sisa ${NickStock.stock(this@RunnerService).size}), nama $sessionPrefix$nickStart, $sessionPrefix${nickStart + 1}, dst")
                } else {
                    addLog("Nickname otomatis aktif: $nickBase$nickStart, $nickBase${nickStart + 1}, dst")
                }
                if (NameFiller.needsPaste(baseNow)) {
                    addLog("Nickname berisi karakter khusus, akan diisi lewat clipboard (tempel)")
                }
            }
        }
        kaitkanActive = false
        if (kaitkanOn) {
            if (!nickOn) {
                addLog("Kaitkan otomatis dimatikan: Nickname otomatis tidak aktif")
            } else if (kaitkanEmail.isEmpty()) {
                addLog("Kaitkan otomatis dilewati: tidak ada email (kolom kosong, stok kosong atau mati)")
            } else if (kaitkanEmail.indexOf('@') < 1) {
                addLog("Kaitkan otomatis dilewati: email tidak valid")
            } else {
                kaitkanActive = true
                addLog("Kaitkan otomatis aktif: $kaitkanEmail")
            }
        }
        if (firstOn && loginKeys.isEmpty()) {
            firstOn = false
            addLog("Popup apk pertama dimatikan: teks tombol kosong")
        }
        if (firstOn) {
            addLog("Apk pertama: tunggu popup maks $firstMax ms, ketuk: " + loginKeys.joinToString(", ") + ", tunggu $afterTapMs ms setelah ketuk")
            if (OcrA11yService.instance == null) {
                addLog("PERINGATAN: Aksesibilitas belum aktif, popup apk pertama tidak bisa dideteksi")
            }
        }

        tapActive = false
        addLog("Ketukan Got it: otomatis lewat OCR (diketuk begitu tulisan Got it terbaca)")

        if (!ShizukuHelper.hasPermission()) {
            addLog("Shizuku belum aktif/diizinkan. Buka Shizuku dan beri izin, lalu coba lagi.")
            phase = "Dihentikan"
            running = false
            main.post { stopSelf() }
            return
        }

        if (animOff) {
            AnimScale.disable(this) { addLog(it) }
            startAnimKeeper()
        }

        // Bersihkan RAM sebelum klon dibuka: buang proses latar aplikasi lain (am kill-all). Bisa dimatikan di Setelan
        if (MemCfg.killAll) {
            val s0 = MemCheck.sys()
            val ka = MemCheck.killAll()
            val s1 = MemCheck.sys()
            addLog("Bersihkan RAM (am kill-all): " + (if (ka.first) "berhasil" else "GAGAL " + ka.second) +
                (if (s0 != null && s1 != null) ", RAM tersedia ${s0.availMb} MB menjadi ${s1.availMb} MB" else ""))
        }

        // Putaran 1: tiap aplikasi dapat jatah waktu tetap (jeda 1).
        // Server kembar: dibersihkan, dibuka ulang SATU kali, lalu dicek lagi.
        phase = "Putaran 1"
        addLog("Mulai putaran 1 (${pkgs.size} aplikasi)")
        var rest = pkgs
        if (firstOn && pkgs.isNotEmpty() && !stopRequested) {
            firstApp(pkgs[0], d3, map)
            rest = pkgs.drop(1)
            done++
        }
        for (pkg in rest) {
            if (stopRequested) break
            if (target > 0 && map.size >= target) {
                addLog("Target $target server tercapai, sisa aplikasi dilewati")
                break
            }

            val tA = SystemClock.uptimeMillis()
            val first = openAndRead(pkg, d1)
            if (!first.first) {
                done++
                continue
            }
            val s1 = first.second

            if (s1 != null && !map.containsKey(s1)) {
                // Server baru: dicatat, TIDAK dibersihkan
                map[s1] = pkg
                found = map.size
                setServers(map)
                addLog("Server $s1 dicatat ($pkg)")
                addLog("Waktu aplikasi ini: ${SystemClock.uptimeMillis() - tA} ms")
            } else if (s1 == null) {
                // Tidak terbaca: langsung dibersihkan, tanpa percobaan ulang
                addLog("Server tidak terbaca, bersihkan $pkg")
                cleanAndWait(pkg, d3)
                addLog("Waktu aplikasi ini: ${SystemClock.uptimeMillis() - tA} ms")
            } else {
                // Server kembar: bersihkan, buka ulang satu kali
                addLog("Server $s1 sudah ada, bersihkan $pkg lalu coba buka ulang 1 kali")
                cleanAndWait(pkg, d3)
                addLog("Waktu aplikasi ini: ${SystemClock.uptimeMillis() - tA} ms")

                if (!stopRequested) {
                    val tB = SystemClock.uptimeMillis()
                    addLog("Percobaan ulang $pkg (server sebelumnya $s1)")
                    val second = openAndRead(pkg, d1)
                    val s2 = second.second
                    if (!second.first) {
                        addLog("Percobaan ulang gagal membuka $pkg")
                    } else if (s2 != null && !map.containsKey(s2)) {
                        map[s2] = pkg
                        found = map.size
                        setServers(map)
                        addLog("Percobaan ulang: server baru $s2")
                        addLog("Server $s2 dicatat ($pkg)")
                    } else {
                        if (s2 == null) {
                            addLog("Percobaan ulang: server tidak terbaca, bersihkan $pkg")
                        } else {
                            addLog("Percobaan ulang: server $s2 sudah ada, bersihkan $pkg")
                        }
                        cleanAndWait(pkg, d3)
                    }
                    addLog("Waktu percobaan ulang: ${SystemClock.uptimeMillis() - tB} ms")
                }
            }
            done++
        }

        // Putaran 2
        if (!stopRequested) {
            val list = map.entries.sortedBy { it.key }
            phase = "Putaran 2"
            done = 0
            total = list.size
            addLog("Mulai putaran 2 (${list.size} server, kecil ke besar)")
            var nameActive = nickOn
            val levelUps = ArrayList<Pair<Int, String>>()
            // Aturan 1: server yang belum dinamai (indeks apk di daftar, nomor server).
            // Aturan 2: server yang berhenti di halaman "Select a hero"
            val unnamed = ArrayList<Pair<Int, Int>>()
            val selectHero = ArrayList<Int>()
            // Nomor nama mengikuti URUTAN apk di putaran 2 (bukan jumlah yang berhasil)
            for ((idx, e) in list.withIndex()) {
                if (stopRequested) break
                val t0 = SystemClock.uptimeMillis()
                val deadline = t0 + d2
                if (launch(e.value)) {
                    addLog("Buka server ${e.key} (${e.value})")
                    if (ocrOn) {
                        val r = ScreenWatcher.waitFor(
                            Targets.createCharacter(ocrKeys),
                            deadline - SystemClock.uptimeMillis(),
                            { stopRequested },
                            { addLog("  $it") }
                        )
                        if (r is WatchResult.Found) {
                            addLog("Server ${e.key}: '${r.key}' terdeteksi di ${SystemClock.uptimeMillis() - t0} ms")
                            if (nameActive) {
                                val nick = plannedNick(idx)
                                val res = if (nickOk(nick)) NameFiller.fill(
                                    nick, r.screenW, r.screenH, true, ocrKeys, d2,
                                    { stopRequested }, { addLog("  $it") }
                                ) else null
                                if (res == null) {
                                    nameActive = false
                                    addLog("Server ${e.key}: nama '$nick' kosong atau berisi karakter kontrol. Penamaan berhenti, putaran 2 lanjut tanpa isi nama")
                                } else if (res.ok) {
                                    setServerNick(e.key, nick)
                                    if (res.reason.contains("Select a hero")) selectHero.add(e.key)
                                    if (res.levelUp) levelUps.add(Pair(e.key, e.value))
                                    addLog("Server ${e.key}: nama '$nick' diterima (${res.reason}), lanjut")
                                } else if (!stopRequested) {
                                    if (res.stopNaming) {
                                        nameActive = false
                                        addLog("Server ${e.key}: nama '$nick' gagal (${res.reason}). Penamaan berhenti, putaran 2 lanjut tanpa isi nama")
                                    } else {
                                        addLog("Server ${e.key}: nama '$nick' gagal (${res.reason}). Apk ini dilewati, penamaan lanjut ke berikutnya")
                                        unnamed.add(Pair(idx, e.key))
                                    }
                                }
                            } else {
                                addLog("Server ${e.key}: lanjut")
                            }
                        } else if (r is WatchResult.NotFound) {
                            addLog("Server ${e.key}: tidak terdeteksi (${r.reason})")
                            if (nameActive && !stopRequested) {
                                addLog("Server ${e.key}: tidak diberi nama ${plannedNick(idx)} (tidak sampai Create Character), penamaan lanjut ke berikutnya")
                                unnamed.add(Pair(idx, e.key))
                            }
                            sleepUntil(deadline)
                        }
                    } else {
                        sleepUntil(deadline)
                    }
                } else {
                    addLog("Gagal buka ${e.value}")
                    if (nameActive) {
                        addLog("Server ${e.key}: tidak diberi nama ${plannedNick(idx)} (tidak terbuka), penamaan lanjut ke berikutnya")
                        unnamed.add(Pair(idx, e.key))
                    }
                    sleepUntil(deadline)
                }
                done++
            }

            // Kaitkan otomatis: apk TERAKHIR (urutan putaran 2) yang sampai halaman Level Up
            if (kaitkanActive && !stopRequested) {
                if (levelUps.isEmpty()) {
                    addLog("Kaitkan otomatis dilewati: tidak ada apk yang sampai halaman Level Up")
                } else {
                    runKaitkan(levelUps.last(), list.lastOrNull()?.value, map, list.map { it.key }, unnamed, selectHero, d2)
                }
            }
        }

        // Kirim akun dan SEMUA server yang terbaca di putaran 1 ke Catatan Cabang (Level 1, keterangan kosong),
        // baik yang sampai Level Up, Select a hero, maupun yang tidak masuk putaran 2.
        // Sesi yang DIHENTIKAN tidak dicatat sama sekali (folder tidak terbentuk), kecuali email sudah berhasil dikaitkan
        if (stopRequested && !kaitkanLinked) {
            if (map.isNotEmpty()) addLog("Sesi dihentikan: tidak dicatat ke Catatan Cabang")
        } else if (map.isNotEmpty()) {
            val (em, id) = notesSnapshot()
            addLog(CatatanLink.sendAccount(this, em, id, map.keys.toList()))
        }

        val result = map.size
        if (back && !stopRequested) launch(packageName)
        phase = if (failStop) "Berhenti" else if (stopRequested) "Dihentikan" else "Selesai"
        if (!failStop) addLog(if (stopRequested) "Dihentikan" else "Selesai $result server")
        running = false

        if (stopRequested) {
            main.post { stopSelf() }
        } else {
            main.post { showCapsule("Selesai $result server") }
        }
    }

    // Jalankan alur Kaitkan otomatis di apk target. Sebelum ikon hadiah diketuk, di halaman Account dikerjakan dulu
    // aturan 1 (server yang belum dinamai) dan aturan 2 (apk "Select a hero")
    private fun runKaitkan(
        target: Pair<Int, String>,
        lastPkg: String?,
        map: LinkedHashMap<Int, String>,
        order: List<Int>,
        unnamed: List<Pair<Int, Int>>,
        selectHero: List<Int>,
        d2: Long
    ) {
        phase = "Kaitkan otomatis"
        done = 0
        total = Linker.STEPS
        addLog("Kaitkan otomatis: apk target ${target.second} (server ${target.first})")
        if (target.second != lastPkg) {
            if (!launch(target.second)) {
                addLog("Kaitkan otomatis gagal: ${target.second} tidak bisa dibuka")
                return
            }
            addLog("Membuka lagi ${target.second} (bukan apk terakhir)")
            sleepMs(1500L)
        }
        val linker = Linker(kaitkanEmail, { stopRequested }, { addLog("  $it") }, { done = it })
        val pre = linker.toAccount()
        if (stopRequested) return
        if (pre != null) {
            addLog("Kaitkan otomatis berhenti: ${pre.reason}")
            val pid0 = pre.profileId
            if (pid0 != null && noteIdNow().isEmpty()) {
                setNoteId(pid0)
                addLog("ID akun dari halaman Profil: $pid0")
            }
            return
        }
        if (unnamed.isNotEmpty() || selectHero.isNotEmpty()) {
            if (!fixServers(linker, map, order, target.first, unnamed, selectHero, d2)) return
            phase = "Kaitkan otomatis"
        }
        val res = linker.fromAccount()
        if (stopRequested) return
        val pid = res.profileId
        if (res.ok) {
            addLog("Kaitkan otomatis berhasil: ${res.reason}")
            addLog(EmailStock.markUsed(this, kaitkanEmail))
            setNoteEmail(kaitkanEmail)
            kaitkanLinked = true
        } else {
            addLog("Kaitkan otomatis berhenti: ${res.reason}")
        }
        if (pid != null) {
            val cur = noteIdNow()
            if (cur.isEmpty()) {
                setNoteId(pid)
                addLog("ID akun dari halaman Profil: $pid")
            } else if (cur != pid) {
                addLog("PERINGATAN: ID Role ($cur) berbeda dengan ID Profil ($pid), dipakai ID Profil")
                setNoteId(pid)
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Aturan 1 dan 2, dikerjakan di halaman Account (sebelum ikon hadiah diketuk). true = lanjut kaitkan, false = berhenti
    // ---------------------------------------------------------------------------------------------

    @Volatile private var failStop = false

    private fun fixFail(total: Int, why: String): Boolean {
        addLog("$total server: proses berhenti ($why)")
        phase = "Berhenti"
        failStop = true
        stopRequested = true
        return false
    }

    private fun onAccountPage(svc: OcrA11yService): Boolean {
        val s = svc.capture(1500L)
        val b = s.bmp ?: return false
        val r = ScreenOcr.read(b, Area.FULL, 0.6f)
        if (!r.timedOut) b.recycle()
        return r.error == null && TextMatch.matches(r.text, "ACCOUNT SETTINGS")
    }

    // Ketuk Switch Server di halaman Account lalu tunggu halaman Character List. Kalau daftar belum terbuka dalam 2,8 detik
    // DAN layar masih halaman Account, ketukannya kemungkinan tidak diterima: ketuk lagi (maks 4 kali)
    private fun openCharacterList(list: ServerList): Boolean {
        val svc = OcrA11yService.instance ?: return false
        for (attempt in 0 until 4) {
            if (stopRequested) return false
            if (attempt > 0 && !onAccountPage(svc)) {
                if (list.readList(3000L) != null) return true
                continue
            }
            val shot = svc.capture(1500L)
            val b = shot.bmp ?: continue
            val w = b.width
            val h = b.height
            val r = ScreenOcr.read(b, Area("tombol switch server", 0.70f, 0.58f, 0.95f, 0.82f), 0.8f)
            if (!r.timedOut) b.recycle()
            val box = if (r.error == null) TextMatch.find(r, listOf("Switch Server", "Ganti Server"))?.second?.box else null
            val x = box?.exactCenterX() ?: (0.807f * w)
            val y = box?.exactCenterY() ?: (0.677f * h)
            val ok = svc.tap(x, y)
            addLog("  ketuk Switch Server di halaman Account" + (if (attempt > 0) " (ulang $attempt)" else "") + ": " + (if (ok) "OK" else "GAGAL"))
            if (list.readList(2800L) != null) return true
        }
        return false
    }

    // Panah kembali dari Character List ke halaman Account. Diulang tiap 2,5 detik selama layar masih Character List
    private fun backToAccount(svc: OcrA11yService): Boolean {
        val shot = svc.capture(1500L)
        val b = shot.bmp ?: return false
        val w = b.width
        val h = b.height
        b.recycle()
        svc.tap(0.16f * w, 0.044f * h)
        var taps = 1
        var lastTap = SystemClock.uptimeMillis()
        val end = SystemClock.uptimeMillis() + 10000L
        while (!stopRequested && SystemClock.uptimeMillis() < end) {
            val s = svc.capture(1500L)
            val bb = s.bmp ?: continue
            val rr = ScreenOcr.read(bb, Area.FULL, 0.6f)
            if (!rr.timedOut) bb.recycle()
            if (rr.error != null) continue
            if (TextMatch.matches(rr.text, "ACCOUNT SETTINGS")) return true
            val inList = listOf("Character List", "All Servers", "Semua Server").any { TextMatch.matches(rr.text, it) }
            if (inList && taps < 4 && SystemClock.uptimeMillis() - lastTap >= 2500L) {
                svc.tap(0.16f * w, 0.044f * h)
                taps++
                lastTap = SystemClock.uptimeMillis()
            }
        }
        return false
    }

    private fun fixServers(
        linker: Linker,
        map: LinkedHashMap<Int, String>,
        order: List<Int>,
        currentServer: Int,
        unnamed: List<Pair<Int, Int>>,
        selectHero: List<Int>,
        d2: Long
    ): Boolean {
        val svc = OcrA11yService.instance ?: return fixFail(order.size, "Aksesibilitas mati")
        val list = ServerList(svc, { stopRequested }) { addLog("  $it") }
        val alive = ArrayList(order.sorted())
        val selectQueue = ArrayList(selectHero)

        // ---- Aturan 1: server yang belum dinamai ----
        for ((idx, srv) in unnamed.sortedBy { it.second }) {
            if (stopRequested) return false
            val pos = alive.indexOf(srv)
            if (pos < 0) continue
            val prev = if (pos > 0) alive[pos - 1] else 0
            val next = if (pos < alive.size - 1) alive[pos + 1] else null
            phase = "Aturan 1"
            addLog("Aturan 1: server $srv belum dinamai. Patokan: " + (if (prev > 0) "server $prev" else "baris paling atas") +
                ", sesudahnya " + (next?.toString() ?: "tidak ada"))
            if (!openCharacterList(list)) return fixFail(alive.size, "halaman Character List tidak terbuka")
            when (val loc = list.locateBelow(prev, next)) {
                is ServerList.Loc.Stopped -> return false
                is ServerList.Loc.Lost -> return fixFail(alive.size, "patokan server $prev tidak ditemukan: ${loc.why}")
                is ServerList.Loc.Missing -> {
                    alive.remove(srv)
                    map.remove(srv)
                    setServers(map)
                    addLog("Server $srv tidak ada di daftar karakter, dihapus dari Catatan Cabang")
                    if (!backToAccount(svc)) return fixFail(alive.size, "tidak kembali ke halaman Account")
                }
                is ServerList.Loc.Exists -> {
                    if (loc.row.num != srv) addLog("Catatan: baris di bawah patokan bernomor ${loc.row.num}, beda dari catatan ($srv)")
                    val err = list.selectAndSwitch(loc.row)
                    if (err != null) return fixFail(alive.size, "pindah ke server $srv gagal: $err")
                    val t = Targets.createCharacter(ocrKeys)
                    val tgt = ScreenTarget(t.name, t.keys, t.area, t.scale, popups = listOf(Popups.SWITCH_ACCOUNT, Popups.GOT_IT))
                    val r = ScreenWatcher.waitFor(tgt, 25000L, { stopRequested }, { addLog("  $it") })
                    if (stopRequested) return false
                    if (r !is WatchResult.Found) {
                        return fixFail(alive.size, "25 detik sesudah Okay, halaman Create Character tidak muncul")
                    }
                    val nick = plannedNick(idx)
                    addLog("Server $srv: Create Character terbaca, mengisi nama '$nick'")
                    val res = NameFiller.fill(nick, r.screenW, r.screenH, true, ocrKeys, d2, { stopRequested }, { addLog("  $it") })
                    if (stopRequested) return false
                    if (!res.ok) return fixFail(alive.size, "nama '$nick' di server $srv gagal: ${res.reason}")
                    setServerNick(srv, nick)
                    addLog("Server $srv: nama '$nick' diterima (${res.reason})")
                    if (!res.levelUp) return fixFail(alive.size, "server $srv tidak sampai halaman Level Up (${res.reason})")
                    val back = linker.toAccount()
                    if (stopRequested) return false
                    if (back != null) return fixFail(alive.size, "kembali ke halaman Account gagal: ${back.reason}")
                }
            }
        }

        // ---- Aturan 2: apk yang berhenti di "Select a hero" ----
        for (srv in selectQueue.sorted()) {
            if (stopRequested) return false
            if (!alive.contains(srv)) continue
            phase = "Aturan 2"
            addLog("Aturan 2: server $srv berhenti di Select a hero, masuk lagi lewat Switch Server")
            if (!openCharacterList(list)) return fixFail(alive.size, "halaman Character List tidak terbuka")
            when (val loc = list.locateNumber(srv)) {
                is ServerList.Loc.Stopped -> return false
                is ServerList.Loc.Missing -> return fixFail(alive.size, "server $srv tidak ada di daftar karakter")
                is ServerList.Loc.Lost -> return fixFail(alive.size, "server $srv tidak ditemukan: ${loc.why}")
                is ServerList.Loc.Exists -> {
                    val err = list.selectAndSwitch(loc.row)
                    if (err != null) return fixFail(alive.size, "pindah ke server $srv gagal: $err")
                    val tgt = ScreenTarget(
                        "Skip the Tutorial",
                        listOf("created accounts in other servers", "Skip the Tutorial"),
                        Area.FULL, 0.6f, popups = listOf(Popups.GOT_IT)
                    )
                    val r = ScreenWatcher.waitFor(tgt, 25000L, { stopRequested }, { addLog("  $it") })
                    if (stopRequested) return false
                    if (r !is WatchResult.Found) {
                        return fixFail(alive.size, "25 detik sesudah Okay, halaman Skip tutorial tidak muncul")
                    }
                    val sk = NameFiller.skipOnly(svc, r.screenW, r.screenH, 20000L, { stopRequested }, { addLog("  $it") })
                    if (stopRequested) return false
                    if (sk != 0) return fixFail(alive.size, "halaman Level Up tidak muncul sesudah Skip di server $srv")
                    addLog("Server $srv: Skip diketuk, halaman Level Up muncul")
                    val back = linker.toAccount()
                    if (stopRequested) return false
                    if (back != null) return fixFail(alive.size, "kembali ke halaman Account gagal: ${back.reason}")
                }
            }
        }
        return true
    }

    // ---------------------------------------------------------------------------------------------
    // Cek batas aplikasi latar: buka N klon, catat klon yang mati atau login ulang, lalu baca RAM tiap klon,
    // mampatkan, baca lagi. Hasil lengkap ke log (awalan [Cek]) dan ringkasannya ke dialog
    // ---------------------------------------------------------------------------------------------

    private fun cek(msg: String) = addLog("[Cek] $msg")

    private fun runMemTest(pk: List<String>, d1: Long) {
        try {
            memTestInner(pk, d1)
        } catch (e: Throwable) {
            cek("Uji berhenti karena galat: ${e.javaClass.simpleName} ${e.message ?: ""}")
        } finally {
            OcrA11yService.instance?.hideDot()
            animKeeping = false   // hentikan penjaga dulu, baru dikembalikan
            if (AnimScale.isPending(this)) AnimScale.restore(this) { cek(it) }
            running = false
            phase = if (stopRequested) "Dihentikan" else "Selesai"
            if (!stopRequested) launch(packageName)
            main.post { stopSelf() }
        }
    }

    private fun mb(kb: Long): Long = kb / 1024

    // Tutup klon: force stop lalu buang kartunya dari recent apps (sama seperti pembersihan sesi biasa)
    private fun closeAll(pk: List<String>) {
        var ok = 0
        for (p in pk) {
            if (ShizukuHelper.forceStop(p)) ok++
            ShizukuHelper.removeFromRecents(p)
        }
        cek("Tutup ${pk.size} klon: force stop berhasil $ok, kartu recent dibuang.")
    }

    private fun memTestInner(pk: List<String>, d1: Long) {
        phase = "Cek batas apk"
        done = 0
        found = 0
        total = pk.size
        cek("===== Cek batas aplikasi latar: buka ${pk.size} apk, jeda per apk $d1 ms =====")
        if (!ShizukuHelper.hasPermission()) {
            cek("Shizuku belum aktif atau diizinkan. Buka Shizuku, beri izin, lalu coba lagi.")
            memReport = "Shizuku belum aktif atau diizinkan, uji tidak bisa dijalankan."
            return
        }
        // Animasi sistem dimatikan selama uji dan dikembalikan sesudahnya (sama seperti sesi biasa)
        if (animOff) {
            AnimScale.disable(this) { cek(it) }
            startAnimKeeper()
        }
        val sys0 = MemCheck.sys()
        cek("HP: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}, RAM total ${sys0?.totalMb ?: 0} MB, batas zRAM/swap ${sys0?.swapTotalMb ?: 0} MB")
        for (l in MemCheck.limits()) cek("Batas Android: $l")

        // Bersih-bersih sebelum uji: tutup klon yang dipilih (juga dari recent) lalu buang proses latar lain
        closeAll(pk)
        val sA = MemCheck.sys()
        if (MemCfg.killAll) {
            val ka = MemCheck.killAll()
            val sB = MemCheck.sys()
            cek("am kill-all: " + (if (ka.first) "berhasil" else "GAGAL ${ka.second}") + ". RAM tersedia ${sA?.availMb ?: 0} MB menjadi ${sB?.availMb ?: 0} MB")
        } else {
            cek("am kill-all dimatikan di Setelan. RAM tersedia ${sA?.availMb ?: 0} MB")
        }
        sleepMs(1500L)
        val sStart = MemCheck.sys()
        OcrA11yService.instance?.showDot()

        // ---- Buka klon satu per satu, pantau yang mati atau login ulang ----
        val pid0 = LinkedHashMap<String, Int>()
        val lostAt = LinkedHashMap<String, String>()
        var firstLossAvail = -1L
        var firstLossIdx = -1
        var opened = 0
        for ((i, pkg) in pk.withIndex()) {
            if (stopRequested) break
            if (!launch(pkg)) {
                cek("Apk ke-${i + 1} $pkg tidak bisa dibuka")
                continue
            }
            opened++
            val t0 = SystemClock.uptimeMillis()
            watchGotIt(t0, d1)
            sleepUntil(t0 + d1)
            if (stopRequested) break
            val now = MemCheck.pidMap(pid0.keys + pkg)
            val pidNow = now[pkg]
            if (pidNow == null) cek("Apk ke-${i + 1} $pkg tidak punya proses sesudah dibuka") else pid0[pkg] = pidNow
            var lostNow = 0
            for ((p, old) in pid0.entries.toList()) {
                if (p == pkg) continue
                val cur = now[p]
                val no = pk.indexOf(p) + 1
                if (cur == null) {
                    lostNow++
                    lostAt[p] = "MATI"
                    pid0.remove(p)
                    cek("  apk ke-$no ($p) MATI saat apk ke-${i + 1} dibuka")
                } else if (cur != old) {
                    lostNow++
                    lostAt[p] = "LOGIN ULANG"
                    pid0[p] = cur
                    cek("  apk ke-$no ($p) LOGIN ULANG (PID $old menjadi $cur) saat apk ke-${i + 1} dibuka")
                }
            }
            val sy = MemCheck.sys()
            if (lostNow > 0 && firstLossIdx < 0) {
                firstLossIdx = i + 1
                firstLossAvail = sy?.availMb ?: -1L
            }
            cek("Apk ke-${i + 1}/${pk.size} dibuka: hidup ${pid0.size}, hilang total ${lostAt.size}. RAM tersedia ${sy?.availMb ?: 0} MB, zRAM terpakai ${sy?.swapUsedMb ?: 0} dari ${sy?.swapTotalMb ?: 0} MB")
            done = i + 1
        }

        // Sesudah klon terakhir dibuka: LANGSUNG kembali ke Project ats, baru membaca dan menulis. Kalau tidak, klon terakhir
        // yang masih di layar bisa terus berjalan sampai Create Character.
        launch(packageName)
        sleepMs(1500L)
        val sAfter = MemCheck.sys()
        if (!stopRequested) {
            sleepMs(1500L)
            val chk = MemCheck.pidMap(pid0.keys)
            for ((p, old) in pid0.entries.toList()) {
                val cur = chk[p]
                if (cur == null) {
                    lostAt[p] = "MATI"
                    pid0.remove(p)
                    cek("  apk ke-${pk.indexOf(p) + 1} ($p) MATI sesudah semua dibuka")
                } else if (cur != old) {
                    lostAt[p] = "LOGIN ULANG"
                    pid0[p] = cur
                    cek("  apk ke-${pk.indexOf(p) + 1} ($p) LOGIN ULANG sesudah semua dibuka")
                }
            }
        }

        // ---- RAM tiap klon yang masih hidup (semua proses tiap klon dijumlahkan) ----
        val orig = LinkedHashMap<String, MemCheck.Mem>()
        if (!stopRequested && pid0.isNotEmpty()) {
            cek("Membaca RAM ${pid0.size} apk yang masih hidup (semua proses tiap apk dijumlahkan). RAM tersedia ${MemCheck.sys()?.availMb ?: 0} MB")
            var first = true
            for (p in pid0.keys.toList()) {
                if (stopRequested) break
                var m = MemCheck.procMem(p)
                if (m == null) {
                    sleepMs(400L)
                    m = MemCheck.procMem(p)
                }
                val no = pk.indexOf(p) + 1
                if (m == null) {
                    cek("  apk ke-$no ($p): RAM tidak terbaca")
                    continue
                }
                orig[p] = m
                cek("  apk ke-$no ($p): PSS ${mb(m.pssKb)} MB, RSS ${mb(m.rssKb)} MB, di zRAM ${mb(m.swapKb)} MB, ${m.procs.size} proses")
                if (first) {
                    first = false
                    for (x in m.procs) cek("    proses: $x")
                }
            }
        }
        cek("Pemampatan memori (compact) dilewati: tidak didukung di HP ini.")

        // ---- Ringkasan ----
        val alive = pid0.size
        val lost = lostAt.size
        val avgPss = if (orig.isNotEmpty()) mb(orig.values.sumOf { it.pssKb }) / orig.size else 0L
        val avgSwap = if (orig.isNotEmpty()) mb(orig.values.sumOf { it.swapKb }) / orig.size else 0L
        val lines = ArrayList<String>()
        lines.add("Dibuka $opened dari ${pk.size} apk. Hidup $alive, hilang $lost (mati atau login ulang).")
        if (firstLossIdx > 0) {
            lines.add("Hilang pertama saat apk ke-$firstLossIdx dibuka, RAM tersedia saat itu $firstLossAvail MB.")
            val total0 = sys0?.totalMb ?: 0L
            if (total0 > 0 && firstLossAvail >= total0 / 6) {
                lines.add("RAM masih lega saat apk pertama hilang, jadi kemungkinan penyebabnya BATAS JUMLAH proses latar, bukan RAM.")
            } else if (firstLossAvail >= 0) {
                lines.add("RAM sudah tipis saat apk pertama hilang, jadi kemungkinan penyebabnya RAM habis.")
            }
        } else if (opened > 0 && !stopRequested) {
            lines.add("Tidak ada apk yang hilang selama uji.")
        }
        if (orig.isNotEmpty()) lines.add("Rata-rata tiap apk (semua proses): RAM PSS $avgPss MB dan zRAM $avgSwap MB.")
        if (sStart != null && sAfter != null && opened > 0) {
            val dAvail = (sStart.availMb - sAfter.availMb) / opened
            val dSwap = (sAfter.swapUsedMb - sStart.swapUsedMb) / opened
            lines.add("Dari sistem: tiap apk menambah zRAM sekitar $dSwap MB dan mengurangi RAM tersedia sekitar $dAvail MB.")
            // Kalau zRAM per apk yang terbaca kurang dari separuh catatan sistem, kemungkinan proses game tidak ikut terhitung
            if (orig.isNotEmpty() && dSwap > 0 && avgSwap * 2 < dSwap) {
                lines.add("PERINGATAN: pembacaan RAM per apk kemungkinan BELUM LENGKAP (zRAM terbaca sekitar $avgSwap MB per apk, sistem mencatat sekitar $dSwap MB). Proses game mungkin tidak ikut terhitung.")
            }
            if (dAvail > 0 || dSwap > 0) {
                val swapT = sys0?.swapTotalMb ?: 0L
                val byRam = if (dAvail > 0) sAfter.availMb / dAvail else Long.MAX_VALUE
                val bySwap = if (dSwap > 0 && swapT > 0) maxOf(0L, swapT - sAfter.swapUsedMb) / dSwap else Long.MAX_VALUE
                val more = minOf(byRam, bySwap)
                if (more != Long.MAX_VALUE) lines.add("Perkiraan masih muat sekitar $more apk lagi (dibatasi " + (if (byRam <= bySwap) "RAM" else "zRAM") + "), hitungan lurus dari uji ini.")
                val p48 = 48
                val availP = sStart.availMb - p48 * dAvail
                val swapP = sStart.swapUsedMb + p48 * dSwap
                lines.add("Contoh untuk $p48 apk: RAM tersedia sekitar $availP MB, zRAM terpakai sekitar $swapP MB dari batas $swapT MB.")
            }
        }
        if (stopRequested) lines.add("Uji dihentikan sebelum selesai, angkanya belum lengkap.")
        for (l in lines) cek(l)
        cek("RAM tersedia di akhir ${MemCheck.sys()?.availMb ?: 0} MB. Rincian per apk ada di log ini (awalan [Cek]).")

        // ---- Tutup semua klon (bawaan), juga dari recent ----
        if (MemCfg.closeAfter) {
            closeAll(pk)
        } else {
            cek("Klon dibiarkan terbuka (diatur di Setelan).")
        }
        memReport = lines.joinToString("\n\n") + "\n\nRincian per apk ada di Aktivitas (awalan [Cek])."
    }

    private fun showCapsule(text: String) {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        // Warna mengikuti tema yang dipilih di aplikasi (gelap atau terang)
        val pal = Themes.of(getSharedPreferences("ats_ui", Context.MODE_PRIVATE).getString("theme", "dark") != "light")
        val dens = resources.displayMetrics.density
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(pal.text)
        tv.textSize = 15f
        tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.setPadding((22 * dens).toInt(), (11 * dens).toInt(), (22 * dens).toInt(), (11 * dens).toInt())
        val bg = GradientDrawable()
        bg.setColor(pal.card)
        bg.cornerRadius = 200f
        bg.setStroke(maxOf(1, (1 * dens).toInt()), pal.borderStrong)
        tv.background = bg

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (resources.displayMetrics.heightPixels * 0.25).toInt()

        try {
            wm.addView(tv, lp)
            capsule = tv
        } catch (e: Exception) {
            stopSelf()
            return
        }
        tv.setOnClickListener { stopSelf() }
        main.postDelayed({ stopSelf() }, 2000)
    }

    private fun removeCapsule() {
        capsule?.let {
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (e: Exception) {
            }
        }
        capsule = null
    }

    override fun onDestroy() {
        stopRequested = true
        removeCapsule()
        running = false
        super.onDestroy()
    }
}
