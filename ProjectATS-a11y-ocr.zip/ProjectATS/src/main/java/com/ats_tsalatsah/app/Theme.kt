package com.ats_tsalatsah.app

import android.graphics.Color

// Satu set warna untuk satu tema.
class Palette(
    val dark: Boolean,
    val bg: Int,           // latar halaman
    val card: Int,         // latar kartu
    val border: Int,       // garis tipis kartu
    val borderStrong: Int, // garis tombol garis-tepi
    val text: Int,
    val muted: Int,        // teks pendukung
    val hint: Int,         // placeholder
    val primary: Int,      // tombol utama, tab aktif, saklar nyala
    val onPrimary: Int,    // teks di atas primary
    val dotOn: Int,        // titik status aktif
    val dotOff: Int,       // titik status mati
    val danger: Int,       // peringatan
    val field: Int,        // latar kolom isian
    val navBg: Int,        // latar menu bawah (sedikit transparan)
    val dim: Int,          // peredup di belakang lembar bawah
    val ground: Int,       // garis tanah putus-putus
    val track: Int         // jalur cincin progres
)

object Themes {
    private fun c(s: String) = Color.parseColor(s)

    // Kabut hutan
    val DARK = Palette(
        dark = true,
        bg = c("#0A0B0B"),
        card = c("#151717"),
        border = c("#262A2A"),
        borderStrong = c("#3A4040"),
        text = c("#E9ECEB"),
        muted = c("#8C9392"),
        hint = c("#5E6564"),
        primary = c("#D9DEDD"),
        onPrimary = c("#121414"),
        dotOn = c("#E9ECEB"),
        dotOff = c("#535353"),
        danger = c("#E5484D"),
        field = c("#0F1111"),
        navBg = c("#EB151717"),
        dim = c("#99000000"),
        ground = c("#535353"),
        track = c("#262A2A")
    )

    // Puncak salju
    val LIGHT = Palette(
        dark = false,
        bg = c("#F4F5F4"),
        card = c("#FFFFFF"),
        border = c("#E0E3E2"),
        borderStrong = c("#C9CDCC"),
        text = c("#141616"),
        muted = c("#6E7473"),
        hint = c("#A3A9A8"),
        primary = c("#3F4443"),
        onPrimary = c("#FFFFFF"),
        dotOn = c("#141616"),
        dotOff = c("#C2C6C5"),
        danger = c("#D93036"),
        field = c("#F7F8F7"),
        navBg = c("#F2FFFFFF"),
        dim = c("#4D141616"),
        ground = c("#8E9493"),
        track = c("#E3E6E5")
    )

    fun of(dark: Boolean): Palette = if (dark) DARK else LIGHT
}
