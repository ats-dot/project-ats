package com.ats_tsalatsah.app

import android.content.Context
import android.graphics.Canvas
import android.view.MotionEvent
import android.widget.FrameLayout

// Wadah paling luar layar. Kalau ada error saat mengukur, menata,
// menggambar, atau menyentuh, error ditangkap dan dilaporkan
// (bukan membuat aplikasi tertutup sendiri).
class SafeFrame(ctx: Context, private val onError: (Throwable) -> Unit) : FrameLayout(ctx) {

    @Volatile private var failed = false

    private fun fail(e: Throwable) {
        if (failed) return
        failed = true
        post { onError(e) }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        try {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        } catch (e: Throwable) {
            setMeasuredDimension(
                MeasureSpec.getSize(widthMeasureSpec),
                MeasureSpec.getSize(heightMeasureSpec)
            )
            fail(e)
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        try {
            super.onLayout(changed, left, top, right, bottom)
        } catch (e: Throwable) {
            fail(e)
        }
    }

    override fun dispatchDraw(canvas: Canvas) {
        try {
            super.dispatchDraw(canvas)
        } catch (e: Throwable) {
            fail(e)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        return try {
            super.dispatchTouchEvent(ev)
        } catch (e: Throwable) {
            fail(e)
            true
        }
    }
}
