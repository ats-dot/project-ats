package com.ats_tsalatsah.app

import android.graphics.Bitmap
import android.graphics.Color

// Satu titik warna. x, y dalam pecahan layar 0..1. tol = selisih maksimal per kanal (0..255).
data class PixelProbe(val x: Float, val y: Float, val color: Int, val tol: Int = 40)

// Cek cepat tanpa OCR: tombol aktif/nonaktif, popup (layar gelap), ikon, badge.
// Jauh lebih cepat dan andal daripada OCR untuk angka satu digit, ikon, atau tulisan pudar.
object PixelCheck {

    fun at(bmp: Bitmap, xf: Float, yf: Float): Int {
        val x = (xf * bmp.width).toInt().coerceIn(0, bmp.width - 1)
        val y = (yf * bmp.height).toInt().coerceIn(0, bmp.height - 1)
        return bmp.getPixel(x, y)
    }

    fun near(a: Int, b: Int, tol: Int): Boolean =
        kotlin.math.abs(Color.red(a) - Color.red(b)) <= tol &&
            kotlin.math.abs(Color.green(a) - Color.green(b)) <= tol &&
            kotlin.math.abs(Color.blue(a) - Color.blue(b)) <= tol

    fun all(bmp: Bitmap, probes: List<PixelProbe>): Boolean =
        probes.all { near(at(bmp, it.x, it.y), it.color, it.tol) }

    // Kecerahan 0..255
    fun brightness(c: Int): Int =
        (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000

    // Rata-rata kecerahan dari grid titik sampel di area tertentu
    fun avgBrightness(bmp: Bitmap, area: Area = Area.FULL, grid: Int = 12): Int {
        val r = area.toRect(bmp.width, bmp.height)
        var sum = 0L
        var n = 0
        for (i in 0 until grid) {
            for (j in 0 until grid) {
                val x = r.left + (r.width() * (i + 0.5f) / grid).toInt()
                val y = r.top + (r.height() * (j + 0.5f) / grid).toInt()
                sum += brightness(bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1)))
                n++
            }
        }
        return if (n == 0) 0 else (sum / n).toInt()
    }

    // Popup biasanya membuat latar jadi gelap
    fun isDimmed(bmp: Bitmap, area: Area = Area.FULL, threshold: Int = 50): Boolean =
        avgBrightness(bmp, area) < threshold

    // Untuk mencari nilai warna titik saat menyusun PixelProbe
    fun describe(bmp: Bitmap, xf: Float, yf: Float): String {
        val c = at(bmp, xf, yf)
        return String.format("#%02X%02X%02X", Color.red(c), Color.green(c), Color.blue(c))
    }
}
