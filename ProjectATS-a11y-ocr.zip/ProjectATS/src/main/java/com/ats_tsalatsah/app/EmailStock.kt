package com.ats_tsalatsah.app

import android.content.Context

// Stok email untuk fitur Kaitkan otomatis. Dipakai bersama oleh tampilan dan layanan,
// disimpan di SharedPreferences supaya tidak hilang.
object EmailStock {

    private const val PREFS = "ats_email"

    // Naik tiap ada perubahan dari luar tampilan (misal layanan memakai email), supaya tampilan menyegarkan diri
    @Volatile var version = 0

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun stock(ctx: Context): List<String> {
        val s = p(ctx).getString("stock", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n").filter { it.isNotBlank() }
    }

    fun stockOn(ctx: Context): Boolean = p(ctx).getBoolean("stockOn", true)

    fun kaitkanOn(ctx: Context): Boolean = p(ctx).getBoolean("kaitkanOn", true)

    fun field(ctx: Context): String = p(ctx).getString("field", "") ?: ""

    private fun lastTop(ctx: Context): String = p(ctx).getString("lastTop", "") ?: ""

    fun top(ctx: Context): String = stock(ctx).firstOrNull() ?: ""

    // Email yang dipakai sesi berikutnya: isi kolom, atau (kalau kosong dan stok nyala) email paling atas
    fun effective(ctx: Context): String {
        val f = field(ctx).trim()
        if (f.isNotEmpty()) return f
        return if (stockOn(ctx)) top(ctx) else ""
    }

    // Kolom ikut email paling atas selama kolom kosong atau masih sama dengan email paling atas yang lama
    private fun resync(ctx: Context, stockNow: List<String>) {
        val ed = p(ctx).edit()
        val on = stockOn(ctx)
        val f = field(ctx)
        val newTop = stockNow.firstOrNull() ?: ""
        if (on && (f.isBlank() || f == lastTop(ctx))) ed.putString("field", newTop)
        ed.putString("lastTop", newTop)
        ed.apply()
    }

    fun setStock(ctx: Context, list: List<String>) {
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        resync(ctx, list)
        version++
    }

    fun setStockOn(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("stockOn", on).apply()
        if (on) resync(ctx, stock(ctx)) else p(ctx).edit().putString("lastTop", top(ctx)).apply()
        version++
    }

    fun setKaitkanOn(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("kaitkanOn", on).apply()
    }

    fun setField(ctx: Context, s: String) {
        p(ctx).edit().putString("field", s).apply()
    }

    // Pecah teks jadi email valid (ada @, tidak kembar). Hasil: (email valid, jumlah baris diabaikan)
    fun parse(text: String, existing: List<String>): Pair<List<String>, Int> {
        val seen = HashSet<String>()
        existing.forEach { seen.add(it.lowercase()) }
        val out = ArrayList<String>()
        var ign = 0
        for (raw in text.split("\n")) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            val k = l.lowercase()
            if (l.indexOf('@') > 0 && !l.contains(' ') && !seen.contains(k)) {
                seen.add(k)
                out.add(l)
            } else {
                ign++
            }
        }
        return Pair(out, ign)
    }

    // Dipanggil setelah halaman "Email verifikasi telah dikirim" muncul.
    // Email dari stok (sama dengan yang paling atas) dihapus; email manual tidak mengubah stok.
    // Kalau stok nyala, kolom kembali ke email paling atas. Hasil: keterangan untuk log.
    fun markUsed(ctx: Context, email: String): String {
        val list = ArrayList(stock(ctx))
        val on = stockOn(ctx)
        val fromStock = on && list.isNotEmpty() && list[0].equals(email, ignoreCase = true)
        val msg: String
        if (fromStock) {
            list.removeAt(0)
            p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
            msg = "Email dihapus dari stok. Sisa ${list.size} email."
        } else if (on) {
            msg = "Email dari kolom (manual): stok tidak berubah."
        } else {
            msg = "Stok mati: stok tidak disentuh."
        }
        if (on) {
            val nt = list.firstOrNull() ?: ""
            p(ctx).edit().putString("field", nt).putString("lastTop", nt).apply()
        }
        version++
        return msg
    }
}
