package com.ats_tsalatsah.app

import android.content.Context

// Stok nickname untuk fitur Nickname otomatis. Dipakai bersama oleh tampilan dan layanan,
// disimpan di SharedPreferences supaya tidak hilang. Tiap apk memakai nickname paling atas;
// nickname yang diterima game dihapus dari stok.
object NickStock {

    private const val PREFS = "ats_nick"

    // Naik tiap ada perubahan (dari tampilan maupun layanan), supaya tampilan menyegarkan diri
    @Volatile var version = 0

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun stock(ctx: Context): List<String> {
        val s = p(ctx).getString("stock", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n").filter { it.isNotBlank() }
    }

    fun stockOn(ctx: Context): Boolean = p(ctx).getBoolean("stockOn", true)

    fun top(ctx: Context): String = stock(ctx).firstOrNull() ?: ""

    // Kolom Nickname di tab Cabang (sama seperti kolom email Kaitkan otomatis): bisa diketik sendiri.
    // Selama kolom kosong atau masih sama dengan awalan paling atas yang lama, kolom ikut awalan paling atas stok.
    fun field(ctx: Context): String = p(ctx).getString("field", "") ?: ""

    private fun lastTop(ctx: Context): String = p(ctx).getString("lastTop", "") ?: ""

    fun setField(ctx: Context, s: String) {
        p(ctx).edit().putString("field", s).apply()
    }

    // Awalan yang dipakai sesi berikutnya: isi kolom, atau (kalau kolom kosong dan stok nyala) awalan paling atas
    fun effective(ctx: Context): String {
        val f = field(ctx).trim()
        if (f.isNotEmpty()) return f
        return if (stockOn(ctx)) top(ctx) else ""
    }

    // Kolom ikut awalan paling atas selama kolom kosong atau masih sama dengan awalan paling atas yang lama
    private fun resync(ctx: Context, stockNow: List<String>) {
        val ed = p(ctx).edit()
        val f = field(ctx)
        val newTop = stockNow.firstOrNull() ?: ""
        if (stockOn(ctx) && (f.isBlank() || f == lastTop(ctx))) ed.putString("field", newTop)
        ed.putString("lastTop", newTop)
        ed.apply()
    }

    // Sesudah awalan ketikan sendiri dipakai satu sesi (stok nyala dan ada isinya): kolom kembali ke awalan paling atas
    // stok, supaya sesi berikutnya tidak memakai awalan yang sama lagi (satu awalan = satu akun)
    @Synchronized
    fun fieldBackToTop(ctx: Context) {
        if (!stockOn(ctx)) return
        val t = top(ctx)
        if (t.isEmpty()) return
        p(ctx).edit().putString("field", t).putString("lastTop", t).apply()
        version++
    }

    // Sekali saja saat versi ini pertama dipakai: kolom diisi awalan paling atas (kalau stok nyala dan ada isinya),
    // atau nickname manual lama
    @Synchronized
    fun migrate(ctx: Context, legacy: String) {
        val sp = p(ctx)
        if (sp.contains("field")) return
        val t = if (stockOn(ctx)) top(ctx) else ""
        sp.edit().putString("field", if (t.isNotEmpty()) t else legacy).putString("lastTop", top(ctx)).apply()
        version++
    }

    @Synchronized
    fun setStock(ctx: Context, list: List<String>) {
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        resync(ctx, list)
        version++
    }

    @Synchronized
    fun setStockOn(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("stockOn", on).apply()
        if (on) resync(ctx, stock(ctx)) else p(ctx).edit().putString("lastTop", top(ctx)).apply()
        version++
    }

    // Stok berisi AWALAN per akun (misal "SCRP-"); nama tiap server = awalan + nomor. Layak masuk stok: 3 sampai 17 karakter
    // (nama akhir 4 sampai 20 karakter menurut aturan game, dengan nomor sampai 3 digit) dan tanpa karakter kontrol
    fun valid(line: String): Boolean {
        val n = line.codePointCount(0, line.length)
        return n in 3..17 && line.none { it.code < 32 }
    }

    // Dipanggil saat Mulai ditekan (kalau kolom kosong atau sama dengan awalan paling atas): awalan paling atas diambil
    // untuk satu sesi penuh dan langsung keluar dari stok; kolom pindah ke awalan berikutnya. Hasil kosong = stok kosong
    @Synchronized
    fun popTop(ctx: Context): String {
        val list = ArrayList(stock(ctx))
        if (list.isEmpty()) return ""
        val top = list.removeAt(0)
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        resync(ctx, list)
        version++
        return top
    }
}
