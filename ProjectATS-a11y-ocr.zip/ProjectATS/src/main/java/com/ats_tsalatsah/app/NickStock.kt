package com.ats_tsalatsah.app

import android.content.Context

// Stok nickname untuk fitur Nickname otomatis. Dipakai bersama oleh tampilan dan layanan,
// disimpan di SharedPreferences supaya tidak hilang. Tiap apk memakai nickname paling atas;
// nickname yang diterima game dihapus dari stok.
object NickStock {

    private const val PREFS = "ats_nick"

    // Naik tiap ada perubahan (dari tampilan maupun layanan), supaya tampilan menyegarkan diri
    @Volatile var version = 0

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun stock(ctx: Context): List<String> {
        val s = p(ctx).getString("stock", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n").filter { it.isNotBlank() }
    }

    fun stockOn(ctx: Context): Boolean = p(ctx).getBoolean("stockOn", true)

    fun top(ctx: Context): String = stock(ctx).firstOrNull() ?: ""

    @Synchronized
    fun setStock(ctx: Context, list: List<String>) {
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        version++
    }

    @Synchronized
    fun setStockOn(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("stockOn", on).apply()
        version++
    }

    // Stok berisi AWALAN per akun (misal "SCRP-"); nama tiap server = awalan + nomor. Layak masuk stok: 3 sampai 17 karakter
    // (nama akhir 4 sampai 20 karakter menurut aturan game, dengan nomor sampai 3 digit) dan tanpa karakter kontrol
    fun valid(line: String): Boolean {
        val n = line.codePointCount(0, line.length)
        return n in 3..17 && line.none { it.code < 32 }
    }

    // Dipanggil saat Mulai ditekan: awalan paling atas diambil untuk satu sesi penuh dan langsung keluar dari stok.
    // Hasil kosong = stok kosong
    @Synchronized
    fun popTop(ctx: Context): String {
        val list = ArrayList(stock(ctx))
        if (list.isEmpty()) return ""
        val top = list.removeAt(0)
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        version++
        return top
    }
}
