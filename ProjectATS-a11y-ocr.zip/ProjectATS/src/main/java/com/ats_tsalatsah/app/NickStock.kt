package com.ats_tsalatsah.app

import android.content.Context

// Stok nickname untuk fitur Nickname otomatis. Dipakai bersama oleh tampilan dan layanan,
// disimpan di SharedPreferences supaya tidak hilang. Tiap apk memakai nickname paling atas;
// nickname yang diterima game dihapus dari stok.
object NickStock {

    private const val PREFS = "ats_nick"

    // Naik tiap ada perubahan (dari tampilan maupun layanan), supaya tampilan menyegarkan diri
    @Volatile var version = 0

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun stock(ctx: Context): List<String> {
        val s = p(ctx).getString("stock", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n").filter { it.isNotBlank() }
    }

    fun stockOn(ctx: Context): Boolean = p(ctx).getBoolean("stockOn", true)

    fun top(ctx: Context): String = stock(ctx).firstOrNull() ?: ""

    @Synchronized
    fun setStock(ctx: Context, list: List<String>) {
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        version++
    }

    @Synchronized
    fun setStockOn(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("stockOn", on).apply()
        version++
    }

    // Layak masuk stok: 4 sampai 20 karakter (aturan game) dan tanpa karakter kontrol
    fun valid(line: String): Boolean {
        val n = line.codePointCount(0, line.length)
        return n in 4..20 && line.none { it.code < 32 }
    }

    // Dipanggil setelah game menerima nickname. Nickname dihapus dari stok. Hasil: keterangan untuk log
    @Synchronized
    fun markUsed(ctx: Context, nick: String): String {
        val list = ArrayList(stock(ctx))
        val i = list.indexOf(nick)
        if (i < 0) return "Nickname sudah tidak ada di stok."
        list.removeAt(i)
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        version++
        return "Nickname dihapus dari stok. Sisa ${list.size} nama."
    }

    // Nickname yang gagal dua kali berturut-turut dipindah ke paling bawah supaya apk berikutnya tidak macet di nama yang sama
    @Synchronized
    fun moveToEnd(ctx: Context, nick: String) {
        val list = ArrayList(stock(ctx))
        val i = list.indexOf(nick)
        if (i < 0) return
        list.removeAt(i)
        list.add(nick)
        p(ctx).edit().putString("stock", list.joinToString("\n")).apply()
        version++
    }
}
