package com.ats_tsalatsah.app

import android.graphics.Bitmap
import android.os.SystemClock

// Isi nama di halaman "Create Character":
// ketuk kolom nama -> hapus nama acak -> ketik nickname -> cek terbaca di bar ketik
// -> OKE di keyboard -> cek nama sudah masuk kolom game -> ketuk Okay emas
// -> tunggu sampai masuk halaman "Skip the Tutorial" atau "Select a hero".
// Kalau macet di Create Character, seluruh langkah diulang (maksimal 3 kali).
object NameFiller {

    // Posisi di layar mendatar, dalam pecahan lebar/tinggi layar (dari screenshot 2400x1080)
    private const val FIELD_X = 0.704f   // kolom nama
    private const val FIELD_Y = 0.410f
    private const val OKE_X = 0.9425f    // OKE di atas keyboard
    private const val OKE_Y = 0.2167f
    private const val OKAY_X = 0.7196f   // tombol Okay coklat keemasan
    private const val OKAY_Y = 0.7139f

    // Bar ketik putih di atas keyboard (tanpa tulisan OKE di kanan)
    private val BAR_TEXT = Area("kolom ketik", 0.03f, 0.12f, 0.88f, 0.33f)

    // Kolom nama di halaman Create Character (tanpa ikon dadu di kanan)
    private val GAME_FIELD = Area("kolom nama", 0.56f, 0.36f, 0.84f, 0.47f)

    // Layar yang muncul kalau nama diterima
    private val ACCEPT_KEYS = listOf(
        "Skip the Tutorial",
        "Select a hero",
        "created accounts in other servers"
    )

    private const val CLEAR_WAIT_MS = 3000L   // tunggu kolom selesai dikosongkan
    private const val TYPE_WAIT_MS = 3500L    // tunggu ketikan selesai muncul di bar
    private const val FIELD_WAIT_MS = 2000L   // tunggu nama muncul di kolom game
    private const val STUCK_MS = 4000L        // masih di Create Character selama ini = macet
    private const val MAX_ATTEMPTS = 3
    private const val MIN_RETRY_MS = 8000L    // sisa waktu minimal untuk mengulang

    class Result(val ok: Boolean, val reason: String)

    private const val OUT_OK = 0
    private const val OUT_RETRY = 1
    private const val OUT_FAIL = 2

    private class Att(val out: Int, val reason: String)
    private class Open(val opened: Boolean, val text: String)
    private class Wait(val code: Int, val text: String)   // 0 diterima, 1 macet, 2 habis waktu, 3 dihentikan

    // Samakan huruf yang sering tertukar oleh OCR (l/i -> 1, o -> 0), di kedua sisi
    private fun fold(s: String): String {
        val n = TextMatch.norm(s).replace(" ", "")
        val sb = StringBuilder(n.length)
        for (ch in n) {
            sb.append(
                when (ch) {
                    'l', 'i' -> '1'
                    'o' -> '0'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    // Bar ketik terbuka = dua titik di bar itu putih
    private fun barOpen(b: Bitmap): Boolean {
        val a = PixelCheck.brightness(PixelCheck.at(b, 0.5f, 0.21f))
        val c = PixelCheck.brightness(PixelCheck.at(b, 0.25f, 0.25f))
        return a > 225 && c > 225
    }

    // Tunggu bar ketik tertutup. true = tercapai.
    private fun waitBarClosed(svc: OcrA11yService, limitMs: Long, stop: () -> Boolean): Boolean {
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val open = barOpen(b)
            b.recycle()
            if (!open) return true
        }
        return false
    }

    // Tunggu bar ketik terbuka, dan baca teks di dalamnya dari screenshot yang sama
    private fun waitBarOpen(svc: OcrA11yService, limitMs: Long, stop: () -> Boolean): Open {
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            if (!barOpen(b)) {
                b.recycle()
                continue
            }
            val r = ScreenOcr.read(b, BAR_TEXT, 0.8f)
            if (!r.timedOut) b.recycle()
            return Open(true, if (r.error != null) "" else r.text.replace('\n', ' ').trim())
        }
        return Open(false, "")
    }

    // Baca teks di satu area. null kalau screenshot/OCR gagal.
    private fun readArea(svc: OcrA11yService, area: Area, scale: Float): String? {
        val s = svc.capture(1500L)
        val b = s.bmp ?: return null
        val r = ScreenOcr.read(b, area, scale)
        if (!r.timedOut) b.recycle()
        return if (r.error != null) null else r.text
    }

    private fun hasPopup(text: String): Boolean =
        Popups.SWITCH_ACCOUNT.keys.any { TextMatch.matches(text, it) }

    private fun closePopup(svc: OcrA11yService, sw: Int, sh: Int, log: (String) -> Unit) {
        val p = Popups.SWITCH_ACCOUNT
        val ok = svc.tap(p.tapX * sw, p.tapY * sh)
        log("popup ${p.name} terlihat, ketuk silang: " + (if (ok) "OK" else "GAGAL"))
    }

    // Cek sekali: ada popup yang menutupi? Kalau ya, tutup.
    private fun checkPopup(svc: OcrA11yService, sw: Int, sh: Int, log: (String) -> Unit) {
        val t = readArea(svc, Area.CREATE_TOP, 0.6f) ?: return
        if (hasPopup(t)) closePopup(svc, sw, sh, log)
    }

    // Sudah di halaman tujuan? Kembalikan teks kunci yang cocok, atau null.
    private fun quickAccepted(svc: OcrA11yService): String? {
        val t = readArea(svc, Area.FULL, 0.6f) ?: return null
        return ACCEPT_KEYS.firstOrNull { TextMatch.matches(t, it) }
    }

    // Setelah Okay: tunggu SAMPAI halaman tujuan muncul. Create Character hilang saja belum cukup
    // (bisa masih loading). Macet = Create Character terus terlihat selama STUCK_MS.
    private fun waitAccepted(
        svc: OcrA11yService,
        createKeys: List<String>,
        sw: Int,
        sh: Int,
        budgetMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Wait {
        val end = SystemClock.uptimeMillis() + budgetMs
        var stillSince = -1L
        var seen = ""
        while (!stop()) {
            val now = SystemClock.uptimeMillis()
            if (now >= end) return Wait(2, seen)
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val r = ScreenOcr.read(b, Area.FULL, 0.6f)
            if (!r.timedOut) b.recycle()
            if (r.error != null) continue
            seen = r.text.replace('\n', ' ').trim()

            if (hasPopup(r.text)) {
                closePopup(svc, sw, sh, log)
                stillSince = -1L
                continue
            }
            val hit = ACCEPT_KEYS.firstOrNull { TextMatch.matches(r.text, it) }
            if (hit != null) return Wait(0, hit)

            if (createKeys.any { TextMatch.matches(r.text, it) }) {
                val t = SystemClock.uptimeMillis()
                if (stillSince < 0) stillSince = t
                else if (t - stillSince >= STUCK_MS) return Wait(1, seen)
            } else {
                stillSince = -1L
            }
        }
        return Wait(3, seen)
    }

    // Satu percobaan penuh. submit = false: berhenti setelah nama terisi di kolom game (untuk tes).
    private fun attempt(
        svc: OcrA11yService,
        nick: String,
        sw: Int,
        sh: Int,
        submit: Boolean,
        createKeys: List<String>,
        budgetMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Att {
        val t0 = SystemClock.uptimeMillis()
        val sb = StringBuilder()
        fun mark(label: String, from: Long) {
            sb.append(label).append(' ').append(SystemClock.uptimeMillis() - from).append(" ms, ")
        }
        fun tapAt(fx: Float, fy: Float): Boolean = svc.tap(fx * sw, fy * sh)

        try {
            // 1. Ketuk kolom nama, tunggu bar ketik terbuka (sekalian baca nama lama)
            var a = SystemClock.uptimeMillis()
            var opened = false
            var old = ""
            for (k in 1..2) {
                if (stop()) return Att(OUT_FAIL, "dihentikan")
                if (!tapAt(FIELD_X, FIELD_Y)) return Att(OUT_FAIL, "ketukan ke kolom nama gagal")
                val o = waitBarOpen(svc, 1500L, stop)
                if (o.opened) {
                    opened = true
                    old = o.text
                    break
                }
                // Bar tidak terbuka: mungkin tertutup popup Switch Account
                checkPopup(svc, sw, sh, log)
            }
            mark("kolom", a)
            if (!opened) log("kolom ketik tidak terdeteksi, tetap dicoba")

            // 2. Hapus nama lama sebanyak panjangnya (+3), lalu TUNGGU sampai kolom kosong.
            //    Game memproses tombol pelan, jadi antreannya harus habis dulu.
            val oldF = fold(old)
            val delCount = if (opened && old.isNotEmpty()) (old.length + 3).coerceIn(6, 24) else 20
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            a = SystemClock.uptimeMillis()
            val c = ShizukuHelper.clearField(delCount, 4000L)
            if (!c.first) return Att(OUT_FAIL, "hapus nama gagal: " + c.second)

            var prev: String? = null
            var cur = ""
            var settled = false
            val clearEnd = SystemClock.uptimeMillis() + CLEAR_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < clearEnd) {
                val t = readArea(svc, BAR_TEXT, 0.8f) ?: continue
                cur = fold(t)
                if (cur.isEmpty() || (prev != null && cur == prev)) {
                    settled = true
                    break
                }
                prev = cur
            }
            mark("hapus ${delCount}x", a)
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!settled) return Att(OUT_RETRY, "kolom belum selesai dikosongkan (terbaca '$cur')")
            if (oldF.isNotEmpty() && cur.length >= oldF.length) {
                return Att(OUT_RETRY, "nama lama tidak terhapus (terbaca '$cur')")
            }

            // 3. Ketik nickname, lalu TUNGGU sampai muncul utuh di bar. Tidak diketik ulang.
            val want = fold(nick)
            a = SystemClock.uptimeMillis()
            val t = ShizukuHelper.inputText(nick, 4000L)
            if (!t.first) return Att(OUT_FAIL, "ketik nama gagal: " + t.second)

            var verified = false
            var lastRead = ""
            var prevT: String? = null
            var same = 0
            val typeEnd = SystemClock.uptimeMillis() + TYPE_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < typeEnd) {
                val tx = readArea(svc, BAR_TEXT, 0.8f) ?: continue
                lastRead = tx.replace('\n', ' ').trim()
                val f = fold(tx)
                if (f.contains(want) && f.length <= want.length + 2) {
                    verified = true
                    break
                }
                if (prevT != null && f == prevT) {
                    same++
                    if (same >= 2) break
                } else {
                    same = 0
                }
                prevT = f
            }
            mark("ketik", a)
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!verified) return Att(OUT_RETRY, "nama di bar tidak sesuai (terbaca '${lastRead.take(40)}')")

            // 4. Ketuk OKE di keyboard, tunggu bar ketik tertutup
            a = SystemClock.uptimeMillis()
            var closed = false
            for (k in 1..2) {
                if (stop()) return Att(OUT_FAIL, "dihentikan")
                if (!tapAt(OKE_X, OKE_Y)) return Att(OUT_FAIL, "ketukan ke OKE gagal")
                if (waitBarClosed(svc, 1500L, stop)) {
                    closed = true
                    break
                }
            }
            mark("OKE", a)
            if (!closed) log("kolom ketik belum tertutup setelah OKE, lanjut")

            // 5. Pastikan nama sudah masuk ke KOLOM GAME sebelum Okay diketuk.
            //    (Tanpa ini, Okay bisa terketuk saat game belum mencatat nama, lalu
            //     game menolak dengan pesan 'Name can only contain 4-20 characters'.)
            a = SystemClock.uptimeMillis()
            var gameOk = false
            var gameRead = ""
            val fieldEnd = SystemClock.uptimeMillis() + FIELD_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < fieldEnd) {
                val tx = readArea(svc, GAME_FIELD, 0.8f) ?: continue
                gameRead = tx.replace('\n', ' ').trim()
                if (fold(tx).contains(want)) {
                    gameOk = true
                    break
                }
            }
            mark("cek kolom", a)
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!gameOk) return Att(OUT_RETRY, "kolom nama di game belum berisi nama (terbaca '${gameRead.take(40)}')")

            if (!submit) {
                log("Nama '$nick' terisi: " + sb + "total ${SystemClock.uptimeMillis() - t0} ms")
                return Att(OUT_OK, "nama '$nick' terisi di kolom game (tidak diajukan)")
            }

            // 6. Ketuk tombol Okay emas
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!tapAt(OKAY_X, OKAY_Y)) return Att(OUT_FAIL, "ketukan ke Okay gagal")

            // 7. Tunggu sampai masuk halaman tujuan
            a = SystemClock.uptimeMillis()
            val left = (budgetMs - (a - t0)).coerceAtLeast(5000L)
            val w = waitAccepted(svc, createKeys, sw, sh, left, stop, log)
            return when (w.code) {
                0 -> {
                    mark("halaman", a)
                    log("Nama '$nick' diisi: " + sb + "total ${SystemClock.uptimeMillis() - t0} ms")
                    Att(OUT_OK, "layar '${w.text}' muncul")
                }
                1 -> Att(OUT_RETRY, "masih di Create Character setelah $STUCK_MS ms (teks layar: '${w.text.take(70)}')")
                2 -> Att(OUT_FAIL, "belum masuk halaman Skip/Select hero sampai batas waktu")
                else -> Att(OUT_FAIL, "dihentikan")
            }
        } catch (e: Throwable) {
            val root = e.cause ?: e
            return Att(OUT_FAIL, "error: ${root.javaClass.simpleName} ${root.message ?: ""}".trim())
        }
    }

    // maxWaitMs = total waktu yang boleh dipakai untuk satu apk (dipakai jeda putaran 2).
    fun fill(
        nick: String,
        sw: Int,
        sh: Int,
        submit: Boolean,
        createKeys: List<String>,
        maxWaitMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Result {
        val svc = OcrA11yService.instance ?: return Result(false, "Aksesibilitas mati")
        if (!ShizukuHelper.hasPermission()) return Result(false, "Shizuku belum diizinkan")
        if (sw <= 0 || sh <= 0) return Result(false, "ukuran layar tidak diketahui")

        val start = SystemClock.uptimeMillis()
        val tries = if (submit) MAX_ATTEMPTS else 1
        var last = "belum dicoba"
        var done = 0
        for (n in 1..tries) {
            if (stop()) return Result(false, "dihentikan")
            val left = maxWaitMs - (SystemClock.uptimeMillis() - start)
            if (n > 1) {
                if (left < MIN_RETRY_MS) break
                // Siapa tahu halaman tujuan sudah muncul (lambat) sejak percobaan sebelumnya
                val q = quickAccepted(svc)
                if (q != null) return Result(true, "layar '$q' muncul")
            }
            done = n
            val a = attempt(svc, nick, sw, sh, submit, createKeys, maxOf(left, 10000L), stop, log)
            when (a.out) {
                OUT_OK -> return Result(true, a.reason)
                OUT_FAIL -> return Result(false, a.reason)
                else -> {
                    last = a.reason
                    log("percobaan $n gagal: ${a.reason}, diulang")
                }
            }
        }
        return Result(false, "setelah $done percobaan: $last")
    }
}
