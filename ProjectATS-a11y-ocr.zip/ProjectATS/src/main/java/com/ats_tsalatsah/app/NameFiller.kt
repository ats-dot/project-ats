package com.ats_tsalatsah.app

import android.graphics.Bitmap
import android.os.SystemClock

// Isi nama di halaman "Create Character":
// ketuk kolom nama -> hapus nama acak -> ketik nickname -> cek terbaca di kolom
// -> ketuk OKE di keyboard -> ketuk tombol Okay emas -> tunggu halaman hilang.
object NameFiller {

    // Posisi di layar mendatar, dalam pecahan lebar/tinggi layar (dari screenshot 2400x1080)
    private const val FIELD_X = 0.704f   // kolom nama
    private const val FIELD_Y = 0.410f
    private const val OKE_X = 0.9425f    // OKE di atas keyboard
    private const val OKE_Y = 0.2167f
    private const val OKAY_X = 0.7196f   // tombol Okay coklat keemasan
    private const val OKAY_Y = 0.7139f

    // Bar ketik putih di atas keyboard (tanpa tulisan OKE di kanan)
    private val BAR_TEXT = Area("kolom ketik", 0.03f, 0.12f, 0.88f, 0.33f)

    // Layar yang muncul kalau nama diterima
    private val ACCEPT_KEYS = listOf(
        "Skip the Tutorial",
        "Select a hero",
        "created accounts in other servers"
    )

    const val ACCEPT_WAIT_MS = 3000L
    private const val CLEAR_WAIT_MS = 3000L   // tunggu kolom selesai dikosongkan
    private const val TYPE_WAIT_MS = 3500L    // tunggu ketikan selesai muncul di kolom

    class Result(val ok: Boolean, val reason: String)

    // Samakan huruf yang sering tertukar oleh OCR (l/i -> 1, o -> 0), di kedua sisi
    private fun fold(s: String): String {
        val n = TextMatch.norm(s).replace(" ", "")
        val sb = StringBuilder(n.length)
        for (ch in n) {
            sb.append(
                when (ch) {
                    'l', 'i' -> '1'
                    'o' -> '0'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    // Bar ketik terbuka = dua titik di bar itu putih
    private fun barOpen(b: Bitmap): Boolean {
        val a = PixelCheck.brightness(PixelCheck.at(b, 0.5f, 0.21f))
        val c = PixelCheck.brightness(PixelCheck.at(b, 0.25f, 0.25f))
        return a > 225 && c > 225
    }

    // Tunggu bar ketik terbuka (wantOpen) atau tertutup. true = tercapai.
    private fun waitBar(svc: OcrA11yService, wantOpen: Boolean, limitMs: Long, stop: () -> Boolean): Boolean {
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val open = barOpen(b)
            b.recycle()
            if (open == wantOpen) return true
        }
        return false
    }

    private class Open(val opened: Boolean, val text: String)

    // Tunggu bar ketik terbuka, dan baca teks di dalamnya dari screenshot yang sama
    // (jadi tidak butuh pembacaan tambahan untuk tahu panjang nama lama).
    private fun waitBarOpen(svc: OcrA11yService, limitMs: Long, stop: () -> Boolean): Open {
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            if (!barOpen(b)) {
                b.recycle()
                continue
            }
            val r = ScreenOcr.read(b, BAR_TEXT, 0.8f)
            if (!r.timedOut) b.recycle()
            return Open(true, if (r.error != null) "" else r.text.replace('\n', ' ').trim())
        }
        return Open(false, "")
    }

    // Baca teks di bar ketik. Hasil: (teks atau null kalau gagal)
    private fun readBar(svc: OcrA11yService): String? {
        val s = svc.capture(1500L)
        val b = s.bmp ?: return null
        val r = ScreenOcr.read(b, BAR_TEXT, 0.8f)
        if (!r.timedOut) b.recycle()
        return if (r.error != null) null else r.text
    }

    // submit = false: berhenti setelah OKE di keyboard (dipakai tombol tes, tidak mengetuk Okay).
    fun fill(
        nick: String,
        sw: Int,
        sh: Int,
        submit: Boolean,
        createKeys: List<String>,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Result {
        val svc = OcrA11yService.instance ?: return Result(false, "Aksesibilitas mati")
        if (!ShizukuHelper.hasPermission()) return Result(false, "Shizuku belum diizinkan")
        if (sw <= 0 || sh <= 0) return Result(false, "ukuran layar tidak diketahui")

        val t0 = SystemClock.uptimeMillis()
        val sb = StringBuilder()
        fun mark(label: String, from: Long) {
            sb.append(label).append(' ').append(SystemClock.uptimeMillis() - from).append(" ms, ")
        }
        fun tapAt(fx: Float, fy: Float): Boolean = svc.tap(fx * sw, fy * sh)

        try {
            // 1. Ketuk kolom nama, tunggu bar ketik terbuka (sekalian baca nama lama)
            var a = SystemClock.uptimeMillis()
            var opened = false
            var old = ""
            for (attempt in 1..2) {
                if (stop()) return Result(false, "dihentikan")
                if (!tapAt(FIELD_X, FIELD_Y)) return Result(false, "ketukan ke kolom nama gagal")
                val o = waitBarOpen(svc, 1500L, stop)
                if (o.opened) {
                    opened = true
                    old = o.text
                    break
                }
            }
            mark("kolom", a)
            if (!opened) log("kolom ketik tidak terdeteksi, tetap dicoba")

            // 2. Hapus nama lama sebanyak panjangnya (+3), lalu TUNGGU sampai kolom
            //    benar-benar kosong. Game memproses tombol pelan, jadi tidak boleh
            //    mengirim perintah berikutnya sebelum antreannya habis.
            val oldF = fold(old)
            val delCount = if (opened && old.isNotEmpty()) (old.length + 3).coerceIn(6, 24) else 20
            if (stop()) return Result(false, "dihentikan")
            a = SystemClock.uptimeMillis()
            val c = ShizukuHelper.clearField(delCount, 4000L)
            if (!c.first) return Result(false, "hapus nama gagal: " + c.second)

            var prev: String? = null
            var cur = ""
            var settled = false
            val clearEnd = SystemClock.uptimeMillis() + CLEAR_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < clearEnd) {
                val t = readBar(svc) ?: continue
                cur = fold(t)
                if (cur.isEmpty() || (prev != null && cur == prev)) {
                    settled = true
                    break
                }
                prev = cur
            }
            mark("hapus ${delCount}x", a)
            if (stop()) return Result(false, "dihentikan")
            if (!settled) return Result(false, "kolom belum selesai dikosongkan (terbaca '$cur')")
            if (oldF.isNotEmpty() && cur.length >= oldF.length) {
                return Result(false, "nama lama tidak terhapus (terbaca '$cur')")
            }

            // 3. Ketik nickname, lalu TUNGGU sampai muncul utuh di kolom. Tidak diulang.
            val want = fold(nick)
            a = SystemClock.uptimeMillis()
            val t = ShizukuHelper.inputText(nick, 4000L)
            if (!t.first) return Result(false, "ketik nama gagal: " + t.second)

            var verified = false
            var lastRead = ""
            var prevT: String? = null
            var same = 0
            val typeEnd = SystemClock.uptimeMillis() + TYPE_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < typeEnd) {
                val tx = readBar(svc) ?: continue
                lastRead = tx.replace('\n', ' ').trim()
                val f = fold(tx)
                if (f.contains(want) && f.length <= want.length + 2) {
                    verified = true
                    break
                }
                if (prevT != null && f == prevT) {
                    same++
                    if (same >= 2) break
                } else {
                    same = 0
                }
                prevT = f
            }
            mark("ketik", a)
            if (stop()) return Result(false, "dihentikan")
            if (!verified) return Result(false, "nama di kolom tidak sesuai (terbaca '${lastRead.take(40)}')")

            // 3. Ketuk OKE di keyboard, tunggu bar ketik tertutup
            a = SystemClock.uptimeMillis()
            var closed = false
            for (attempt in 1..2) {
                if (stop()) return Result(false, "dihentikan")
                if (!tapAt(OKE_X, OKE_Y)) return Result(false, "ketukan ke OKE gagal")
                if (waitBar(svc, false, 1500L, stop)) {
                    closed = true
                    break
                }
            }
            mark("OKE", a)
            if (!closed) log("kolom ketik belum tertutup setelah OKE, lanjut")

            if (!submit) {
                log("Nama '$nick' terisi: " + sb + "total ${SystemClock.uptimeMillis() - t0} ms")
                return Result(true, "nama '$nick' terisi di kolom (tidak diajukan)")
            }

            // 4. Ketuk tombol Okay emas
            if (stop()) return Result(false, "dihentikan")
            if (!tapAt(OKAY_X, OKAY_Y)) return Result(false, "ketukan ke Okay gagal")

            // 5. Tunggu halaman Create Character hilang (nama diterima)
            a = SystemClock.uptimeMillis()
            val end = a + ACCEPT_WAIT_MS
            var gone = 0
            var seen = ""
            while (!stop() && SystemClock.uptimeMillis() < end) {
                val s = svc.capture(1500L)
                val b = s.bmp ?: continue
                val r = ScreenOcr.read(b, Area.FULL, 0.6f)
                if (!r.timedOut) b.recycle()
                if (r.error != null) continue
                seen = r.text.replace('\n', ' ').trim()

                val hit = ACCEPT_KEYS.firstOrNull { TextMatch.matches(r.text, it) }
                if (hit != null) {
                    mark("diterima", a)
                    log("Nama '$nick' diisi: " + sb + "total ${SystemClock.uptimeMillis() - t0} ms")
                    return Result(true, "layar '$hit' muncul")
                }
                val still = createKeys.any { TextMatch.matches(r.text, it) }
                if (still) {
                    gone = 0
                } else {
                    gone++
                    if (gone >= 2) {
                        mark("diterima", a)
                        log("Nama '$nick' diisi: " + sb + "total ${SystemClock.uptimeMillis() - t0} ms")
                        return Result(true, "halaman Create Character hilang")
                    }
                }
            }
            if (stop()) return Result(false, "dihentikan")
            return Result(
                false,
                "halaman Create Character masih ada setelah $ACCEPT_WAIT_MS ms, nama kemungkinan ditolak" +
                    (if (seen.isEmpty()) "" else " (teks layar: '${seen.take(60)}')")
            )
        } catch (e: Throwable) {
            val root = e.cause ?: e
            return Result(false, "error: ${root.javaClass.simpleName} ${root.message ?: ""}".trim())
        }
    }
}
