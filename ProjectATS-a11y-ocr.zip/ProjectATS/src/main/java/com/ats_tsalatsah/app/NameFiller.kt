package com.ats_tsalatsah.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// Isi nama di halaman "Create Character":
// ketuk kolom nama -> hapus nama acak -> ketik nickname -> cek terbaca di bar ketik
// -> OKE di keyboard -> cek nama sudah masuk kolom game -> ketuk Okay emas
// -> tunggu sampai masuk halaman "Skip the Tutorial" atau "Select a hero".
// Kalau macet di Create Character, seluruh langkah diulang (maksimal 3 kali).
object NameFiller {

    // Posisi di layar mendatar, dalam pecahan lebar/tinggi layar (dari screenshot 2400x1080)
    private const val FIELD_X = 0.704f   // kolom nama
    private const val FIELD_Y = 0.410f
    private const val OKE_X = 0.9425f    // OKE di atas keyboard
    private const val OKE_Y = 0.2167f
    private const val OKAY_X = 0.7196f   // tombol Okay coklat keemasan
    private const val OKAY_Y = 0.7139f

    // Bar ketik putih di atas keyboard (tanpa tulisan OKE di kanan)
    private val BAR_TEXT = Area("kolom ketik", 0.03f, 0.12f, 0.88f, 0.33f)

    // Kolom nama di halaman Create Character (tanpa ikon dadu di kanan)
    private val GAME_FIELD = Area("kolom nama", 0.56f, 0.36f, 0.84f, 0.47f)

    private const val SKIP_X = 0.8075f   // tombol Skip emas di halaman "Skip the Tutorial"
    private const val SKIP_Y = 0.6861f

    // Halaman "Level Up" (angka level + tombol Continue) yang muncul setelah Skip
    private val LEVEL_KEYS = listOf("Level Up")

    // Layar yang muncul kalau nama diterima
    private val ACCEPT_KEYS = listOf(
        "Skip the Tutorial",
        "Select a hero",
        "created accounts in other servers"
    )

    private const val CLEAR_WAIT_MS = 3000L   // tunggu kolom selesai dikosongkan
    private const val TYPE_WAIT_MS = 3500L    // tunggu ketikan selesai muncul di bar
    private const val FIELD_WAIT_MS = 2000L   // tunggu nama muncul di kolom game
    private const val STUCK_MS = 4000L        // masih di Create Character selama ini = macet
    private const val MAX_ATTEMPTS = 3
    private const val MIN_RETRY_MS = 8000L    // sisa waktu minimal untuk mengulang

    // stopNaming = true: masalahnya berat (ditolak game, Shizuku/Aksesibilitas bermasalah), jadi
    // penamaan dihentikan. false: hanya apk ini yang gagal, penamaan lanjut ke apk berikutnya.
    class Result(val ok: Boolean, val reason: String, val stopNaming: Boolean = true) {
        // true = apk ini sampai ke halaman Level Up (setelah nama diterima dan Skip diketuk)
        val levelUp: Boolean get() = ok && reason.contains("halaman Level Up muncul")
    }

    private const val OUT_OK = 0
    private const val OUT_RETRY = 1
    private const val OUT_FAIL = 2

    private class Att(val out: Int, val reason: String, val stuck: Boolean = false)
    private class Open(val opened: Boolean, val text: String)
    private class Wait(val code: Int, val text: String)   // 0 diterima, 1 macet, 2 habis waktu, 3 dihentikan

    // Samakan huruf yang sering tertukar oleh OCR (l/i -> 1, o -> 0), di kedua sisi
    private fun fold(s: String): String {
        val n = TextMatch.norm(s).replace(" ", "")
        val sb = StringBuilder(n.length)
        for (ch in n) {
            sb.append(
                when (ch) {
                    'l', 'i' -> '1'
                    'o' -> '0'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    // "input text" hanya andal untuk huruf, angka, spasi, titik, strip, dan garis bawah.
    // Karakter lain (simbol seperti • √ { } [ ] ~ | % dst) diisi lewat clipboard + Paste.
    fun needsPaste(nick: String): Boolean = nick.any {
        !(it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == ' ' || it == '-' || it == '_' || it == '.')
    }

    private fun setClipboard(svc: OcrA11yService, text: String): Boolean {
        var ok = false
        val latch = CountDownLatch(1)
        Handler(Looper.getMainLooper()).post {
            try {
                val cm = svc.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("nickname", text))
                ok = true
            } catch (e: Throwable) {
            }
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
        return ok
    }

    // Masukkan nickname ke kolom yang fokus: diketik, atau ditempel kalau ada karakter khusus
    fun typeText(svc: OcrA11yService, nick: String, log: (String) -> Unit): Pair<Boolean, String> {
        if (!needsPaste(nick)) return ShizukuHelper.inputText(nick, 4000L)
        if (!setClipboard(svc, nick)) return Pair(false, "tidak bisa mengisi clipboard")
        log("teks berisi karakter khusus, ditempel lewat clipboard")
        return ShizukuHelper.pasteKey(4000L)
    }

    // Bagian huruf/angka dari nickname (simbol dibuang, sudah di-fold). Simbol sering salah dibaca OCR,
    // jadi yang dicocokkan hanya bagian huruf/angkanya, berurutan.
    private fun nickParts(nick: String): List<String> =
        nick.split(Regex("[^A-Za-z0-9]+")).filter { it.isNotEmpty() }.map { fold(it) }.filter { it.isNotEmpty() }

    // Teks diputar 180 derajat: urutan dibalik, 6<->9, p<->d, b<->q, n<->u, m<->w.
    // OCR kadang menebak arah tulisan terbalik kalau hurufnya simetris (misal SHIHO | 9 -> '61 OHIHS').
    private fun rot180(f: String): String {
        val sb = StringBuilder(f.length)
        for (i in f.length - 1 downTo 0) {
            sb.append(
                when (f[i]) {
                    '6' -> '9'
                    '9' -> '6'
                    'p' -> 'd'
                    'd' -> 'p'
                    'b' -> 'q'
                    'q' -> 'b'
                    'n' -> 'u'
                    'u' -> 'n'
                    'm' -> 'w'
                    'w' -> 'm'
                    else -> f[i]
                }
            )
        }
        return sb.toString()
    }

    private fun nickMatches(f: String, parts: List<String>): Boolean =
        seqMatch(f, parts) || seqMatch(rot180(f), parts)

    // Cari bagian nama (p) mulai dari posisi 'from'. Bagian >= 4 huruf boleh salah/kurang/lebih 1 huruf
    // (OCR kadang menghilangkan huruf yang menempel dengan simbol, misal SHIHO • -> SHIH•).
    // Hasil: posisi akhir bagian itu, atau -1 kalau tidak ketemu.
    private fun findPart(f: String, p: String, from: Int): Int {
        val i = f.indexOf(p, from)
        if (i >= 0) return i + p.length
        if (p.length < 4) return -1
        for (len in (p.length - 1)..(p.length + 1)) {
            var s = from
            while (s + len <= f.length) {
                if (TextMatch.lev(f.substring(s, s + len), p, 1) <= 1) return s + len
                s++
            }
        }
        return -1
    }

    private fun seqMatch(f: String, parts: List<String>): Boolean {
        if (parts.isEmpty()) return f.isNotEmpty()
        var pos = 0
        for (p in parts) {
            val end = findPart(f, p, pos)
            if (end < 0) return false
            pos = end
        }
        return f.length <= parts.sumOf { it.length } + 3
    }

    // Bar ketik terbuka = dua titik di bar itu putih
    private fun barOpen(b: Bitmap): Boolean {
        val a = PixelCheck.brightness(PixelCheck.at(b, 0.5f, 0.21f))
        val c = PixelCheck.brightness(PixelCheck.at(b, 0.25f, 0.25f))
        return a > 225 && c > 225
    }

    // Tunggu bar ketik tertutup. true = tercapai.
    private fun waitBarClosed(svc: OcrA11yService, limitMs: Long, stop: () -> Boolean): Boolean {
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val open = barOpen(b)
            b.recycle()
            if (!open) return true
        }
        return false
    }

    // Tunggu bar ketik terbuka, dan baca teks di dalamnya dari screenshot yang sama
    private fun waitBarOpen(svc: OcrA11yService, limitMs: Long, stop: () -> Boolean): Open {
        val end = SystemClock.uptimeMillis() + limitMs
        while (!stop() && SystemClock.uptimeMillis() < end) {
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            if (!barOpen(b)) {
                b.recycle()
                continue
            }
            val r = ScreenOcr.read(b, BAR_TEXT, 0.8f)
            if (!r.timedOut) b.recycle()
            return Open(true, if (r.error != null) "" else r.text.replace('\n', ' ').trim())
        }
        return Open(false, "")
    }

    // Baca teks di satu area. null kalau screenshot/OCR gagal.
    private fun readArea(svc: OcrA11yService, area: Area, scale: Float): String? {
        val s = svc.capture(1500L)
        val b = s.bmp ?: return null
        val r = ScreenOcr.read(b, area, scale)
        if (!r.timedOut) b.recycle()
        return if (r.error != null) null else r.text
    }

    private fun hasPopup(text: String): Boolean =
        Popups.SWITCH_ACCOUNT.keys.any { TextMatch.matches(text, it) }

    private fun closePopup(svc: OcrA11yService, sw: Int, sh: Int, log: (String) -> Unit) {
        val p = Popups.SWITCH_ACCOUNT
        val ok = svc.tap(p.tapX * sw, p.tapY * sh)
        log("popup ${p.name} terlihat, ketuk silang: " + (if (ok) "OK" else "GAGAL"))
    }

    // Cek sekali: ada popup yang menutupi? Kalau ya, tutup.
    private fun checkPopup(svc: OcrA11yService, sw: Int, sh: Int, log: (String) -> Unit) {
        val t = readArea(svc, Area.CREATE_TOP, 0.6f) ?: return
        if (hasPopup(t)) closePopup(svc, sw, sh, log)
    }

    // Sudah di halaman tujuan? Kembalikan teks kunci yang cocok, atau null.
    private fun quickAccepted(svc: OcrA11yService): String? {
        val t = readArea(svc, Area.FULL, 0.6f) ?: return null
        return ACCEPT_KEYS.firstOrNull { TextMatch.matches(t, it) }
    }

    private fun isSkipPage(hit: String): Boolean = hit != "Select a hero"

    // Ketuk Skip, lalu tunggu halaman Level Up. 0 = muncul, 1 = habis waktu, 2 = dihentikan.
    // Kalau halaman Skip masih terlihat, Skip diketuk lagi tiap 3 detik (maksimal 4 kali).
    private fun skipToLevelUp(
        svc: OcrA11yService,
        sw: Int,
        sh: Int,
        budgetMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Int {
        val end = SystemClock.uptimeMillis() + budgetMs
        var taps = 1
        var lastTap = SystemClock.uptimeMillis()
        val ok0 = svc.tap(SKIP_X * sw, SKIP_Y * sh)
        log("ketuk Skip di (${(SKIP_X * sw).toInt()}, ${(SKIP_Y * sh).toInt()}): " + (if (ok0) "OK" else "GAGAL"))
        while (!stop()) {
            if (SystemClock.uptimeMillis() >= end) return 1
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val r = ScreenOcr.read(b, Area.FULL, 0.6f)
            if (!r.timedOut) b.recycle()
            if (r.error != null) continue
            if (LEVEL_KEYS.any { TextMatch.matches(r.text, it) }) return 0
            val onSkip = ACCEPT_KEYS.any { isSkipPage(it) && TextMatch.matches(r.text, it) }
            val now = SystemClock.uptimeMillis()
            if (onSkip && taps < 4 && now - lastTap >= 3000L) {
                taps++
                lastTap = now
                val ok = svc.tap(SKIP_X * sw, SKIP_Y * sh)
                log("halaman Skip masih terlihat, ketuk Skip lagi (ke-$taps): " + (if (ok) "OK" else "GAGAL"))
            }
        }
        return 2
    }

    // Ketuk Skip lalu tunggu halaman Level Up (dipakai aturan apk "Select a hero"). 0 = muncul, 1 = habis waktu, 2 = dihentikan
    fun skipOnly(svc: OcrA11yService, sw: Int, sh: Int, budgetMs: Long, stop: () -> Boolean, log: (String) -> Unit): Int =
        skipToLevelUp(svc, sw, sh, budgetMs, stop, log)

    // Setelah halaman tujuan muncul: kalau itu halaman Skip, ketuk Skip dan tunggu Level Up.
    // Halaman "Select a hero" tidak diketuk apa pun. Hasil: keterangan untuk log.
    private fun afterAccepted(
        svc: OcrA11yService,
        hit: String,
        sw: Int,
        sh: Int,
        levelMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): String {
        if (!isSkipPage(hit)) return "layar '$hit' muncul"
        val t0 = SystemClock.uptimeMillis()
        val r = skipToLevelUp(svc, sw, sh, levelMs, stop, log)
        val ms = SystemClock.uptimeMillis() - t0
        return when (r) {
            0 -> "layar '$hit' muncul, Skip diketuk, halaman Level Up muncul ($ms ms)"
            1 -> "layar '$hit' muncul, Skip diketuk tapi halaman Level Up belum muncul sampai batas waktu"
            else -> "dihentikan"
        }
    }

    // Setelah Okay: tunggu SAMPAI halaman tujuan muncul. Create Character hilang saja belum cukup
    // (bisa masih loading). Macet = Create Character terus terlihat selama STUCK_MS.
    private fun waitAccepted(
        svc: OcrA11yService,
        createKeys: List<String>,
        sw: Int,
        sh: Int,
        budgetMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Wait {
        val end = SystemClock.uptimeMillis() + budgetMs
        var stillSince = -1L
        var seen = ""
        while (!stop()) {
            val now = SystemClock.uptimeMillis()
            if (now >= end) return Wait(2, seen)
            val s = svc.capture(1500L)
            val b = s.bmp ?: continue
            val r = ScreenOcr.read(b, Area.FULL, 0.6f)
            if (!r.timedOut) b.recycle()
            if (r.error != null) continue
            seen = r.text.replace('\n', ' ').trim()

            if (hasPopup(r.text)) {
                closePopup(svc, sw, sh, log)
                stillSince = -1L
                continue
            }
            val hit = ACCEPT_KEYS.firstOrNull { TextMatch.matches(r.text, it) }
            if (hit != null) return Wait(0, hit)

            if (createKeys.any { TextMatch.matches(r.text, it) }) {
                val t = SystemClock.uptimeMillis()
                if (stillSince < 0) stillSince = t
                else if (t - stillSince >= STUCK_MS) return Wait(1, seen)
            } else {
                stillSince = -1L
            }
        }
        return Wait(3, seen)
    }

    // Satu percobaan penuh. submit = false: berhenti setelah nama terisi di kolom game (untuk tes).
    private fun attempt(
        svc: OcrA11yService,
        nick: String,
        sw: Int,
        sh: Int,
        submit: Boolean,
        createKeys: List<String>,
        budgetMs: Long,
        levelMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Att {
        val t0 = SystemClock.uptimeMillis()
        val sb = StringBuilder()
        fun mark(label: String, from: Long) {
            sb.append(label).append(' ').append(SystemClock.uptimeMillis() - from).append(" ms, ")
        }
        fun tapAt(fx: Float, fy: Float): Boolean = svc.tap(fx * sw, fy * sh)

        try {
            // 1. Ketuk kolom nama, tunggu bar ketik terbuka (sekalian baca nama lama)
            var a = SystemClock.uptimeMillis()
            var opened = false
            var old = ""
            for (k in 1..2) {
                if (stop()) return Att(OUT_FAIL, "dihentikan")
                if (!tapAt(FIELD_X, FIELD_Y)) return Att(OUT_FAIL, "ketukan ke kolom nama gagal")
                val o = waitBarOpen(svc, 1500L, stop)
                if (o.opened) {
                    opened = true
                    old = o.text
                    break
                }
                // Bar tidak terbuka: mungkin tertutup popup Switch Account
                checkPopup(svc, sw, sh, log)
            }
            mark("kolom", a)
            if (!opened) log("kolom ketik tidak terdeteksi, tetap dicoba")

            // 2. Hapus nama lama sebanyak panjangnya (+3), lalu TUNGGU sampai kolom kosong.
            //    Game memproses tombol pelan, jadi antreannya harus habis dulu.
            val oldF = fold(old)
            val delCount = if (opened && old.isNotEmpty()) (old.length + 3).coerceIn(6, 24) else 20
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            a = SystemClock.uptimeMillis()
            val c = ShizukuHelper.clearField(delCount, 4000L)
            if (!c.first) return Att(OUT_FAIL, "hapus nama gagal: " + c.second)

            var prev: String? = null
            var cur = ""
            var settled = false
            val clearEnd = SystemClock.uptimeMillis() + CLEAR_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < clearEnd) {
                val t = readArea(svc, BAR_TEXT, 0.8f) ?: continue
                cur = fold(t)
                if (cur.isEmpty() || (prev != null && cur == prev)) {
                    settled = true
                    break
                }
                prev = cur
            }
            mark("hapus ${delCount}x", a)
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!settled) return Att(OUT_RETRY, "kolom belum selesai dikosongkan (terbaca '$cur')")
            if (oldF.isNotEmpty() && cur.length >= oldF.length) {
                return Att(OUT_RETRY, "nama lama tidak terhapus (terbaca '$cur')")
            }

            // 3. Ketik nickname, lalu TUNGGU sampai muncul utuh di bar. Tidak diketik ulang.
            val parts = nickParts(nick)
            a = SystemClock.uptimeMillis()
            val t = typeText(svc, nick, log)
            if (!t.first) return Att(OUT_FAIL, "ketik nama gagal: " + t.second)

            var verified = false
            var lastRead = ""
            var prevT: String? = null
            var same = 0
            val typeEnd = SystemClock.uptimeMillis() + TYPE_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < typeEnd) {
                val tx = readArea(svc, BAR_TEXT, 0.8f) ?: continue
                lastRead = tx.replace('\n', ' ').trim()
                val f = fold(tx)
                if (nickMatches(f, parts)) {
                    verified = true
                    break
                }
                if (prevT != null && f == prevT) {
                    same++
                    if (same >= 2) break
                } else {
                    same = 0
                }
                prevT = f
            }
            mark("ketik", a)
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!verified) return Att(OUT_RETRY, "nama di bar tidak sesuai (terbaca '${lastRead.take(40)}')")

            // 4. Ketuk OKE di keyboard, tunggu bar ketik tertutup
            a = SystemClock.uptimeMillis()
            var closed = false
            for (k in 1..2) {
                if (stop()) return Att(OUT_FAIL, "dihentikan")
                if (!tapAt(OKE_X, OKE_Y)) return Att(OUT_FAIL, "ketukan ke OKE gagal")
                if (waitBarClosed(svc, 1500L, stop)) {
                    closed = true
                    break
                }
            }
            mark("OKE", a)
            if (!closed) log("kolom ketik belum tertutup setelah OKE, lanjut")

            // 5. Pastikan nama sudah masuk ke KOLOM GAME sebelum Okay diketuk.
            //    (Tanpa ini, Okay bisa terketuk saat game belum mencatat nama, lalu
            //     game menolak dengan pesan 'Name can only contain 4-20 characters'.)
            a = SystemClock.uptimeMillis()
            var gameOk = false
            var gameRead = ""
            val fieldEnd = SystemClock.uptimeMillis() + FIELD_WAIT_MS
            while (!stop() && SystemClock.uptimeMillis() < fieldEnd) {
                val tx = readArea(svc, GAME_FIELD, 0.8f) ?: continue
                gameRead = tx.replace('\n', ' ').trim()
                if (nickMatches(fold(tx), parts)) {
                    gameOk = true
                    break
                }
            }
            mark("cek kolom", a)
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!gameOk) {
                // Tidak persis sama. Kalau kolom kosong atau masih nama lama, ulangi (game belum mencatat).
                // Selain itu kemungkinan besar hanya OCR yang kurang tepat: lanjut ketuk Okay,
                // dan kalau ternyata ditolak, deteksi macet di langkah 7 yang mengulang.
                val g = fold(gameRead)
                val looksOld = oldF.length >= 4 && (g.contains(oldF) || TextMatch.lev(g, oldF, 2) <= 2)
                if (g.isEmpty() || looksOld) {
                    return Att(OUT_RETRY, "kolom nama di game belum berisi nama (terbaca '${gameRead.take(40)}')")
                }
                log("kolom nama di game terbaca '${gameRead.take(40)}' (tidak persis), lanjut ketuk Okay")
            }

            if (!submit) {
                log("Nama '$nick' terisi: " + sb + "total ${SystemClock.uptimeMillis() - t0} ms")
                return Att(OUT_OK, "nama '$nick' terisi di kolom game (tidak diajukan)")
            }

            // 6. Ketuk tombol Okay emas
            if (stop()) return Att(OUT_FAIL, "dihentikan")
            if (!tapAt(OKAY_X, OKAY_Y)) return Att(OUT_FAIL, "ketukan ke Okay gagal")

            // 7. Tunggu sampai masuk halaman tujuan
            a = SystemClock.uptimeMillis()
            val left = (budgetMs - (a - t0)).coerceAtLeast(5000L)
            val w = waitAccepted(svc, createKeys, sw, sh, left, stop, log)
            return when (w.code) {
                0 -> {
                    mark("halaman", a)
                    log("Nama '$nick' diisi: " + sb + "total ${SystemClock.uptimeMillis() - t0} ms")
                    Att(OUT_OK, afterAccepted(svc, w.text, sw, sh, levelMs, stop, log))
                }
                1 -> Att(OUT_RETRY, "masih di Create Character setelah $STUCK_MS ms (teks layar: '${w.text.take(70)}')", true)
                2 -> Att(OUT_FAIL, "belum masuk halaman Skip/Select hero sampai batas waktu")
                else -> Att(OUT_FAIL, "dihentikan")
            }
        } catch (e: Throwable) {
            val root = e.cause ?: e
            return Att(OUT_FAIL, "error: ${root.javaClass.simpleName} ${root.message ?: ""}".trim())
        }
    }

    // maxWaitMs = total waktu yang boleh dipakai untuk satu apk (dipakai jeda putaran 2).
    fun fill(
        nick: String,
        sw: Int,
        sh: Int,
        submit: Boolean,
        createKeys: List<String>,
        maxWaitMs: Long,
        stop: () -> Boolean,
        log: (String) -> Unit
    ): Result {
        val svc = OcrA11yService.instance ?: return Result(false, "Aksesibilitas mati")
        if (!ShizukuHelper.hasPermission()) return Result(false, "Shizuku belum diizinkan")
        if (sw <= 0 || sh <= 0) return Result(false, "ukuran layar tidak diketahui")

        val start = SystemClock.uptimeMillis()
        val tries = if (submit) MAX_ATTEMPTS else 1
        var last = "belum dicoba"
        var lastStuck = false
        var done = 0
        for (n in 1..tries) {
            if (stop()) return Result(false, "dihentikan")
            val left = maxWaitMs - (SystemClock.uptimeMillis() - start)
            if (n > 1) {
                if (left < MIN_RETRY_MS) break
                // Siapa tahu halaman tujuan sudah muncul (lambat) sejak percobaan sebelumnya
                val q = quickAccepted(svc)
                if (q != null) return Result(true, afterAccepted(svc, q, sw, sh, maxWaitMs, stop, log))
            }
            done = n
            val a = attempt(svc, nick, sw, sh, submit, createKeys, maxOf(left, 10000L), maxWaitMs, stop, log)
            when (a.out) {
                OUT_OK -> return Result(true, a.reason)
                OUT_FAIL -> return Result(false, a.reason)
                else -> {
                    last = a.reason
                    lastStuck = a.stuck
                    log("percobaan $n gagal: ${a.reason}, diulang")
                }
            }
        }
        // Macet di Create Character = kemungkinan ditolak game -> hentikan penamaan.
        // Selain itu (OCR salah baca, dll) hanya apk ini yang dilewati.
        return Result(false, "setelah $done percobaan: $last", lastStuck)
    }
}
