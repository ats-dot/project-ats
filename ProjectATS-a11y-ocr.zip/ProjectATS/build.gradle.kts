plugins {
    id("com.android.application") version "8.5.2"
    id("org.jetbrains.kotlin.android") version "1.9.24"
}
android {
    namespace = "com.ats_tsalatsah.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ats_tsalatsah.app"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk {
            // Hanya 64-bit (arm64): kedua HP target memakainya, dan pustaka OCR untuk 32-bit hanya menambah ukuran APK
            abiFilters += listOf("arm64-v8a")
        }
    }
    // Kunci tanda tangan tetap: semua build bertanda tangan sama, jadi APK baru bisa dipasang menimpa tanpa uninstall
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release {
            // Rilis ringan: tidak diacak atau dipangkas (aman untuk Shizuku dan OCR), tapi tidak lagi "debuggable"
            isMinifyEnabled = false
            isShrinkResources = false
            // Kunci tanda tangan sama dengan sebelumnya, jadi APK baru tetap bisa dipasang menimpa tanpa uninstall
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    lint {
        // Pemeriksaan lint rilis dimatikan supaya build tidak gagal karena peringatan yang tidak berkaitan dengan fitur
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    // OCR offline (model ikut di dalam APK)
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
