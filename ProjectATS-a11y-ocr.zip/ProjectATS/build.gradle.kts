plugins {
    id("com.android.application") version "8.5.2"
    id("org.jetbrains.kotlin.android") version "1.9.24"
}
android {
    namespace = "com.ats_tsalatsah.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ats_tsalatsah.app"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk {
            // Batasi arsitektur supaya APK tidak membengkak karena model OCR
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }
    // Kunci tanda tangan tetap: semua build bertanda tangan sama, jadi APK baru bisa dipasang menimpa tanpa uninstall
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    // OCR offline (model ikut di dalam APK)
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
