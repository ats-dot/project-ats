# Catatan proyek: Project ats

Baca berkas ini dulu. Jangan membaca seluruh kode; pakai `grep -n` lalu baca hanya fungsi yang perlu diubah.

## Cara kerja dengan pemilik proyek
- Bahasa Indonesia, singkat, cocok layar HP kecil. Pemula coding, hanya pakai HP Android.
- Kode tidak bisa dikompilasi di sini. Selalu jujur bahwa kode belum dikompilasi atau diuji.
- Kalau pemilik baru bertanya atau mengeluh: beri penyebab dan usulan dulu, JANGAN langsung menulis kode.
- "jangan buat kode dulu" = hanya analisis. Kalau ragu soal maksud, tanya dulu (maksimal sekitar 3 pertanyaan, lebih baik berupa pilihan).
- Untuk tampilan baru: tunjukkan gambar (mockup) dulu, termasuk tema gelap dan terang, baru dikerjakan.
- Pengiriman: HANYA satu berkas `ProjectATS-a11y-ocr.zip` (nama sama, berisi folder `ProjectATS`), diunggah menimpa yang lama ke GitHub, build lewat GitHub Actions (unzip lalu `gradle assembleDebug`). Jangan kirim berkas per path.
- Log sesi (`Sesi_N.txt`) dikirim pemilik. Saat membaca, saring dulu baris "baca #" yang panjang.
- Hasil log atau layar yang tidak jelas: jangan menebak, minta contoh atau screenshot.

## Ringkasan aplikasi
Aplikasi Android native Kotlin (tanpa Compose), paket `com.ats_tsalatsah.app`, minSdk 30, UI dibuat dari kode.
Fungsi: membuka banyak apk game klon, mencatat nomor server, mengisi nickname otomatis, lalu mengaitkan email ke akun Moonton.
Perlu Shizuku (diizinkan manual) dan layanan Aksesibilitas (untuk screenshot, OCR ML Kit, dan ketukan).

## Alur satu sesi (RunnerService)
1. Putaran 1: tiap apk dibuka, nomor server dibaca dari logcat lewat Shizuku. Jatah waktu tetap per apk (jeda putaran 1).
   - Apk pertama khusus: menunggu popup "Info Sistem", mengetuk "Login kembali" lewat OCR, lalu menunggu sebentar.
   - ID akun dibaca sekali per sesi dari tulisan "Role:<angka>" di pojok kanan atas layar loading (`RoleReader`, dua bacaan harus sama).
2. Putaran 2: apk diurutkan nomor server kecil ke besar. Tiap apk menunggu halaman "Create Character" lewat OCR (maks jeda putaran 2).
   Popup Switch Account ditutup (X) dan memperpanjang waktu tunggu 10 detik (maks 3 kali).
   - Nickname otomatis (`NameFiller`): nama = dasar + (nomor awal + urutan), ketik/tempel, cek OCR, ketuk OKE, ketuk Okay, tunggu halaman Skip, ketuk Skip, tunggu Level Up.
   - Apk yang sampai Level Up dicatat. Gagal/ditolak game ("banned word") menghentikan penamaan sesuai aturan di `NameFiller.Result.stopNaming`.
3. Kaitkan otomatis (`Linker`, 14 langkah), di akhir putaran 2, pada apk TERAKHIR yang sampai Level Up:
   Continue, Shop, Purchase, Use Battle Points, tutup dialog, kembali, Profil (baca ID di sini), Account, ikon hadiah, Connect Now, MOONTON Account, isi email, Kirim, tunggu "Email verifikasi telah dikirim".
   Langkah macet = berhenti dan dicatat di log. Email dihapus dari stok setelah halaman konfirmasi muncul.
4. Selesai: kapsul "Selesai N server", animasi sistem dikembalikan.

## Berkas (src/main/java/com/ats_tsalatsah/app)
- MainActivity.kt (besar, ~2400 baris): seluruh UI (4 tab: Cabang, Apps, Aktivitas, Setelan; halaman Stok email; menu bawah; tema).
- RunnerService.kt: layanan latar, logika sesi, penyimpanan log dan Catatan umum, kapsul, tes.
- ShizukuHelper.kt: eksekusi perintah, ketuk, ketik, tempel, force-stop, hapus dari recent.
- OcrA11yService.kt: Aksesibilitas (screenshot, ketukan, titik melayang tak terlihat; dipasang hanya saat sesi/tes).
- ScreenOcr.kt, ScreenWatcher.kt, TextMatch.kt, PixelCheck.kt: OCR, menunggu halaman/popup, pencocokan teks longgar, cek piksel.
- NameFiller.kt, Linker.kt, RoleReader.kt: nickname, alur kaitkan, pembaca ID.
- EmailStock.kt: stok email dan kolom email (SharedPreferences `ats_email`).
- SecureA11y.kt: menyalakan Aksesibilitas lewat Settings.Secure (butuh izin WRITE_SECURE_SETTINGS).
- AutoPerms.kt: memberi izin yang kurang otomatis lewat Shizuku (izin di atas, notifikasi, overlay, baterai).
- AnimScale.kt: mematikan animasi sistem selama sesi (lewat WindowManager dan settings put, dibaca ulang dan dijaga).
- Dlg.kt: dialog bertema (pengganti AlertDialog). Theme.kt, Decor.kt, Widgets.kt: tema, hiasan, komponen. SafeFrame.kt, CrashLog.kt: layar error darurat.

## Tema
Gelap "Kabut hutan" dan terang "Puncak salju". Warna lewat `Palette` (Theme.kt). Ikon dan logo desain pemilik, jangan diubah tanpa diminta.

## Pengaturan bawaan penting
jeda putaran 1 = 5700 ms, jeda putaran 2 = 25000 ms, tunggu setelah ketuk = 1800 ms, waktu ketukan Got it = 4900 ms.
Nickname otomatis nyala, Kaitkan otomatis nyala, Stok email nyala, matikan animasi sistem saat proses nyala.

## Aturan yang pernah membuat build gagal atau perilaku salah
- Teks `helpItems` di MainActivity tidak boleh berisi tanda kutip ganda di dalamnya (merusak kompilasi).
- Log hanya untuk kejadian selama sesi. Jangan mencatat kejadian di luar sesi (menumpuk jadi "sesi" palsu).
- Titik melayang dipasang saat Mulai, bukan saat layanan tersambung.
- Pencocokan teks halaman dilakukan per baris OCR (kata dari baris berbeda bisa salah cocok, mis. "Purchase Hero" vs "Heroes").
- ID dari halaman Profil lebih dipercaya daripada ID dari Role (OCR kadang salah satu digit, mis. 3 terbaca 8).
- Putaran 2: sesaat setelah apk baru dibuka, layar apk sebelumnya bisa masih tampil. Kalau itu Create Character, dulu dianggap milik apk baru (sesi 28, server 57119 dan 57136). Sekarang `ScreenWatcher.waitFor(..., STALE_GUARD_MS)`: Create Character baru dihitung kalau layar sudah pernah terbaca tanpa Create Character, atau terbaca terus sejak awal selama 3 detik.
- Cek nama (`NameFiller.fold`): angka 7 di font game sering terbaca Z, jadi z disamakan dengan 7 (seperti l/i = 1, o = 0).
- Cek nama longgar (`NameFiller.nearMatch`): bagian nama di bawah 4 huruf (misal awalan AOI) dulu harus terbaca persis, sehingga sesi 2_2 gagal di 15 apk padahal namanya terketik benar (I hilang di samping '-', O terbaca Q, 0 terbaca d, '-' terbaca ':'). Sekarang, kalau tidak persis, nama UTUH dibandingkan: boleh beda 1 huruf (2 untuk nama 8 huruf ke atas), q/d = 0, s = 5, b = 8, g = 9, harus mulai di huruf pertama/kedua, sisa di belakang maks 3 huruf. Di bar ketik, cara longgar ini baru dipakai SESUDAH teks bar tidak berubah lagi (ketikan selesai), supaya ketikan yang belum utuh tidak ikut lolos. Di kolom game, cara ini dicek sebelum pemeriksaan "nama lama" (saat diulang, nama lama bisa sama dengan nama baru).
- Saat proses berhenti karena gagal (`fixFail`) atau Kaitkan otomatis berhenti, layar saat itu disimpan ke `Download/masalah.png` (`saveProblemShot`, nama ditambah " (1)" dst kalau sudah ada) dan Linker menulis teks layar terakhir lengkap. Langkah Purchase yang gagal juga menulis posisi ketukan dan teks halaman Shop saat posisi diambil (sesi 29: dialog Purchase Hero tidak muncul setelah 5 ketukan di server 57029).
- Semua izin selain Shizuku diberikan otomatis lewat `AutoPerms`; Aksesibilitas dinyalakan oleh `SecureA11y` (cepat, tetap jalan walau Shizuku mati).
- Tampilan baru harus memakai `Dlg` untuk dialog dan warna dari `pal`, supaya mengikuti tema.

## Status pengujian
Sudah dicoba pemilik dan berjalan: alur nickname, Kaitkan otomatis penuh, animasi, izin otomatis lewat Shizuku, stok email.
Belum dikonfirmasi: tampilan dialog bertema (Dlg) di HP, dan penghapusan baris Nyala otomatis.

## Integrasi ke Catatan Cabang (aplikasi com.catatan.cabang)
- Di akhir sesi (sesudah putaran 2 dan Kaitkan otomatis), `CatatanLink.sendAccount` mengirim email (kalau berhasil dikaitkan), ID akun (`noteId`), dan SEMUA nomor server yang terbaca di putaran 1 (`map`), tanpa melihat apakah sampai Level Up atau tidak, ke ContentProvider `content://com.catatan.cabang.bukti` (metode `akun`).
- Selain itu, tiap apk di putaran 2 yang selesai (sampai Level Up, atau batas jeda putaran 2 habis) langsung dicatat: ID akun + server apk itu, tanpa email (`catatServerApk`). Kiriman ini jalan di latar (antrean satu thread, berurutan), karena saat 40 game hidup satu kiriman bisa makan ±4 detik dan dulu membuat bot diam. Kiriman akhir menunggu antrean ini habis dulu (maks 20 detik).
  Penjelasan di log: tiap kiriman mencatat hasil dan lamanya; kiriman yang belum dijawab lebih dari 15 detik diberi PERINGATAN; di akhir sesi ada ringkasan "Catatan Cabang per apk: N dikirim, berhasil, gagal, belum selesai". Sesi 29: tidak ada satu pun baris kiriman per apk (penyebab belum diketahui; di awal sesi itu Catatan Cabang ikut ditutup paksa).
- Di Catatan Cabang, akun dicocokkan lewat ID; ID baru jadi folder baru, server baru dicatat Level 1 dan keterangan kosong. Server yang sudah ada tidak diubah.
- Manifest memuat `<queries><provider ...>` supaya provider terlihat di Android 11 ke atas. Kalau Catatan Cabang tidak terpasang, hanya muncul satu baris di log.
- Linker langkah 12 (isi email): isi kolom diverifikasi hanya dari kotak kolom (`EMAIL_FIELD_AREA`), bukan area luas, karena chip clipboard keyboard menampilkan email yang sama dan membuat verifikasi salah lolos. Kalau tempel gagal, alur berhenti dengan alasan dan teks yang terbaca di kolom (tanpa cadangan ketik satu per satu, sesuai permintaan pemilik).

## Kunci tanda tangan
- `debug.keystore` (di folder ini) dipakai oleh `signingConfigs.debug` supaya semua build bertanda tangan sama dan APK baru bisa dipasang MENIMPA tanpa uninstall. Jangan dihapus atau diganti, karena kalau berubah, pemasangan berikutnya wajib uninstall lagi.
